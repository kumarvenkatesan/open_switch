CREATE TABLE failed_transaction_log_?3 PARTITION OF failed_transaction_log FOR VALUES from ('?1') to ('?2');
CREATE TABLE transaction_log_?3 PARTITION OF transaction_log FOR VALUES from ('?1') to ('?2');
CREATE TABLE api_calls_log_?3 PARTITION OF api_calls_log FOR VALUES from ('?1') to ('?2');
CREATE TABLE customer_entry_?3 PARTITION OF customer_entry FOR VALUES from ('?1') to ('?2');
CREATE TABLE ledger_entry_?3 PARTITION OF ledger_entry FOR VALUES from ('?1') to ('?2');