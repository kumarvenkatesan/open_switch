
CREATE TABLE if not exists account_rule_info (
	rule_id varchar(10) NOT NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	business_entity varchar(12) NOT NULL,
	financial_entity varchar(12) NOT NULL,
	product_code varchar(12) NOT NULL,
	txn_type varchar(10) NOT NULL,
	CONSTRAINT account_rule_info_pkey PRIMARY KEY (rule_id),
	CONSTRAINT uk16ur4of4qhhlfq3711iv6ixg0 UNIQUE (business_entity, financial_entity, product_code, txn_type)
);


CREATE TABLE api_calls_log (
	log_id varchar(255) NOT NULL,
	created_date date NOT NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	request text NULL,
	request_url varchar(255) NOT NULL,
	response text NULL,
	"source" varchar(255) NOT NULL,
	created_month varchar(6) NOT NULL,
	CONSTRAINT api_calls_log_pk PRIMARY KEY (log_id, created_date, created_month)
)
PARTITION BY RANGE (created_date);

create table if not exists api_calls_log_${date} partition of api_calls_log for values from ('${start_date}') to ('${end_date}');


CREATE TABLE if not exists customer_balance (
	account_number varchar(32) NOT NULL,
	product_code varchar(12) NOT NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	available_balance numeric(26, 4) NOT NULL,
	balance_limit numeric(26, 4) NULL,
	credit_balance numeric(26, 4) NOT NULL,
	currency_code varchar(3) NOT NULL,
	debit_balance numeric(26, 4) NOT NULL,
	balance_type bpchar(1) NOT NULL,
	financial_entity varchar(255) NOT NULL,
	CONSTRAINT customer_balance_financial_entity_idx PRIMARY KEY (financial_entity,account_number)
);

CREATE TABLE customer_entry (
	pkey bigserial NOT NULL,
	created_date date NOT NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	account_number varchar(32) NOT NULL,
	account_type varchar(255) NOT NULL,
	accounting_seq int4 NOT NULL,
	amount numeric(26, 4) NOT NULL,
	auth_num int8 NOT NULL,
	currency_code varchar(3) NOT NULL,
	dr_cr_flag bpchar(1) NOT NULL,
	financial_entity varchar(12) NOT NULL,
	fund_type bpchar(1) NOT NULL,
	narration varchar(255) NOT NULL,
	transaction_key varchar(255) NOT NULL,
	transaction_type varchar(11) NOT NULL,
	closing_balance numeric(26, 4) NOT NULL,
	created_month varchar(6) NOT NULL,
	CONSTRAINT customer_entry_pk PRIMARY KEY (pkey, created_date, created_month)
)
PARTITION BY RANGE (created_date);

create table if not exists customer_entry_${date} partition of customer_entry for values from ('${start_date}') to ('${end_date}');


CREATE TABLE failed_transaction_log (
	pkey bigserial NOT NULL,
	created_date date NOT NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	account_no varchar(255) NULL,
	accounting_entry text NULL,
	accounting_rule_id varchar(255) NULL,
	beneficiary_account_no varchar(255) NULL,
	beneficiary_customer_id varchar(255) NULL,
	business_entity varchar(255) NULL,
	customer_id varchar(255) NULL,
	dr_cr_amount numeric(19, 2) NULL,
	dr_cr_flag bpchar(1) NULL,
	fee_amount numeric(19, 2) NULL,
	available_balance numeric(26, 8) NULL,
	financial_entity varchar(255) NULL,
	instrument_id varchar(255) NULL,
	instrument_type varchar(255) NULL,
	interest_amount numeric(19, 2) NULL,
	issuer_id varchar(255) NULL,
	iss_currency_code varchar(255) NULL,
	narration varchar(255) NULL,
	org_source_transaction_key varchar(255) NULL,
	org_transaction_date date NULL,
	product_id varchar(255) NULL,
	remarks varchar(255) NULL,
	api_ref_num varchar(255) NULL,
	request_type varchar(255) NULL,
	additional_data1 text NULL,
	additional_data2 text NULL,
	additional_data3 text NULL,
	response_code varchar(255) NULL,
	reversal_amount numeric(19, 2) NULL,
	reversal_flag bpchar(1) NULL,
	"source" varchar(255) NULL,
	source_transaction_key varchar(255) NULL,
	transaction_amount numeric(19, 2) NULL,
	transaction_date_time timestamp NULL,
	transaction_key varchar(255) NULL,
	transaction_status bpchar(1) NULL,
	transaction_type varchar(255) NULL,
	transaction_seq int8 NULL,
	created_month varchar(6) NOT NULL,
	CONSTRAINT failed_transaction_log_pk PRIMARY KEY (pkey, created_date, created_month),
	CONSTRAINT failed_transaction_log_uk UNIQUE (source, source_transaction_key, created_date, created_month)
)
PARTITION BY RANGE (created_date);

create table if not exists failed_transaction_log_${date} partition of failed_transaction_log for values from ('${start_date}') to ('${end_date}');


CREATE TABLE if not exists key_mapper (
	key_rule_id varchar(255) NOT NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	keys text NULL,
	CONSTRAINT key_mapper_pkey PRIMARY KEY (key_rule_id)
);

CREATE TABLE if not exists ledger_acct_map (
	ledger_key varchar(128) NOT NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	account_number varchar(32) NOT NULL,
	financial_entity varchar(255) NULL,
	ledger_code varchar(3) NOT NULL,
	CONSTRAINT ledger_acct_map_pkey PRIMARY KEY (ledger_key),
	CONSTRAINT uk2j3gfoebljki5qnvhwm32abmg UNIQUE (ledger_key, financial_entity)
);

CREATE TABLE ledger_entry (
	pkey bigserial NOT NULL,
	created_date date NOT NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	account_number varchar(32) NOT NULL,
	account_type varchar(255) NOT NULL,
	accounting_seq int4 NOT NULL,
	amount numeric(26, 4) NOT NULL,
	auth_num int8 NOT NULL,
	currency_code varchar(3) NOT NULL,
	dr_cr_flag bpchar(1) NOT NULL,
	financial_entity varchar(12) NOT NULL,
	fund_type bpchar(1) NOT NULL,
	narration varchar(255) NOT NULL,
	transaction_key varchar(255) NOT NULL,
	transaction_type varchar(11) NOT NULL,
	created_month varchar(6) NOT NULL,
	CONSTRAINT ledger_entry_pk PRIMARY KEY (pkey, created_date, created_month)
)
PARTITION BY RANGE (created_date);

create table if not exists ledger_entry_${date} partition of ledger_entry for values from ('${start_date}') to ('${end_date}');

CREATE TABLE if not exists ledger_key_select (
	select_key varchar(128) NOT NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	entity_id varchar(255) NULL,
	ledger_code_type varchar(255) NULL,
	CONSTRAINT ledger_key_select_pkey PRIMARY KEY (select_key)
);


CREATE TABLE if not exists transaction_key_rule (
	business_entity varchar(12) NOT NULL,
	financial_entity varchar(12) NOT NULL,
	"source" varchar(12) NOT NULL,
	txn_type varchar(32) NOT NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	description varchar(45) NOT NULL,
	key_rule varchar(128) NOT NULL,
	narration varchar(128) NOT NULL,
	CONSTRAINT transaction_key_rule_pkey PRIMARY KEY (business_entity, financial_entity, source, txn_type)
);

-- auth_test.transaction_log definition

-- Drop table

-- DROP TABLE transaction_log;

CREATE TABLE transaction_log (
	pkey bigserial NOT NULL,
	created_date date NOT NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	account_no varchar(32) NOT NULL,
	accounting_entry text NULL,
	accounting_rule_id varchar(20) NULL,
	beneficiary_account_no varchar(32) NULL,
	beneficiary_customer_id varchar(32) NULL,
	business_entity varchar(12) NOT NULL,
	customer_id varchar(32) NOT NULL,
	dr_cr_amount numeric(26, 4) NOT NULL,
	dr_cr_flag bpchar(1) NOT NULL,
	fee_amount numeric(26, 4) NULL,
	financial_entity varchar(12) NOT NULL,
	instrument_id varchar(32) NULL,
	instrument_type varchar(4) NULL,
	interest_amount numeric(26, 4) NULL,
	issuer_id varchar(8) NULL,
	iss_currency_code varchar(3) NOT NULL,
	narration varchar(255) NOT NULL,
	org_source_transaction_key varchar(255) NULL,
	org_transaction_date date NULL,
	product_id varchar(11) NOT NULL,
	remarks varchar(255) NOT NULL,
	api_ref_num varchar(255) NOT NULL,
	request_type varchar(12) NOT NULL,
	additional_data1 text NULL,
	additional_data2 text NULL,
	additional_data3 text NULL,
	response_code varchar(3) NOT NULL,
	reversal_amount numeric(26, 4) NULL,
	reversal_flag bpchar(1) NULL,
	"source" varchar(12) NOT NULL,
	source_transaction_key varchar(255) NOT NULL,
	transaction_amount numeric(26, 4) NULL,
	transaction_date_time timestamp NOT NULL,
	transaction_key varchar(255) NOT NULL,
	transaction_status bpchar(1) NOT NULL,
	transaction_type varchar(12) NOT NULL,
	transaction_seq int8 NOT NULL,
	available_balance numeric(26, 8) NOT NULL,
	additional_data4 text NULL,
	additional_data5 text NULL,
	split_flag bpchar NULL,
	created_month varchar(6) NOT NULL,
	CONSTRAINT transaction_log_pk PRIMARY KEY (pkey, created_date, created_month),
	CONSTRAINT transaction_log_un UNIQUE (source, business_entity, transaction_key, created_date, created_month),
	CONSTRAINT transaction_log_un_1 UNIQUE (source, source_transaction_key, created_date, created_month)
)
PARTITION BY RANGE (created_date);

create table if not exists transaction_log_${date} partition of transaction_log for values from ('${start_date}') to ('${end_date}');

CREATE TABLE if not exists transaction_seq_info (
	financial_entity varchar(255) NOT NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	transaction_seq int8 NULL,
	CONSTRAINT transaction_seq_info_pkey PRIMARY KEY (financial_entity)
);


CREATE TABLE if not exists transaction_type (
	pkey bigserial NOT NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	is_balance_req bool NOT NULL DEFAULT false,
	business_entity varchar(12) NOT NULL,
	description varchar(45) NULL,
	financial_entity varchar(12) NOT NULL,
	fund_type bpchar(1) NOT NULL,
	txn_mode bpchar(1) NOT NULL,
	txn_type varchar(12) NOT NULL,
	CONSTRAINT transaction_type_pkey PRIMARY KEY (pkey),
	CONSTRAINT uk1k03kagrbwtuqw5ylqgl91lci UNIQUE (business_entity, financial_entity, txn_type)
);


CREATE TABLE if not exists account_fund_flow (
	pkey bigserial NOT NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	acct_type varchar(255) NULL,
	dr_cr_flag varchar(255) NULL,
	fund_type varchar(255) NULL,
	seq_no int4 NOT NULL,
	rule_id varchar(10) NULL,
	CONSTRAINT account_fund_flow_pkey PRIMARY KEY (pkey),
	CONSTRAINT fkreeh2etxex5atjceq6eo72lml FOREIGN KEY (rule_id) REFERENCES auth.account_rule_info(rule_id)
);