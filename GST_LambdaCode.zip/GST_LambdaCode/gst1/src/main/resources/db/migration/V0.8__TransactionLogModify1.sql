ALTER TABLE transaction_log ADD is_split boolean NULL;
ALTER TABLE transaction_log ADD mode varchar(5) NULL;