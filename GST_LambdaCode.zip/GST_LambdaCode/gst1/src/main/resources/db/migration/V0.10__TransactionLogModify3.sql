ALTER TABLE transaction_log ADD is_incremental boolean NULL;
ALTER TABLE failed_transaction_log ADD is_incremental boolean NULL;

ALTER TABLE transaction_log ADD is_partial_auth boolean NULL;
ALTER TABLE transaction_log ADD remaining_drCr_amount numeric(26, 4)  NULL;
update transaction_log set remaining_drCr_amount = 0;

ALTER TABLE failed_transaction_log ADD is_partial_auth boolean NULL;
ALTER TABLE failed_transaction_log ADD remaining_drCr_amount numeric(26, 4)  NULL;
update failed_transaction_log set remaining_drCr_amount = 0;