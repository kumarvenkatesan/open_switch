ALTER TABLE customer_balance ADD ledger_balance numeric(26, 4)  NULL;
update customer_balance set ledger_balance = 0;
Alter table customer_balance alter column ledger_balance set NOT NULL;