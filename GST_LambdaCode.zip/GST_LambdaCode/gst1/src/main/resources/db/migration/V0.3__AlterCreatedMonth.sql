ALTER TABLE auth.failed_transaction_log DROP CONSTRAINT failed_transaction_log_pk;
ALTER TABLE auth.failed_transaction_log ADD CONSTRAINT failed_transaction_log_pk PRIMARY KEY (pkey,created_date);

ALTER TABLE transaction_log DROP CONSTRAINT transaction_log_pk;
ALTER TABLE transaction_log ADD CONSTRAINT transaction_log_pk PRIMARY KEY (pkey,created_date);