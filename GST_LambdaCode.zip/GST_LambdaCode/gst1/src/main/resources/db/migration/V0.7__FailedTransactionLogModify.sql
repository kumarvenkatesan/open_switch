ALTER TABLE failed_transaction_log ADD transaction_flag varchar(1) NULL;
update failed_transaction_log set transaction_flag='G';
Alter table failed_transaction_log alter column transaction_flag set NOT NULL;