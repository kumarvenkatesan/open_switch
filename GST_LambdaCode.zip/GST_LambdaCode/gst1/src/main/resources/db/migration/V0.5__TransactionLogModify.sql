ALTER TABLE transaction_log ADD transaction_flag varchar(1) NULL;
update transaction_log set transaction_flag='G';
Alter table transaction_log alter column transaction_flag set NOT NULL;