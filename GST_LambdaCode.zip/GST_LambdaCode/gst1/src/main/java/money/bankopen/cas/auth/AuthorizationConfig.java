package money.bankopen.cas.auth;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import lombok.extern.slf4j.Slf4j;
import money.bankopen.cas.auth.utils.ByteArrToCharacterConverter;
import money.bankopen.cas.auth.utils.ByteArrayToLocalDateTimeConverter;
import money.bankopen.cas.auth.utils.CharacterToByteArrConverter;
import money.bankopen.cas.auth.utils.CommonUtils;
import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.convert.RedisCustomConversions;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Configuration
@Slf4j
@EnableRedisRepositories(basePackages = "money.bankopen.cas.auth.redis.dao")
@EnableJpaRepositories(basePackages = "money.bankopen.cas.auth.domain.dao")
@EnableAsync
@EnableFeignClients
@EnableScheduling
public class AuthorizationConfig {

	@Value("${spring.datasource.url}")
	String dataSourceUrl;

	@Value("${spring.datasource.name}")
	String dataSourceName;

	@Value("${spring.datasource.username}")
	String dataSourceUserName;

	@Value("${spring.datasource.password}")
	String dataSourcePassword;

	@Value("${postgres.db.schema}")
	String databaseSchema;

	@Value("${redis.host}")
	String redisHost;

	@Value("${redis.port}")
	int redisPort;
	
	@Value("${redis.database.index}")
	int redisDataBaseIndex;
	
	@Value("${hikari.max.pool.size}")
	int hikariMaxPoolSize;
	
	@Value("${redis.password}")
	String redisPassword;

	@Bean
	JedisConnectionFactory jedisConnectionFactory() {
		log.info("IP : {} PORT : {}", redisHost, redisPort);
		var redisStandaloneConfiguration = new RedisStandaloneConfiguration(redisHost, redisPort);
		if(redisPassword != null) {
			redisStandaloneConfiguration.setPassword(redisPassword);
		}
		redisStandaloneConfiguration.setDatabase(redisDataBaseIndex);
		JedisConnectionFactory jedisConFactory = null;
		jedisConFactory = new JedisConnectionFactory(redisStandaloneConfiguration);
		jedisConFactory.getPoolConfig().setMaxTotal(50);
		jedisConFactory.getPoolConfig().setMaxIdle(50);
		jedisConFactory.getPoolConfig().setMinIdle(10);
		return jedisConFactory;
	}

	@Bean
	public RedisTemplate<String, Object> redisTemplate() {
		RedisTemplate<String, Object> template = new RedisTemplate<>();
		template.setConnectionFactory(jedisConnectionFactory());
		template.setKeySerializer(new StringRedisSerializer());
		template.setValueSerializer(new StringRedisSerializer());
		return template;
	}

	@Bean
	public HikariDataSource dataSource() {
		HikariConfig hConfig = new HikariConfig();
		hConfig.setJdbcUrl(dataSourceUrl + "/" + dataSourceName);
		hConfig.setUsername(dataSourceUserName);
		hConfig.setPassword(dataSourcePassword);
		hConfig.setSchema(databaseSchema);
		hConfig.setMaximumPoolSize(hikariMaxPoolSize);
		return new HikariDataSource(hConfig);
	}

	@Bean
	RedisCustomConversions redisCustomConversions(ByteArrayToLocalDateTimeConverter converter) {
		return new RedisCustomConversions(Arrays.asList(new ByteArrayToLocalDateTimeConverter(),new CharacterToByteArrConverter(),new ByteArrToCharacterConverter()));
	}

	@Bean
	public ObjectMapper objectMapper() {
		ObjectMapper mapper =  Jackson2ObjectMapperBuilder.json().build();
		mapper.registerModule(new JavaTimeModule());
		return mapper;
	}

	@Bean
	public Flyway flyway() {
		Map<String, String> map = new HashMap<>();
		LocalDate d1 = LocalDate.now();
		LocalDate startDate = d1.withDayOfMonth(1);
		LocalDate endDate = d1.withDayOfMonth(d1.lengthOfMonth());

		map.put("date", d1.format(CommonUtils.DATE_MMYYYY));
		map.put("start_date", startDate.format(CommonUtils.DATE_YYYY_MM_DD));
		map.put("end_date", endDate.format(CommonUtils.DATE_YYYY_MM_DD));
		return Flyway.configure().baselineOnMigrate(true).baselineVersion("0.0").schemas(databaseSchema)
				.defaultSchema(databaseSchema).dataSource(this.dataSource()).locations("classpath:db/migration")
				.placeholders(map).load();
	}
	
	@Bean
	public JdbcTemplate jdbcTemplate() {
		return new JdbcTemplate(this.dataSource());
	}

}
