package money.bankopen.cas.auth;

import lombok.Getter;
import money.bankopen.cas.auth.enumtypes.TransactionModes;
import money.bankopen.cas.auth.redis.service.RedisDataLoaderService;
import money.bankopen.cas.auth.service.AbstractAuthService;
import money.bankopen.cas.auth.service.impl.AsyncAuthServiceImpl;
import money.bankopen.cas.auth.service.impl.SyncAuthServiceImpl;
import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.EnumMap;
import java.util.Map;

@Component
public class AppInit implements InitializingBean {
	
	@Autowired
	Flyway flyway;
	
	@Autowired SyncAuthServiceImpl syncService;

	@Autowired
	AsyncAuthServiceImpl asyncService;
	
	@Getter
	Map<TransactionModes, AbstractAuthService> abstractServiceMap = new EnumMap<>(TransactionModes.class);
	
	@Autowired
	RedisDataLoaderService redisLoaderService;
	
	@Value("${redis.internal.load.enable}")
	boolean redisInternalLoadEnabled;

	@Override
	public void afterPropertiesSet() throws Exception {	
		
		abstractServiceMap.put(TransactionModes.SYNC, syncService);
		abstractServiceMap.put(TransactionModes.ASYNC, asyncService);
		
		flyway.migrate(); //db script run
		
		if(redisInternalLoadEnabled)
			redisLoaderService.loadRedisCacheData(); //loading redis cache
	}

}
