package money.bankopen.cas.auth;

import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.*;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.backoff.FixedBackOff;

import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableKafka
public class KafkaConfig {

    @Value("${transaction.topic}")
    private String transactionTopic;

    @Value("${transaction.topic.partition}")
    private int transactionTopicPartition;

    @Value("${kafka.bootstrap.server}")
    private String kafkaBoostrapServer;

    @Value("${kafka.consumer.group.id}")
    private String consumerGroupId;

    @Value("${kafka.consumer.container.concurrency}")
    private int consumerContainerConcurrency;

    @Autowired
    private ThreadPoolTaskExecutor asyncTaskExecutor;

    @Value("${kafka.sasl.enabled}")
    private boolean kafkaSASLEnabled;

    @Value("${spring.kafka.properties.sasl.mechanism}")
    private String saslMechanism;

    @Value("${spring.kafka.properties.security.protocol}")
    private String securityProtocolConfig;

    @Value("${spring.kafka.properties.sasl.jaas.config}")
    private String saslJaasConfig;

    @Bean
    public NewTopic transactionTopic() {
        return TopicBuilder.name(transactionTopic)
                .partitions(transactionTopicPartition)
                .build();
    }

    @Bean
    KafkaAdmin admin() {
        Map<String, Object> configMap = new HashMap<>();
        configMap.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBoostrapServer);
        if (kafkaSASLEnabled) {
            configMap.put(AdminClientConfig.SECURITY_PROTOCOL_CONFIG, securityProtocolConfig);
            configMap.put(SaslConfigs.SASL_MECHANISM, saslMechanism);
            configMap.put(SaslConfigs.SASL_JAAS_CONFIG, saslJaasConfig);
        }
        return new KafkaAdmin(configMap);
    }

    @Bean
    public ProducerFactory<String, String> producerFactory() {
        Map<String, Object> configMap = new HashMap<>();
        configMap.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBoostrapServer);
        configMap.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configMap.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        if (kafkaSASLEnabled) {
            configMap.put(AdminClientConfig.SECURITY_PROTOCOL_CONFIG, securityProtocolConfig);
            configMap.put(SaslConfigs.SASL_MECHANISM, saslMechanism);
            configMap.put(SaslConfigs.SASL_JAAS_CONFIG, saslJaasConfig);
        }
        return new DefaultKafkaProducerFactory<>(configMap);
    }

    @Bean
    public KafkaTemplate<String, String> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }

    @Bean
    public ConsumerFactory<String, String> consumerFactory() {
        Map<String, Object> configMap = new HashMap<>();
        configMap.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBoostrapServer);
        configMap.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        configMap.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        configMap.put(ConsumerConfig.GROUP_ID_CONFIG, consumerGroupId);
        if (kafkaSASLEnabled) {
            configMap.put(AdminClientConfig.SECURITY_PROTOCOL_CONFIG, securityProtocolConfig);
            configMap.put(SaslConfigs.SASL_MECHANISM, saslMechanism);
            configMap.put(SaslConfigs.SASL_JAAS_CONFIG, saslJaasConfig);
        }
        return new DefaultKafkaConsumerFactory<>(configMap);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConcurrency(consumerContainerConcurrency);
        factory.setConsumerFactory(consumerFactory());
        factory.setCommonErrorHandler(new DefaultErrorHandler(new FixedBackOff(0L, 0L)));
        return factory;
    }
}