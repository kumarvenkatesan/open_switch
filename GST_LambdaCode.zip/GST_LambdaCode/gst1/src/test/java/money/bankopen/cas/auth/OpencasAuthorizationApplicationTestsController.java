package money.bankopen.cas.auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpencasAuthorizationApplicationTestsController {

	@Test
	void contextLoads() {
	}

}
