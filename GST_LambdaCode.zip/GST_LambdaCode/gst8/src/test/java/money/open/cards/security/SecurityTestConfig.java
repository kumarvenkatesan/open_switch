package money.open.cards.security;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import redis.embedded.RedisServer;

import javax.annotation.PostConstruct;

@TestConfiguration
@Slf4j
public class SecurityTestConfig {

    private RedisServer redisServer;

    @Value("${redis.port}")
    private int redisPort;

    @Value("${redis.host}")
    String redisHost;

    @Value("${redis.database.index}")
    int redisDataBaseIndex;

    @Value("${redis.password}")
    String redisPassword;

    @PostConstruct
    public void postConstruct(){
        redisServer = new RedisServer(redisPort);
        redisServer.start();
    }

    @Bean
    public JedisConnectionFactory jedisConnectionFactory() {
        RedisStandaloneConfiguration config = new RedisStandaloneConfiguration(redisHost, redisPort);
        if (StringUtils.isNotEmpty(redisPassword)) {
            config.setPassword(redisPassword);
        }
        config.setDatabase(redisDataBaseIndex);
        JedisConnectionFactory cf = new JedisConnectionFactory(config);
        cf.getPoolConfig().setMaxIdle(0); //To force redis to create new connection on every test
        cf.afterPropertiesSet();
        log.info("Checking connection with Redis {}", cf.getConnection().ping());
        return cf;
    }

}
