package money.open.cards.security;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.security.converter.ByteArrToCharacterConverter;
import money.open.cards.security.converter.ByteArrayToLocalDateTimeConverter;
import money.open.cards.security.converter.CharacterToByteArrConverter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.convert.RedisCustomConversions;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.util.Arrays;

@Configuration
@Slf4j
@EnableRedisRepositories(basePackages = {
        "money.open.cards.security.redis.repository"})
public class RedisConfig {

    @Value("${redis.host}")
    String redisHost;

    @Value("${redis.port}")
    int redisPort;

    @Value("${redis.database.index}")
    int redisDataBaseIndex;

    @Value("${redis.password}")
    String redisPassword;

    @Bean
    @Profile("!test")
    public JedisConnectionFactory jedisConnectionFactory() {
        RedisStandaloneConfiguration config = new RedisStandaloneConfiguration(redisHost, redisPort);
        if (StringUtils.isNotEmpty(redisPassword)) {
            config.setPassword(redisPassword);
        }
        config.setDatabase(redisDataBaseIndex);
        JedisConnectionFactory cf = new JedisConnectionFactory(config);
        cf.afterPropertiesSet();
        log.info("Checking connection with Redis {}", cf.getConnection().ping());
        return cf;
    }

    @Bean
    public RedisTemplate<String, Object> redisTemplate() {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(jedisConnectionFactory());
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(new StringRedisSerializer());
        return template;
    }

    @Bean
    public RedisCustomConversions redisCustomConversions() {
        return new RedisCustomConversions(Arrays.asList(new ByteArrayToLocalDateTimeConverter(), new CharacterToByteArrConverter(), new ByteArrToCharacterConverter()));
    }
}
