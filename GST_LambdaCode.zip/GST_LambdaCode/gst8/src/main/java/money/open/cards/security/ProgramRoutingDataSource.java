package money.open.cards.security;

import money.open.cards.security.exception.DataSourceLookupException;
import money.open.cards.security.utils.ResponseCodes;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import javax.sql.DataSource;

public class ProgramRoutingDataSource extends AbstractRoutingDataSource {
    @Override
    protected Object determineCurrentLookupKey() {
        return ProgramContextHolder.getCurrentProgram();
    }

    @Override
    protected DataSource determineTargetDataSource() {
        try {
            return super.determineTargetDataSource();
        } catch (IllegalStateException e){
            throw new DataSourceLookupException(ResponseCodes.INVALID_PROGRAM_ID);
        }
    }
}
