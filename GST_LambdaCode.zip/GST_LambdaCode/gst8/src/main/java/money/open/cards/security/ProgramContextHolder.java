package money.open.cards.security;

public class ProgramContextHolder {
    private static final ThreadLocal<String> currentProgram = new ThreadLocal<>();

    public static String getCurrentProgram(){
        return currentProgram.get();
    }

    public static void setCurrentProgram(String tenant){
        currentProgram.set(tenant);
    }

    public static void removeCurrentProgram(){
        currentProgram.remove();
    }
}
