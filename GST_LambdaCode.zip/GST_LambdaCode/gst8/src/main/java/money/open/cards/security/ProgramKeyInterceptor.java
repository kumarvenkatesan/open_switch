package money.open.cards.security;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.security.utils.ResponseCodes;
import money.open.cards.security.exception.SecurityException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
@Slf4j
public class ProgramKeyInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        String programId = request.getHeader("program");
        log.info("Program id :: {}",programId);
        if(StringUtils.isEmpty(programId))
            throw new SecurityException(ResponseCodes.INVALID_PROGRAM_ID);
        ProgramContextHolder.setCurrentProgram(programId);
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        ProgramContextHolder.removeCurrentProgram();
    }
}
