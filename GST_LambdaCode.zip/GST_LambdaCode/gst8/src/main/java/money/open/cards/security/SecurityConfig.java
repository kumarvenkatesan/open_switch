package money.open.cards.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import money.open.cards.security.redis.ProgramMasterRedis;
import money.open.cards.security.redis.dao.impl.ProgramMasterRedisDaoImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.scheduling.annotation.EnableAsync;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@Configuration
@Slf4j
@EnableJpaRepositories(basePackages = {
        "money.open.cards.security.entity.repository"})
@EnableAsync
@EnableFeignClients
public class SecurityConfig {

    @Value("${hikari.max.pool.size}")
    private int hikariMaxPoolSize;

    @Autowired
    private ProgramMasterRedisDaoImpl programMasterRedisDao;

    @Getter
    private Map<Object,Object> availableDataSources = new HashMap<>();

    @Value("${postgres.db.schema}")
    private String schemaName;

    public Map<Object,Object> loadAvailableDataSources(){
        Iterable<ProgramMasterRedis> programMasterRedisIterable = programMasterRedisDao.findAll();
        Iterator<ProgramMasterRedis> programMasterRedisIterator = programMasterRedisIterable.iterator();
        if(!programMasterRedisIterator.hasNext()){
            log.info("No datasource available to connect");
            throw new RuntimeException("No datasource available to connect");
        }
        while(programMasterRedisIterator.hasNext()){
            ProgramMasterRedis programMasterRedis = programMasterRedisIterator.next();
            log.info("Loading datasource {}",programMasterRedis.getProgramKey());
            HikariConfig hConfig = new HikariConfig();
            hConfig.setJdbcUrl(programMasterRedis.getDbUrl());
            hConfig.setUsername(programMasterRedis.getUsername());
            hConfig.setPassword(programMasterRedis.getPassword());
            hConfig.setSchema(schemaName);
            hConfig.setMaximumPoolSize(hikariMaxPoolSize);
            HikariDataSource hikariDataSource= new HikariDataSource(hConfig);
            availableDataSources.put(programMasterRedis.getProgramKey(),hikariDataSource);
        }
        return availableDataSources;
    }

    @Bean
    @Order(-2)
    @Primary
    @Profile("!test")
    public DataSource dataSource() {
        ProgramRoutingDataSource programRoutingDataSource = new ProgramRoutingDataSource();
        programRoutingDataSource.setTargetDataSources(this.loadAvailableDataSources());
        return programRoutingDataSource;
    }

    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = Jackson2ObjectMapperBuilder.json().build();
        mapper.registerModule(new JavaTimeModule());
        return mapper;
    }

}
