-- secure_vault_bkp.card_vault definition

-- Drop table

-- DROP TABLE card_vault;

CREATE TABLE card_vault (
	card_hash varchar(128) NOT NULL,
	card_enc varchar(64) NOT NULL,
	card_data varchar(64) NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
    created_at timestamp NOT NULL DEFAULT now(),
    modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
    modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT card_vault_pkey PRIMARY KEY (card_hash)
);