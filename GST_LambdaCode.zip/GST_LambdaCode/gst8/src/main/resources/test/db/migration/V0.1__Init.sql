-- secure_vault_bkp.card_vault definition

-- Drop table

-- DROP TABLE card_vault;

CREATE TABLE card_vault (
	card_hash varchar(128) NOT NULL,
	card_enc varchar(64) NOT NULL,
	card_data varchar(64) NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
    created_at timestamp NOT NULL DEFAULT now(),
    modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
    modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT card_vault_pkey PRIMARY KEY (card_hash)
);

-- secure_vault_bkp.hsm_master definition

-- Drop table

-- DROP TABLE hsm_master;

CREATE TABLE hsm_master (
	hsm_id varchar(11) NOT NULL,
	hsm_model varchar(45) NOT NULL,
	hsm_type varchar(1) NOT NULL,
	hsm_ip varchar(15) NOT NULL,
	hsm_port int4 NOT NULL,
	hsm_tcp_header_type varchar(1) NOT NULL,
	hsm_tcp_header_len int4 NOT NULL,
	hsm_msg_header_len int4 NOT NULL,
	timeout int4 NOT NULL,
	reconnect_interval int4 NOT NULL,
	hsm_status varchar(1) NOT NULL,
	description varchar(45) NULL DEFAULT NULL::character varying,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT hsm_master_pkey PRIMARY KEY (hsm_id)
);


-- secure_vault_bkp.issuer_key definition

-- Drop table

-- DROP TABLE issuer_key;

CREATE TABLE issuer_key (
	issuer_key_id varchar(20) NOT NULL,
	pin_ver_method varchar(1) NOT NULL,
	key_store varchar(1) NOT NULL,
	key_len int4 NOT NULL,
	pin_key varchar(74) NOT NULL,
	pin_key_kcv varchar(12) NOT NULL,
	cvv_key varchar(74) NOT NULL,
	cvv_key_kcv varchar(12) NOT NULL,
	chip_ac_key varchar(74) NOT NULL,
	chip_ac_key_kcv varchar(12) NOT NULL,
	dec_table varchar(16) NOT NULL,
	pin_pad_char varchar(1) NOT NULL,
	pan_pad_char varchar(1) NOT NULL,
	pin_len int4 NOT NULL,
	pan_len int4 NOT NULL,
	pan_val_len int4 NOT NULL,
	pan_val_offset int4 NOT NULL,
	pinblock_format varchar(2) NOT NULL,
	pvki varchar(1) NOT NULL,
	cdol1 varchar(250) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT issuer_key_pkey PRIMARY KEY (issuer_key_id)
);


-- secure_vault_bkp.network_key definition

-- Drop table

-- DROP TABLE network_key;

CREATE TABLE network_key (
	network_key_id varchar(20) NOT NULL,
	key_store varchar(1) NOT NULL,
	key_len int4 NOT NULL,
	zonal_master_key varchar(74) NOT NULL,
	zonal_master_key_kcv varchar(12) NOT NULL,
	acq_working_key varchar(74) NOT NULL,
	acq_working_key_kcv varchar(12) NOT NULL,
	iss_working_key varchar(74) NOT NULL,
	iss_working_key_kcv varchar(12) NOT NULL,
	description varchar(45) NULL DEFAULT NULL::character varying,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
    created_at timestamp NOT NULL DEFAULT now(),
    modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
    modified_at timestamp NOT NULL DEFAULT now()
);