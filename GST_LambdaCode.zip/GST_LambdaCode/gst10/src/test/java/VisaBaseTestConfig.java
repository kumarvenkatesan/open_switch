import org.springframework.boot.test.context.TestConfiguration;

@TestConfiguration
public class VisaBaseTestConfig {

}
