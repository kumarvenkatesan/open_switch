package money.open.cards.visabase;

import money.open.cards.visabase.exception.ReqInterepedException;
import money.open.cards.visabase.exception.TransactionException;
import money.open.cards.visabase.validation.ElementValidation;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ElementValidationTests {
    
    
    @BeforeAll
    public void before() {
        MockitoAnnotations.openMocks(this);
    }
    
    @InjectMocks
    ElementValidation validation;
    
    
    @Test
    void validate() throws TransactionException, ReqInterepedException {
        
        assertDoesNotThrow(()->validation.mandatoryValidation("",""));
        // visaProcessAPI.loadPrimaryElements(isoBuffer,transactionRequestDto,mandatoryLoad);
    }
}

