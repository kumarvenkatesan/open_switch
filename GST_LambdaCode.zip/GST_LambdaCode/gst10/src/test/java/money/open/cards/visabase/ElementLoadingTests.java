package money.open.cards.visabase;

import money.open.cards.visabase.constants.Element;
import money.open.cards.visabase.dto.InfData;
import money.open.cards.visabase.dto.TransactionRequestDto;
import money.open.cards.visabase.exception.ReqInterepedException;
import money.open.cards.visabase.service.impl.DataManagingServiceImpl;
import money.open.cards.visabase.service.impl.ElementLoadingServiceImpl;
import money.open.cards.visabase.service.parsor.EMVParser;
import money.open.cards.visabase.utility.Convertor;
import money.open.cards.visabase.utility.TPEGeneralUtil;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.util.Hashtable;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@Disabled("Class not ready for tests")
class ElementLoadingTests {

    
    @BeforeAll
    public void before(){
        MockitoAnnotations.openMocks(this);
    }
    @InjectMocks
    ElementLoadingServiceImpl elementLoadingService;
    
    @InjectMocks
    EMVParser emvParser;
    
    @InjectMocks
    TransactionRequestDto transactionRequestDto;
    @InjectMocks
    Hashtable<String, String> isoBuffer;
    
    String defaultAmount="0.0";
    
    
    
    @Test
    void loadDE002(){
        isoBuffer.put(Element.DE002,"1234512345012345");
        elementLoadingService.setConvertor(new Convertor());
        elementLoadingService.loadDE002(isoBuffer,transactionRequestDto,Element.DE002);
        assertEquals("1234512345012345",transactionRequestDto.getCardNumber());
        assertEquals("123451",transactionRequestDto.getIssuerBin());
        
    }
    
    @Test
    void loadDE003(){
        String element = Element.DE003;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE003(isoBuffer,transactionRequestDto,element);
        assertDoesNotThrow(()->{});
    }
    
    @Test
    void loadDE004(){
        isoBuffer.put(Element.DE004,"*");
        elementLoadingService.setConvertor(new Convertor());
        elementLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementLoadingService.loadDE004(isoBuffer,transactionRequestDto,Element.DE004);
        assertEquals(new BigDecimal(defaultAmount),transactionRequestDto.getTransactionAmount());
    
        isoBuffer.put(Element.DE004,"000000001210");
        elementLoadingService.loadDE004(isoBuffer,transactionRequestDto,Element.DE004);
        assertEquals(new BigDecimal("12.10"),transactionRequestDto.getTransactionAmount());
    }
    @Test
    void loadDE005(){
        isoBuffer.put(Element.DE005,"*");
        elementLoadingService.setConvertor(new Convertor());
        elementLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementLoadingService.loadDE005(isoBuffer,transactionRequestDto,Element.DE005);
        assertEquals(new BigDecimal(defaultAmount),transactionRequestDto.getSettlementAmount());
        
        isoBuffer.put(Element.DE005,"000000001210");
        elementLoadingService.loadDE005(isoBuffer,transactionRequestDto,Element.DE005);
        assertEquals(new BigDecimal("12.10"),transactionRequestDto.getSettlementAmount());
    }
    @Test
    void loadDE006(){
        isoBuffer.put(Element.DE006,"*");
        elementLoadingService.setConvertor(new Convertor());
        elementLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementLoadingService.loadDE006(isoBuffer,transactionRequestDto,Element.DE006);
        assertEquals(new BigDecimal(defaultAmount),transactionRequestDto.getBillingAmount());
        
        isoBuffer.put(Element.DE006,"000000001210");
        elementLoadingService.loadDE006(isoBuffer,transactionRequestDto,Element.DE006);
        assertEquals(new BigDecimal("12.10"),transactionRequestDto.getBillingAmount());
    }
    
    @Test
    void loadDE007(){
        String element = Element.DE007;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE007(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getTranDateTime());
        
        isoBuffer.put(element,"1019101105");
        elementLoadingService.loadDE007(isoBuffer,transactionRequestDto,element);
        assertEquals("1019101105",transactionRequestDto.getTranDateTime());
    }
    @Test
    void loadDE008(){
        String element=Element.DE008;
        isoBuffer.put(element,"*");
        elementLoadingService.setConvertor(new Convertor());
        elementLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementLoadingService.loadDE008(isoBuffer,transactionRequestDto,element);
        assertEquals(new BigDecimal(defaultAmount),transactionRequestDto.getBillingFeeAmount());
        
        isoBuffer.put(element,"000000001210");
        elementLoadingService.loadDE008(isoBuffer,transactionRequestDto,element);
        assertEquals(new BigDecimal("12.10"),transactionRequestDto.getBillingFeeAmount());
    }
    
    @Test
    void loadDE009(){
        String element = Element.DE009;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE009(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getSettlementConversionRate());
        
        isoBuffer.put(element,"0.0");
        elementLoadingService.loadDE009(isoBuffer,transactionRequestDto,element);
        assertEquals("0.0",transactionRequestDto.getSettlementConversionRate());
    }
    @Test
    void loadDE010(){
        String element = Element.DE010;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE010(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getBillingConversionRate());
        
        isoBuffer.put(element,"0.0");
        elementLoadingService.loadDE010(isoBuffer,transactionRequestDto,element);
        assertEquals("0.0",transactionRequestDto.getBillingConversionRate());
    }
    @Test
    void loadDE011(){
        String element = Element.DE011;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE011(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getStan());
        
        isoBuffer.put(element,"001568");
        elementLoadingService.loadDE011(isoBuffer,transactionRequestDto,element);
        assertEquals("001568",transactionRequestDto.getStan());
    }
    @Test
    void loadDE012(){
        String element = Element.DE012;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE012(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getLocalTime());
        
        isoBuffer.put(element,"235959");
        elementLoadingService.setConvertor(new Convertor());
        elementLoadingService.loadDE012(isoBuffer,transactionRequestDto,element);
        assertEquals("23:59:59",transactionRequestDto.getLocalTime());
    }
    @Test
    void loadDE013(){
        String element = Element.DE013;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE013(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getLocalDate());
        
        isoBuffer.put(element,"0108");
        elementLoadingService.loadDE013(isoBuffer,transactionRequestDto,element);
        assertEquals(LocalDate.of(2000, Month.JANUARY, 8),transactionRequestDto.getLocalDate());
    }
    
    @Test
    void loadDE014(){
        String element = Element.DE014;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE014(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getExpiryDate());
        
        isoBuffer.put(element,"2409");
        elementLoadingService.loadDE014(isoBuffer,transactionRequestDto,element);
        assertEquals("2409",transactionRequestDto.getExpiryDate());
    }
    @Test
    void loadDE015(){
        String element = Element.DE015;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE015(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getSettlementDate());
    
        isoBuffer.put(element,"2808");
        elementLoadingService.loadDE015(isoBuffer,transactionRequestDto,element);
        assertEquals(LocalDate.of(2028, Month.AUGUST, 1),transactionRequestDto.getSettlementDate());
    }
    @Test
    void loadDE016(){
        String element = Element.DE016;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE016(isoBuffer,transactionRequestDto,element);
        assertNotNull(transactionRequestDto.getConversionDate());
        
        isoBuffer.put(element,"2808");
        elementLoadingService.loadDE016(isoBuffer,transactionRequestDto,element);
        assertEquals(LocalDate.of(2028, Month.AUGUST, 1),transactionRequestDto.getConversionDate());
    
        isoBuffer.put(element,"0000");
        LocalDate currentdate = LocalDate.now();
        elementLoadingService.loadDE016(isoBuffer,transactionRequestDto,element);
        assertEquals(LocalDate.of(currentdate.getYear(), currentdate.getMonth(), currentdate.getDayOfMonth()),transactionRequestDto.getConversionDate());
    }
    @Test
    void loadDE017(){
        String element = Element.DE017;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE017(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getCaptureDate());
        
        isoBuffer.put(element,"2022-01-01");
        elementLoadingService.loadDE017(isoBuffer,transactionRequestDto,element);
        assertEquals(LocalDate.of(2022, Month.JANUARY, 1),transactionRequestDto.getCaptureDate());
    }
    @Test
    void loadDE018(){
        String element = Element.DE017;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE018(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getMcc());
        
        isoBuffer.put(element,"6011");
        elementLoadingService.loadDE018(isoBuffer,transactionRequestDto,element);
        assertEquals("6011",transactionRequestDto.getMcc());
    }
    @Test
    void loadDE019(){
        String element = Element.DE019;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE019(isoBuffer,transactionRequestDto,element);
        assertEquals(0,transactionRequestDto.getAcqInstCountryCode());
        
        isoBuffer.put(element,"0840");
        elementLoadingService.loadDE019(isoBuffer,transactionRequestDto,element);
        assertEquals(840,transactionRequestDto.getAcqInstCountryCode());
    }
    @Test
    void loadDE020(){
        String element = Element.DE020;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE020(isoBuffer,transactionRequestDto,element);
        assertEquals(0,transactionRequestDto.getPanExtendedCountryCode());
        
        isoBuffer.put(element,"0840");
        elementLoadingService.loadDE020(isoBuffer,transactionRequestDto,element);
        assertEquals(840,transactionRequestDto.getPanExtendedCountryCode());
    }
    @Test
    void loadDE021(){
        String element = Element.DE021;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE021(isoBuffer,transactionRequestDto,element);
        assertEquals(0,transactionRequestDto.getFwdInstCountryCode());
        
        isoBuffer.put(element,"0840");
        elementLoadingService.loadDE021(isoBuffer,transactionRequestDto,element);
        assertEquals(840,transactionRequestDto.getFwdInstCountryCode());
    }
    @Test
    void loadDE022(){
        String element = Element.DE022;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE022(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getPosEntryMode());
        
        isoBuffer.put(element,"9010");
        elementLoadingService.loadDE022(isoBuffer,transactionRequestDto,element);
        assertEquals("9010",transactionRequestDto.getPosEntryMode());
    }
    @Test
    void loadDE023(){
        String element = Element.DE023;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE023(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getCardSeqNum());
        
        isoBuffer.put(element,"0001");
        elementLoadingService.loadDE023(isoBuffer,transactionRequestDto,element);
        assertEquals("0001",transactionRequestDto.getCardSeqNum());
    }
    @Test
    void loadDE025(){
        String element = Element.DE025;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE025(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getPosConditionCode());
        
        isoBuffer.put(element,"0001");
        elementLoadingService.loadDE025(isoBuffer,transactionRequestDto,element);
        assertEquals("0001",transactionRequestDto.getPosConditionCode());
    }
    @Test
    void loadDE026(){
        String element = Element.DE026;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE026(isoBuffer,transactionRequestDto,element);
        assertEquals("NA",transactionRequestDto.getPosPinCaptureCode());
        
        isoBuffer.put(element,"0001");
        elementLoadingService.loadDE026(isoBuffer,transactionRequestDto,element);
        assertEquals("0001",transactionRequestDto.getPosPinCaptureCode());
    }
    @Test
    void loadDE027(){
        String element = Element.DE027;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE027(isoBuffer,transactionRequestDto,element);
        assertEquals("NA",transactionRequestDto.getAuthIdResp());
        
        isoBuffer.put(element,"0001");
        elementLoadingService.loadDE027(isoBuffer,transactionRequestDto,element);
        assertEquals("0001",transactionRequestDto.getAuthIdResp());
    }
    @Test
    void loadDE028(){
        String element = Element.DE028;
        isoBuffer.put(element,"*");
        elementLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementLoadingService.loadDE028(isoBuffer,transactionRequestDto,element);
        assertEquals(new BigDecimal("0.0"),transactionRequestDto.getTransactionFeeAmount());
        
        isoBuffer.put(element,"C4F0F0F0F0F0F1F0F0");
        elementLoadingService.setConvertor(new Convertor());
        elementLoadingService.loadDE028(isoBuffer,transactionRequestDto,element);
        assertEquals(new BigDecimal("100"),transactionRequestDto.getTransactionFeeAmount());
    
        isoBuffer.put(element,"C3F0F0F0F0F0F1F0F0");
        elementLoadingService.loadDE028(isoBuffer,transactionRequestDto,element);
        assertEquals(new BigDecimal("100"),transactionRequestDto.getTransactionFeeAmount());
    }
    
    @Test
    void loadDE029(){
        String element = Element.DE029;
        isoBuffer.put(element,"*");
        elementLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementLoadingService.loadDE029(isoBuffer,transactionRequestDto,element);
        assertEquals(new BigDecimal("0.0"),transactionRequestDto.getSettlementFeeAmount());
        
        isoBuffer.put(element,"000000001200");
        elementLoadingService.loadDE029(isoBuffer,transactionRequestDto,element);
        assertEquals(new BigDecimal("1200"),transactionRequestDto.getSettlementFeeAmount());
    }
    @Test
    void loadDE030(){
        String element = Element.DE030;
        isoBuffer.put(element,"*");
        elementLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementLoadingService.loadDE030(isoBuffer,transactionRequestDto,element);
        assertEquals(new BigDecimal("0.0"),transactionRequestDto.getTransactionProcessingFeeAmount());
        
        isoBuffer.put(element,"000000001200");
        elementLoadingService.loadDE030(isoBuffer,transactionRequestDto,element);
        assertEquals(new BigDecimal("1200"),transactionRequestDto.getTransactionProcessingFeeAmount());
    }
    @Test
    void loadDE031(){
        String element = Element.DE030;
        isoBuffer.put(element,"*");
        elementLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementLoadingService.loadDE031(isoBuffer,transactionRequestDto,element);
        assertEquals(new BigDecimal("0.0"),transactionRequestDto.getSettlementProcessingFeeAmount());
        
        isoBuffer.put(element,"000000001200");
        elementLoadingService.loadDE031(isoBuffer,transactionRequestDto,element);
        assertEquals(new BigDecimal("1200"),transactionRequestDto.getSettlementProcessingFeeAmount());
    }
    
    @Test
    void loadDE032(){
        String element = Element.DE032;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE032(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getAcquirerInstitutionId());
        
        isoBuffer.put(element,"0001");
        elementLoadingService.setConvertor(new Convertor());
        elementLoadingService.loadDE032(isoBuffer,transactionRequestDto,element);
        assertEquals("00000000001",transactionRequestDto.getAcquirerInstitutionId());
    }
    @Test
    void loadDE033(){
        String element = Element.DE033;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE033(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getForwardingInstIdCode());
        
        isoBuffer.put(element,"0001");
        elementLoadingService.loadDE033(isoBuffer,transactionRequestDto,element);
        assertEquals("0001",transactionRequestDto.getForwardingInstIdCode());
    }
    @Test
    void loadDE035() throws ReqInterepedException {
        String element = Element.DE035;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE035(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getCvv1());
        assertNull(transactionRequestDto.getCvv1ServiceCode());
        
        isoBuffer.put(element,"4726570100000121D300312312345123");
        DataManagingServiceImpl dataManagingService = new DataManagingServiceImpl(null);
        dataManagingService.setTpeGeneralUtil(new TPEGeneralUtil());
        elementLoadingService.setDataManagingService(dataManagingService);
        elementLoadingService.loadDE035(isoBuffer,transactionRequestDto,element);
        assertEquals("123",transactionRequestDto.getCvv1());
        assertEquals("123",transactionRequestDto.getCvv1ServiceCode());
    }
    
    @Test
    void loadDE037(){
        String element = Element.DE037;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE037(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getRrn());
        
        isoBuffer.put(element,"F2F2F8F6F0F9F0F0F1F2F3F6");
        elementLoadingService.setConvertor(new Convertor());
        elementLoadingService.loadDE037(isoBuffer,transactionRequestDto,element);
        assertEquals("228609001236",transactionRequestDto.getRrn());
    }
    
    @Test
    void loadDE038(){
        String element = Element.DE038;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE038(isoBuffer,transactionRequestDto,element);
        assertDoesNotThrow(()->{});
    }
    
    @Test
    void loadDE039(){
        String element = Element.DE039;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE039(isoBuffer,transactionRequestDto,element);
        assertDoesNotThrow(()->{});
    }
    @Test
    void loadDE041(){
        String element = Element.DE041;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE041(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getCardAcceptorTerminalId());
        
        isoBuffer.put(element,"F2F2F8F6F0F9F0F0F1F2F3F6");
        elementLoadingService.setConvertor(new Convertor());
        elementLoadingService.loadDE041(isoBuffer,transactionRequestDto,element);
        assertEquals("228609001236",transactionRequestDto.getCardAcceptorTerminalId());
    }
    @Test
    void loadDE042(){
        String element = Element.DE042;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE042(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getCardAcceptorId());
        
        isoBuffer.put(element,"F2F2F8F6F0F9F0F0F1F2F3F6");
        elementLoadingService.setConvertor(new Convertor());
        elementLoadingService.loadDE042(isoBuffer,transactionRequestDto,element);
        assertEquals("228609001236",transactionRequestDto.getCardAcceptorId());
    }
    @Test
    void loadDE043(){
        String element = Element.DE043;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE043(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getCardAcceptorTerminalLocation());
        
        isoBuffer.put(element,"F2F2F8F6F0F9F0F0F1F2F3F6");
        elementLoadingService.setConvertor(new Convertor());
        elementLoadingService.loadDE043(isoBuffer,transactionRequestDto,element);
        assertEquals("228609001236",transactionRequestDto.getCardAcceptorTerminalLocation());
    }
    @Test
    void loadDE044(){
        String element = Element.DE044;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE044(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getAdditionalData());
        
        isoBuffer.put(element,"228609001236");
        elementLoadingService.loadDE044(isoBuffer,transactionRequestDto,element);
        assertEquals("228609001236",transactionRequestDto.getAdditionalData());
    }
    @Test
    void loadDE048(){
        String element = Element.DE048;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE048(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getAdditionalDataPrivate());
        
        isoBuffer.put(element,"F2F2F8F6F0F9F0F0F1F2F3F6");
        elementLoadingService.setConvertor(new Convertor());
        elementLoadingService.loadDE048(isoBuffer,transactionRequestDto,element);
        assertEquals("228609001236",transactionRequestDto.getAdditionalDataPrivate());
    }
    @Test
    void loadDE049(){
        String element = Element.DE049;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE049(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getTransactionCurrencyCode());
        
        isoBuffer.put(element,"0356");
        elementLoadingService.loadDE049(isoBuffer,transactionRequestDto,element);
        assertEquals("0356",transactionRequestDto.getTransactionCurrencyCode());
    }
    @Test
    void loadDE050(){
        String element = Element.DE050;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE050(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getSettlementCurrencyCode());
        
        isoBuffer.put(element,"0840");
        elementLoadingService.loadDE050(isoBuffer,transactionRequestDto,element);
        assertEquals("0840",transactionRequestDto.getSettlementCurrencyCode());
    }
    @Test
    void loadDE051(){
        String element = Element.DE051;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE051(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getBillingCurrencyCode());
        
        isoBuffer.put(element,"0840");
        elementLoadingService.loadDE051(isoBuffer,transactionRequestDto,element);
        assertEquals("0840",transactionRequestDto.getBillingCurrencyCode());
    }
    @Test
    void loadDE052(){
        String element = Element.DE052;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE052(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getPinData());
        
        isoBuffer.put(element,"PINDATA");
        elementLoadingService.loadDE052(isoBuffer,transactionRequestDto,element);
        assertEquals("PINDATA",transactionRequestDto.getPinData());
    }
    @Test
    void loadDE053(){
        String element = Element.DE053;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE053(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getSecurityRelatedControlInformation());
        
        isoBuffer.put(element,"SECURITY_DATA");
        elementLoadingService.loadDE053(isoBuffer,transactionRequestDto,element);
        assertEquals("SECURITY_DATA",transactionRequestDto.getSecurityRelatedControlInformation());
    }
    @Test
    void loadDE054(){
        String element = Element.DE054;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE054(isoBuffer,transactionRequestDto,element);
        assertDoesNotThrow(()->{});
    }
    @Test
    void loadDE055() throws ReqInterepedException {
        String element = Element.DE055;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE055(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getIccRelatedData());
        
        isoBuffer.put(element,"ICC_RELATED");
        elementLoadingService.loadDE055(isoBuffer,transactionRequestDto,element);
        assertEquals("ICC_RELATED",transactionRequestDto.getIccRelatedData());
    }
    @Test
    void loadDE060(){
        String element = Element.DE060;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE060(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getVisaPosInformation());
        
        isoBuffer.put(element,"VISA_POS_INFO");
        elementLoadingService.loadDE060(isoBuffer,transactionRequestDto,element);
        assertEquals("VISA_POS_INFO",transactionRequestDto.getVisaPosInformation());
    }
    @Test
    void loadDE062(){
        String element = Element.DE062;
       /* isoBuffer.put(element,"*");
        elementLoadingService.loadDE062(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getInfData());*/
        
        isoBuffer.put(element,"40000000000000000303005354928187");
    
        InfData infData = new InfData();
        String p62Data = isoBuffer.get(element);
        String binaryData = new Convertor().parseBitmap(p62Data.substring(0, 16));
        if (binaryData.charAt(0) == '1') {
            String authCharIndicator = new Convertor().convertEBCDICHexValue(p62Data.substring(16, 18));
            infData.setAuthCharIndicator(authCharIndicator);
        }
        
        elementLoadingService.loadDE062(isoBuffer,transactionRequestDto,element);
        assertEquals("INF_DATA",transactionRequestDto.getInfData());
    }
    @Test
    void loadDE063(){
        String element = Element.DE063;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE063(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getFinancialNetworkCode());
        
        isoBuffer.put(element,"FIN_NETWORK_CODE");
        elementLoadingService.loadDE063(isoBuffer,transactionRequestDto,element);
        assertEquals("FIN_NETWORK_CODE",transactionRequestDto.getFinancialNetworkCode());
    }
    @Test
    void loadDE066(){
        String element = Element.DE066;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE066(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getSettlementCode());
        
        isoBuffer.put(element,"SETTLEMENT_CODE");
        elementLoadingService.loadDE066(isoBuffer,transactionRequestDto,element);
        assertEquals("SETTLEMENT_CODE",transactionRequestDto.getSettlementCode());
    }
    @Test
    void loadDE068(){
        String element = Element.DE068;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE068(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getReceivingInstCountryCode());
        
        isoBuffer.put(element,"0840");
        elementLoadingService.loadDE068(isoBuffer,transactionRequestDto,element);
        assertEquals("0840",transactionRequestDto.getReceivingInstCountryCode());
    }
    @Test
    void loadDE069(){
        String element = Element.DE069;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE069(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getSettlementInstCountryCode());
        
        isoBuffer.put(element,"0840");
        elementLoadingService.loadDE069(isoBuffer,transactionRequestDto,element);
        assertEquals("0840",transactionRequestDto.getSettlementInstCountryCode());
    }
    @Test
    void loadDE090(){
        String element = Element.DE090;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE090(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getOriginalDataElements());
        
        isoBuffer.put(element,"0840");
        elementLoadingService.loadDE090(isoBuffer,transactionRequestDto,element);
        assertEquals("0840",transactionRequestDto.getOriginalDataElements());
    }
    @Test
    void loadDE099(){
        String element = Element.DE099;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE099(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getSettlementInstIdCode());
        
        isoBuffer.put(element,"SETTLEMENT_ID");
        elementLoadingService.loadDE099(isoBuffer,transactionRequestDto,element);
        assertEquals("SETTLEMENT_ID",transactionRequestDto.getSettlementInstIdCode());
    }
    @Test
    void loadDE100(){
        String element = Element.DE100;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE100(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getReceivingInstIdCode());
        
        isoBuffer.put(element,"RECEIVE_ID");
        elementLoadingService.loadDE100(isoBuffer,transactionRequestDto,element);
        assertEquals("RECEIVE_ID",transactionRequestDto.getReceivingInstIdCode());
    }
    @Test
    void loadDE102(){
        String element = Element.DE102;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE102(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getAccountIdentification1());
        
        isoBuffer.put(element,"ACCOUNT_ID1");
        elementLoadingService.loadDE102(isoBuffer,transactionRequestDto,element);
        assertEquals("ACCOUNT_ID1",transactionRequestDto.getAccountIdentification1());
    }
    @Test
    void loadDE103(){
        String element = Element.DE103;
        isoBuffer.put(element,"*");
        elementLoadingService.loadDE103(isoBuffer,transactionRequestDto,element);
        assertNull(transactionRequestDto.getAccountIdentification2());
        
        isoBuffer.put(element,"ACCOUNT_ID2");
        elementLoadingService.loadDE103(isoBuffer,transactionRequestDto,element);
        assertEquals("ACCOUNT_ID2",transactionRequestDto.getAccountIdentification2());
    }
    
    @Test
    void parse55() throws ReqInterepedException {
        emvParser.setConvertor(new Convertor());
        String data55String = "0100F89F3303204000950500000400009F37049BADBCAB5F010F0102030405060708090A0B0C0D0E0F5F020F0102030405060708090A0B0C0D0E0F5F030F0102030405060708090A0B0C0D0E0F5F040F0102030405060708090A0B0C0D0E0F9F100706010A03A000009F26080123456789ABCDEF9F360200FF820200009C01019F1A0203569A030101019F02060000000123005F2A0208409F03060000000000005F050F0102030405060708090A0B0C0D0E0F5F060F0102030405060708090A0B0C0D0E0F5F070F0102030405060708090A0B0C0D0E0F5F080F0102030405060708090A0B0C0D0E0F5F090F0102030405060708090A0B0C0D0E0F";
        Map<String,String> data55= emvParser.parseField55DataVisa(data55String,null);
    
        System.out.println("data55--->" + data55);
    
    }
    
    
    
    @Test
    void parse34() throws ReqInterepedException {
        emvParser.setConvertor(new Convertor());
        String data34String = "5600179F1F0FF2F5F54BF2F5F54BF2F5F54BF2F5F5DF1F02F1F2";
        Map<String,String> data55= emvParser.parseField34DataVisa(data34String,null);
        
        System.out.println("data55--->" + data55);
        
    }
    
}