package money.open.cards.visabase;

import money.open.cards.visabase.config.VisaBaseConfig;
import money.open.cards.visabase.dto.Message;
import money.open.cards.visabase.exception.TransactionException;
import money.open.cards.visabase.exception.VisaBaseException;
import money.open.cards.visabase.service.impl.NetworkMasterServiceImpl;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.IOException;
import java.util.Hashtable;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class NetworkMasterServiceImplTest {
    
    
    @BeforeAll
    public void before() {
        MockitoAnnotations.openMocks(this);
    }
    
    @InjectMocks
    NetworkMasterServiceImpl networkMasterService;
    
    @InjectMocks
    Hashtable<String, String> isoBuffer;
    
    
    
    @Test
    void formatMessage() throws VisaBaseException, TransactionException, IOException {
        NetworkMasterServiceImpl a = new NetworkMasterServiceImpl();
        a.setVisaBaseConfig(new VisaBaseConfig());
        String t2 = "00001601020160000000000000000000000000000000000002007EFD669128E0FA1610403456789012345601100000000000400000000002500000000002500005041322406100000061000000000444184802050403090000601108400510000100C4F0F0F0F0F0F0F0F00C012345678901204034567890123456D030912312345000F2F1F2F4F1F3F0F0F0F4F4F4C1E3D4F0F1404040C3C1D9C440C1C3C3C5D7E3D6D94040C1C3D8E4C9D9C5D940D5C1D4C5404040404040404040404040C3C9E3E840D5C1D4C540404040E4E208400840084062FAF4E84B13D45D2001010100000000670100649F3303204000950500000400009F37049BADBCAB9F100C0B010A03A0B00000000000009F26080123456789ABCDEF9F360200FF820200009C01019F1A0208409A030101019F02060000000123005F2A0208409F03060000000000008407A00000000310100425000010098000000000000000E8068020000002F0";
        String t1 = "00001A810100A4117930000000010000410000000100000080000319160102008A000000117930011000498C1007010420000110722022810AC082041040394401000013170000000000000010001201071556000008034400010006476119F2F3F3F5F0F7F0F0F0F0F0F8F1F4F34BF14BF1404040E5C9E2C140C7D3D6C2C1D3F6F6F6F603440E01000B91090123456789ABCDEF001040000000000000000302335261576288";
        Message msgBuffer = new Message();
        msgBuffer.setData(t1);
        msgBuffer.setMessageStatus("RSP");
        msgBuffer.setStationName("HOST");
        // Hashtable<String, String> isoBuffer = new Hashtable<>();
        // CustomResponse customResponse = a.doSignOn(msgBuffer);
        // System.out.println(customResponse);
        VisaBaseException thrown = assertThrows(
                VisaBaseException.class,
                () -> a.doSignOn(msgBuffer),
                "Expected doSignOn() to throw, but it didn't"
        );
    
        assertTrue(thrown.getMessage().contains("TCP-IP Connection Not Available"));
    
    }
}
