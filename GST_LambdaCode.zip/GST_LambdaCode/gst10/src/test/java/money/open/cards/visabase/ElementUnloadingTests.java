package money.open.cards.visabase;

import money.open.cards.visabase.constants.Element;
import money.open.cards.visabase.dto.BalanceDetailsDto;
import money.open.cards.visabase.dto.TransactionRequestDto;
import money.open.cards.visabase.exception.ReqInterepedException;
import money.open.cards.visabase.exception.RspInterepedException;
import money.open.cards.visabase.service.impl.ElementUnLoadingServiceImpl;
import money.open.cards.visabase.service.parsor.EMVParser;
import money.open.cards.visabase.service.parsor.VisaFieldParser;
import money.open.cards.visabase.utility.Convertor;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ElementUnloadingTests {
    
    
    @BeforeAll
    public void before() {
        MockitoAnnotations.openMocks(this);
    }
    
    @InjectMocks
    ElementUnLoadingServiceImpl elementUnLoadingService;
    
    @InjectMocks
    EMVParser emvParser;
    
    @InjectMocks
    TransactionRequestDto transactionRequestDto;
    @InjectMocks
    Hashtable<String, String> isoBuffer;
    
    String defaultAmount = "0.0";
    
    
    @Test
    void loadDE002() throws RspInterepedException {
        String element = Element.DE002;
        transactionRequestDto.setCardNumber("1234512345012345");
        elementUnLoadingService.loadDE002(isoBuffer, transactionRequestDto, element);
        assertEquals("1234512345012345", isoBuffer.get(element));
    }
    @Test
    void loadDE003() {
        String element = Element.DE003;
        transactionRequestDto.setTpCode("02314012");
        elementUnLoadingService.loadDE003(isoBuffer, transactionRequestDto, element);
        assertEquals("02314012", isoBuffer.get(element));
    }
    @Test
    void loadDE004() {
        String element = Element.DE004;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
    
        transactionRequestDto.setTransactionAmount(new BigDecimal("0.0"));
        elementUnLoadingService.loadDE004(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    
        transactionRequestDto.setTransactionAmount(new BigDecimal("30.00"));
        transactionRequestDto.setTpCode("30");
        elementUnLoadingService.loadDE004(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setTransactionAmount(new BigDecimal("30.00"));
        transactionRequestDto.setTpCode("31");
        elementUnLoadingService.loadDE004(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    
        transactionRequestDto.setTransactionAmount(new BigDecimal("30.00"));
        transactionRequestDto.setTpCode("00");
        elementUnLoadingService.loadDE004(isoBuffer, transactionRequestDto, element);
        assertEquals("000000003000", isoBuffer.get(element));
    }
    @Test
    void loadDE005() {
        String element = Element.DE005;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
        
        transactionRequestDto.setSettlementAmount(new BigDecimal("0.0"));
        elementUnLoadingService.loadDE005(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setSettlementAmount(new BigDecimal("30.00"));
        transactionRequestDto.setResponseCode("00");
        elementUnLoadingService.loadDE005(isoBuffer, transactionRequestDto, element);
        assertEquals("000000003000", isoBuffer.get(element));
        
        transactionRequestDto.setTransactionAmount(new BigDecimal("30.00"));
        transactionRequestDto.setResponseCode("13");
        elementUnLoadingService.loadDE005(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    }
    @Test
    void loadDE006() {
        String element = Element.DE006;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
        
        transactionRequestDto.setBillingAmount(new BigDecimal("0.0"));
        elementUnLoadingService.loadDE006(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setBillingAmount(new BigDecimal("30.00"));
        transactionRequestDto.setPosEntryMode("00");
        elementUnLoadingService.loadDE006(isoBuffer, transactionRequestDto, element);
        assertEquals("000000003000", isoBuffer.get(element));
        
        transactionRequestDto.setBillingAmount(new BigDecimal("30.00"));
        transactionRequestDto.setPosEntryMode("05");
        elementUnLoadingService.loadDE006(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    }
    @Test
    void loadDE007() {
        String element = Element.DE007;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
        
        transactionRequestDto.setTranDateTime(null);
        elementUnLoadingService.loadDE007(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setTranDateTime("0000");
        elementUnLoadingService.loadDE007(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
    @Test
    void loadDE008() {
        String element = Element.DE008;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
        
        transactionRequestDto.setBillingFeeAmount(new BigDecimal("0.0"));
        elementUnLoadingService.loadDE008(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setBillingFeeAmount(new BigDecimal("30.00"));
        elementUnLoadingService.loadDE008(isoBuffer, transactionRequestDto, element);
        assertEquals("30.00", isoBuffer.get(element));
    }
    @Test
    void loadDE009() {
        String element = Element.DE009;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
        
        transactionRequestDto.setSettlementConversionRate(null);
        transactionRequestDto.setResponseCode("05");
        elementUnLoadingService.loadDE009(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    
        transactionRequestDto.setSettlementConversionRate(null);
        transactionRequestDto.setResponseCode("00");
        elementUnLoadingService.loadDE009(isoBuffer, transactionRequestDto, element);
        assertDoesNotThrow(()->{});
    }
    @Test
    void loadDE010() {
        String element = Element.DE010;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
        
        transactionRequestDto.setBillingConversionRate(null);
        elementUnLoadingService.loadDE010(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setBillingConversionRate("0.0");
        transactionRequestDto.setPosEntryMode("05");
        elementUnLoadingService.loadDE010(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    
        transactionRequestDto.setBillingConversionRate("0.0");
        transactionRequestDto.setPosEntryMode("06");
        elementUnLoadingService.loadDE010(isoBuffer, transactionRequestDto, element);
        assertDoesNotThrow(()->{});
    }
    @Test
    void loadDE011() {
        String element = Element.DE011;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
        
        transactionRequestDto.setStan(null);
        elementUnLoadingService.loadDE011(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setStan("0000");
        elementUnLoadingService.loadDE011(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
    @Test
    void loadDE012() {
        String element = Element.DE012;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
        
        transactionRequestDto.setPosEntryMode("07");
        elementUnLoadingService.loadDE012(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    
        transactionRequestDto.setPosEntryMode("90");
        elementUnLoadingService.loadDE012(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    
        transactionRequestDto.setPosEntryMode("05");
        elementUnLoadingService.loadDE012(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    
        transactionRequestDto.setPosEntryMode("03");
        transactionRequestDto.setLocalTime("17:46:51");
        elementUnLoadingService.loadDE012(isoBuffer, transactionRequestDto, element);
        assertEquals("174651", isoBuffer.get(element));
    
        transactionRequestDto.setPosEntryMode("03");
        transactionRequestDto.setLocalTime("174651");
        elementUnLoadingService.loadDE012(isoBuffer, transactionRequestDto, element);
        assertEquals("174651", isoBuffer.get(element));
    }
    @Test
    void loadDE013() {
        String element = Element.DE013;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
        
        transactionRequestDto.setPosEntryMode("07");
        elementUnLoadingService.loadDE013(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    
        transactionRequestDto.setPosEntryMode("90");
        elementUnLoadingService.loadDE013(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    
        transactionRequestDto.setPosEntryMode("05");
        elementUnLoadingService.loadDE013(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setPosEntryMode("03");
        DateTimeFormatter formatMMdd = new DateTimeFormatterBuilder()
                .appendPattern("MMdd")
                .parseDefaulting(ChronoField.YEAR, 2000)
                .toFormatter();
        LocalDate localDate = LocalDate.parse("1017", formatMMdd);
        transactionRequestDto.setLocalDate(localDate);
        elementUnLoadingService.loadDE013(isoBuffer, transactionRequestDto, element);
        assertEquals("1017", isoBuffer.get(element));
        
        transactionRequestDto.setPosEntryMode("03");
        transactionRequestDto.setLocalDate(null);
        elementUnLoadingService.loadDE013(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    }
    @Test
    void loadDE014() {
        String element = Element.DE014;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
        
        transactionRequestDto.setPosEntryMode("07");
        elementUnLoadingService.loadDE014(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setPosEntryMode("90");
        elementUnLoadingService.loadDE014(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setPosEntryMode("05");
        elementUnLoadingService.loadDE014(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setPosEntryMode("03");
        transactionRequestDto.setExpiryDate("0323");
        elementUnLoadingService.loadDE014(isoBuffer, transactionRequestDto, element);
        assertEquals("0323", isoBuffer.get(element));
        
        transactionRequestDto.setPosEntryMode("03");
        transactionRequestDto.setExpiryDate(null);
        elementUnLoadingService.loadDE014(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    }
    @Test
    void loadDE015() {
        String element = Element.DE015;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
        
        transactionRequestDto.setPosEntryMode("06");
        elementUnLoadingService.loadDE015(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
    @Test
    void loadDE016() {
        String element = Element.DE016;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
        
        transactionRequestDto.setResponseCode("06");
        elementUnLoadingService.loadDE016(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    
        elementUnLoadingService.loadDE016(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    
        transactionRequestDto.setResponseCode("00");
        elementUnLoadingService.loadDE016(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
    @Test
    void loadDE017() {
        String element = Element.DE017;
        elementUnLoadingService.loadDE017(isoBuffer, transactionRequestDto, element);
        assertDoesNotThrow(()->{});
    }
    @Test
    void loadDE018() {
        String element = Element.DE018;
        elementUnLoadingService.loadDE018(isoBuffer, transactionRequestDto, element);
        assertDoesNotThrow(()->{});
    }
    @Test
    void loadDE019() {
        String element = Element.DE019;
        transactionRequestDto.setAcqInstCountryCode(840);
        elementUnLoadingService.loadDE019(isoBuffer, transactionRequestDto, element);
        assertEquals("0840", isoBuffer.get(element));
    
        transactionRequestDto.setAcqInstCountryCode(0);
        elementUnLoadingService.loadDE019(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    }
    @Test
    void loadDE020() {
        String element = Element.DE020;
        transactionRequestDto.setPanExtendedCountryCode(840);
        elementUnLoadingService.loadDE020(isoBuffer, transactionRequestDto, element);
        assertEquals("0840", isoBuffer.get(element));
        
        transactionRequestDto.setPanExtendedCountryCode(0);
        elementUnLoadingService.loadDE020(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    }
    @Test
    void loadDE021() {
        String element = Element.DE021;
        transactionRequestDto.setFwdInstCountryCode(840);
        elementUnLoadingService.loadDE021(isoBuffer, transactionRequestDto, element);
        assertEquals("0840", isoBuffer.get(element));
        
        transactionRequestDto.setFwdInstCountryCode(0);
        elementUnLoadingService.loadDE021(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    }
    @Test
    void loadDE022() {
        String element = Element.DE022;
        elementUnLoadingService.loadDE022(isoBuffer, transactionRequestDto, element);
        assertDoesNotThrow(()->{});
    }
    @Test
    void loadDE023() {
        String element = Element.DE023;
        transactionRequestDto.setCardSeqNum(null);
        transactionRequestDto.setPosEntryMode("06");
        elementUnLoadingService.loadDE023(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    
        transactionRequestDto.setCardSeqNum("0000");
        transactionRequestDto.setPosEntryMode("071");
        elementUnLoadingService.loadDE023(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setCardSeqNum("0000");
        transactionRequestDto.setPosEntryMode("061");
        elementUnLoadingService.loadDE023(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
    @Test
    void loadDE025() {
        String element = Element.DE025;
        transactionRequestDto.setPosConditionCode(null);
        elementUnLoadingService.loadDE025(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setPosConditionCode("0000");
        elementUnLoadingService.loadDE025(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
    @Test
    void loadDE026() {
        String element = Element.DE026;
        transactionRequestDto.setPosPinCaptureCode("NA");
        elementUnLoadingService.loadDE026(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setPosPinCaptureCode("0000");
        elementUnLoadingService.loadDE026(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
    @Test
    void loadDE027() {
        String element = Element.DE027;
        transactionRequestDto.setAuthIdResp("NA");
        elementUnLoadingService.loadDE027(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setAuthIdResp("0000");
        elementUnLoadingService.loadDE027(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
    @Test
    void loadDE028() {
        String element = Element.DE028;
        elementUnLoadingService.loadDE028(isoBuffer, transactionRequestDto, element);
        assertDoesNotThrow(()->{});
    }
    @Test
    void loadDE029() {
        String element = Element.DE029;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        transactionRequestDto.setSettlementFeeAmount(new BigDecimal("0.0"));
        elementUnLoadingService.loadDE029(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setSettlementFeeAmount(new BigDecimal("30.00"));
        elementUnLoadingService.loadDE029(isoBuffer, transactionRequestDto, element);
        assertEquals("30.00", isoBuffer.get(element));
    }
    @Test
    void loadDE030() {
        String element = Element.DE030;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        transactionRequestDto.setTransactionProcessingFeeAmount(new BigDecimal("0.0"));
        elementUnLoadingService.loadDE030(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setTransactionProcessingFeeAmount(new BigDecimal("30.00"));
        elementUnLoadingService.loadDE030(isoBuffer, transactionRequestDto, element);
        assertEquals("30.00", isoBuffer.get(element));
    }
    @Test
    void loadDE031() {
        String element = Element.DE031;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        transactionRequestDto.setSettlementProcessingFeeAmount(new BigDecimal("0.0"));
        elementUnLoadingService.loadDE031(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setSettlementProcessingFeeAmount(new BigDecimal("30.00"));
        elementUnLoadingService.loadDE031(isoBuffer, transactionRequestDto, element);
        assertEquals("30.00", isoBuffer.get(element));
    }
    @Test
    void loadDE032() {
        String element = Element.DE032;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        transactionRequestDto.setAcquirerInstitutionId(null);
        elementUnLoadingService.loadDE032(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setAcquirerInstitutionId("1234");
        elementUnLoadingService.loadDE032(isoBuffer, transactionRequestDto, element);
        assertEquals("1234", isoBuffer.get(element));
    }
    @Test
    void loadDE033() {
        String element = Element.DE033;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        transactionRequestDto.setForwardingInstIdCode(null);
        elementUnLoadingService.loadDE033(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setForwardingInstIdCode("1234");
        elementUnLoadingService.loadDE033(isoBuffer, transactionRequestDto, element);
        assertEquals("1234", isoBuffer.get(element));
    }
    @Test
    void loadDE035() {
        String element = Element.DE035;
        elementUnLoadingService.loadDE035(isoBuffer, transactionRequestDto, element);
        assertDoesNotThrow(()->{});
    }
    @Test
    void loadDE037() {
        String element = Element.DE037;
        transactionRequestDto.setRrn("1234");
        elementUnLoadingService.setConvertor(new Convertor());
        elementUnLoadingService.loadDE037(isoBuffer, transactionRequestDto, element);
        assertEquals("F1F2F3F4", isoBuffer.get(element));
    }
    @Test
    void loadDE038() {
        String element = Element.DE038;
        transactionRequestDto.setRrn("123456");
        transactionRequestDto.setResponseCode("00");
        elementUnLoadingService.setConvertor(new Convertor());
        elementUnLoadingService.loadDE038(isoBuffer, transactionRequestDto, element);
        assertEquals("F1F2F3F4F5F6", isoBuffer.get(element));
    }
    @Test
    void loadDE039() {
        String element = Element.DE039;
        transactionRequestDto.setResponseCode("00");
        elementUnLoadingService.setConvertor(new Convertor());
        elementUnLoadingService.loadDE039(isoBuffer, transactionRequestDto, element);
        assertEquals("F0F0", isoBuffer.get(element));
    }
    @Test
    void loadDE041() {
        String element = Element.DE041;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
        transactionRequestDto.setCardAcceptorTerminalId(null);
        elementUnLoadingService.loadDE041(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setCardAcceptorTerminalId("1234");
        elementUnLoadingService.loadDE041(isoBuffer, transactionRequestDto, element);
        assertEquals("F1F2F3F4", isoBuffer.get(element));
    }
    @Test
    void loadDE042() {
        String element = Element.DE042;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
        transactionRequestDto.setCardAcceptorId(null);
        elementUnLoadingService.loadDE042(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setCardAcceptorId("1234");
        elementUnLoadingService.loadDE042(isoBuffer, transactionRequestDto, element);
        assertEquals("F1F2F3F4", isoBuffer.get(element));
    }
    @Test
    void loadDE043() {
        String element = Element.DE043;
        elementUnLoadingService.loadDE043(isoBuffer, transactionRequestDto, element);
        assertDoesNotThrow(()->{});
    }
    @Test
    void loadDE044() throws RspInterepedException {
        String element = Element.DE044;
        elementUnLoadingService.loadDE044(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        Convertor convertor = new Convertor();
        elementUnLoadingService.setConvertor(convertor);
        VisaFieldParser visaFieldParser = new VisaFieldParser();
        visaFieldParser.setConvertor(new Convertor());
        elementUnLoadingService.setVisaFieldParser(visaFieldParser);
        //Case 1 - cvv2 is space
        transactionRequestDto.setChipTxn(true);
        transactionRequestDto.setResponseCode("00");
        transactionRequestDto.setAdditionalData("not null");
        elementUnLoadingService.loadDE044(isoBuffer, transactionRequestDto, element);
        assertEquals(convertor.convertToEBSDICHEXValue("5   1   1 P   0"), isoBuffer.get(element));
    
        // case 2 cvv2 is 1
        transactionRequestDto.setChipTxn(true);
        transactionRequestDto.setResponseCode("00");
        
        transactionRequestDto.setAdditionalData("not null");
        elementUnLoadingService.loadDE044(isoBuffer, transactionRequestDto, element);
        assertEquals(convertor.convertToEBSDICHEXValue("5   1   1 N   0"), isoBuffer.get(element));
    
        // case 3 cvv2 is 2
        transactionRequestDto.setChipTxn(true);
        transactionRequestDto.setResponseCode("00");
        
        transactionRequestDto.setAdditionalData("not null");
        elementUnLoadingService.loadDE044(isoBuffer, transactionRequestDto, element);
        assertEquals(convertor.convertToEBSDICHEXValue("5   1   1 M   0"), isoBuffer.get(element));
    
        // case 4 arqc 0 cvv2 is 1
        transactionRequestDto.setChipTxn(true);
        transactionRequestDto.setResponseCode("00");
        
        transactionRequestDto.setAdditionalData("not null");
        elementUnLoadingService.loadDE044(isoBuffer, transactionRequestDto, element);
        assertEquals(convertor.convertToEBSDICHEXValue("5   1     M   0"), isoBuffer.get(element));
    
        // case 4 arqc 0 cvv2 is 1
        transactionRequestDto.setChipTxn(true);
        transactionRequestDto.setResponseCode("00");
        
        transactionRequestDto.setAdditionalData("not null");
        elementUnLoadingService.loadDE044(isoBuffer, transactionRequestDto, element);
        assertEquals(convertor.convertToEBSDICHEXValue("5U  1     M   0"), isoBuffer.get(element));
    
        // case 5 arqc 0 cvvresultRequired is false
        transactionRequestDto.setChipTxn(true);
        transactionRequestDto.setResponseCode("00");
        
        transactionRequestDto.setAdditionalData("not null");
        elementUnLoadingService.loadDE044(isoBuffer, transactionRequestDto, element);
        assertEquals(convertor.convertToEBSDICHEXValue("5U  1     P   0"), isoBuffer.get(element));
    
        // case 6 arqc 0 getCvv2Response is DEFAULT
        transactionRequestDto.setChipTxn(true);
        transactionRequestDto.setResponseCode("00");
        
        transactionRequestDto.setAdditionalData("not null");
        elementUnLoadingService.loadDE044(isoBuffer, transactionRequestDto, element);
        assertEquals(convertor.convertToEBSDICHEXValue("5U  1     P   0"), isoBuffer.get(element));
    
        // case 6 arqc 0 setCavvStatusCode is empty
        transactionRequestDto.setChipTxn(true);
        transactionRequestDto.setResponseCode("00");
        
        transactionRequestDto.setAdditionalData("not null");
        elementUnLoadingService.loadDE044(isoBuffer, transactionRequestDto, element);
        assertEquals(convertor.convertToEBSDICHEXValue("5U  1     P   0"), isoBuffer.get(element));
    }
    @Test
    void loadDE049() {
        String element = Element.DE049;
        elementUnLoadingService.setDefaultAmount(new BigDecimal(defaultAmount));
        elementUnLoadingService.setConvertor(new Convertor());
        transactionRequestDto.setTransactionCurrencyCode(null);
        elementUnLoadingService.loadDE049(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setTransactionCurrencyCode("0356");
        elementUnLoadingService.loadDE049(isoBuffer, transactionRequestDto, element);
        assertEquals("0356", isoBuffer.get(element));
    }
    @Test
    void loadDE050() {
        String element = Element.DE050;
        transactionRequestDto.setSettlementCurrencyCode(null);
        transactionRequestDto.setResponseCode("06");
        elementUnLoadingService.loadDE050(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setSettlementCurrencyCode("0356");
        transactionRequestDto.setResponseCode("06");
        elementUnLoadingService.loadDE050(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setSettlementCurrencyCode("0356");
        transactionRequestDto.setResponseCode("00");
        elementUnLoadingService.loadDE050(isoBuffer, transactionRequestDto, element);
        assertEquals("0356", isoBuffer.get(element));
    
        transactionRequestDto.setSettlementCurrencyCode(null);
        transactionRequestDto.setResponseCode("00");
        elementUnLoadingService.loadDE050(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    }
    @Test
    void loadDE051() {
        String element = Element.DE051;
        transactionRequestDto.setBillingCurrencyCode(null);
        transactionRequestDto.setPosEntryMode("05");
        elementUnLoadingService.loadDE051(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setBillingCurrencyCode("0356");
        transactionRequestDto.setPosEntryMode("05");
        elementUnLoadingService.loadDE051(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setBillingCurrencyCode("0356");
        transactionRequestDto.setPosEntryMode("06");
        elementUnLoadingService.loadDE051(isoBuffer, transactionRequestDto, element);
        assertEquals("0356", isoBuffer.get(element));
        
        transactionRequestDto.setBillingCurrencyCode(null);
        transactionRequestDto.setPosEntryMode("06");
        elementUnLoadingService.loadDE051(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    }
    @Test
    void loadDE052() {
        String element = Element.DE052;
        elementUnLoadingService.loadDE052(isoBuffer, transactionRequestDto, element);
        assertDoesNotThrow(()->{});
    }
    @Test
    void loadDE053() {
        String element = Element.DE053;
        elementUnLoadingService.loadDE053(isoBuffer, transactionRequestDto, element);
        assertDoesNotThrow(()->{});
    }
    @Test
    void loadDE054() throws RspInterepedException {
        String element = Element.DE054;
        Convertor convertor = new Convertor();
        elementUnLoadingService.setConvertor(convertor);
        transactionRequestDto.setTpCode("30");
        StringBuilder additionalData = new StringBuilder();
        List<BalanceDetailsDto> balance = new ArrayList<>();
        BalanceDetailsDto balanceDetailsDto = new BalanceDetailsDto();
        balanceDetailsDto.setAccountType("00");
        balanceDetailsDto.setAmountType("01");
        balanceDetailsDto.setCurrencyCode("840");
        balanceDetailsDto.setSignAmount('C');
        balanceDetailsDto.setAvailableBalance(new BigDecimal("97329.0000"));
        balance.add(balanceDetailsDto);
        transactionRequestDto.setBalanceDetails(balance);
        for (BalanceDetailsDto data: balance) {
            additionalData.append(data.getAccountType());
            additionalData.append(data.getAmountType());
            additionalData.append(data.getCurrencyCode());
            additionalData.append(data.getSignAmount());
            additionalData.append(convertor.convertBigDecimalToString(data.getAvailableBalance()));
        }
        isoBuffer.put(element,convertor.convertToEBSDICHEXValue(additionalData.toString()));
        elementUnLoadingService.loadDE054(isoBuffer, transactionRequestDto, element);
        assertEquals(convertor.convertToEBSDICHEXValue("0001840C00000973290000"), isoBuffer.get(element));
    
        transactionRequestDto.setTpCode("00");
        elementUnLoadingService.loadDE054(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    }
    @Test
    void loadDE055() throws ReqInterepedException, RspInterepedException {
        String element = Element.DE055;
        EMVParser emvParser = new EMVParser();
        emvParser.setConvertor(new Convertor());
        elementUnLoadingService.setEmvParser(emvParser);
        elementUnLoadingService.setConvertor(new Convertor());
        transactionRequestDto.setIccRelatedData(null);
        elementUnLoadingService.loadDE055(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    
        String data55String = "0100F89F3303204000950500000400009F37049BADBCAB5F010F0102030405060708090A0B0C0D0E0F5F020F0102030405060708090A0B0C0D0E0F5F030F0102030405060708090A0B0C0D0E0F5F040F0102030405060708090A0B0C0D0E0F9F100706010A03A000009F26080123456789ABCDEF9F360200FF820200009C01019F1A0203569A030101019F02060000000123005F2A0208409F03060000000000005F050F0102030405060708090A0B0C0D0E0F5F060F0102030405060708090A0B0C0D0E0F5F070F0102030405060708090A0B0C0D0E0F5F080F0102030405060708090A0B0C0D0E0F5F090F0102030405060708090A0B0C0D0E0F";
        transactionRequestDto.setSecurityInfo("NNNYNN");
        //transactionRequestDto.setIccRelatedData(data55String);
        elementUnLoadingService.loadDE055(isoBuffer, transactionRequestDto, element);
        assertEquals(data55String, isoBuffer.get(element));
    
        transactionRequestDto.setSecurityInfo("NNNNNN");
        //transactionRequestDto.setIccRelatedData(data55String);
        elementUnLoadingService.loadDE055(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
    
    }
    @Test
    void loadDE060() {
        String element = Element.DE060;
        elementUnLoadingService.loadDE060(isoBuffer, transactionRequestDto, element);
        assertDoesNotThrow(()->{});
    }
    @Test
    void loadDE062() throws ReqInterepedException, NoSuchAlgorithmException, RspInterepedException {
        String element = Element.DE062;
        Convertor convertor = new Convertor();
        elementUnLoadingService.setConvertor(convertor);
        VisaFieldParser visaFieldParser = new VisaFieldParser();
        visaFieldParser.setConvertor(new Convertor());
        elementUnLoadingService.setVisaFieldParser(visaFieldParser);
        transactionRequestDto.setInfData(null);
        elementUnLoadingService.loadDE062(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        String data62String1 = "C000000000000000E80000000000000000";
        //transactionRequestDto.setInfData(data62String1);
        transactionRequestDto.setPosEntryMode("90");
        elementUnLoadingService.loadDE062(isoBuffer, transactionRequestDto, element);
        assertEquals(data62String1, isoBuffer.get(element));
    
        String data62String2 = "C000000000000000E80000000000000000";
        //transactionRequestDto.setInfData(data62String2);
        transactionRequestDto.setPosEntryMode("07");
        elementUnLoadingService.loadDE062(isoBuffer, transactionRequestDto, element);
        assertEquals(data62String2, isoBuffer.get(element));
    
        //transactionRequestDto.setInfData(data62String2);
        transactionRequestDto.setPosEntryMode("09");
        elementUnLoadingService.loadDE062(isoBuffer, transactionRequestDto, element);
        assertEquals(data62String2, isoBuffer.get(element));
    }
    @Test
    void loadDE063() throws RspInterepedException {
        String element = Element.DE063;
        Convertor convertor = new Convertor();
        elementUnLoadingService.setConvertor(convertor);
        VisaFieldParser visaFieldParser = new VisaFieldParser();
        visaFieldParser.setConvertor(new Convertor());
        elementUnLoadingService.setVisaFieldParser(visaFieldParser);
        transactionRequestDto.setFinancialNetworkCode(null);
        elementUnLoadingService.loadDE063(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setFinancialNetworkCode("0001");
        transactionRequestDto.setPosEntryMode("90");
        Hashtable<String, String> field63 = new Hashtable();
		field63.put("DE063.0", "24");
		field63.put("DE063.1", "0002");
		field63.put("DE063.19", convertor.convertToEBSDICHEXValue("ZZZ"));
    
        System.out.println(visaFieldParser.field63Reverseparser(field63));

        isoBuffer.put(element, visaFieldParser.field63Reverseparser(field63));
        //elementUnLoadingService.loadDE063(isoBuffer, transactionRequestDto, element);
        //assertEquals(visaFieldParser.field63Reverseparser(field63), isoBuffer.get(element));
        
       
    }
    @Test
    void loadDE066() {
        String element = Element.DE066;
        transactionRequestDto.setSettlementCode("NA");
        elementUnLoadingService.loadDE066(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setSettlementCode("0000");
        elementUnLoadingService.loadDE066(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
    @Test
    void loadDE068() {
        String element = Element.DE068;
        transactionRequestDto.setReceivingInstCountryCode("NA");
        elementUnLoadingService.loadDE068(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setReceivingInstCountryCode("0000");
        elementUnLoadingService.loadDE068(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
    @Test
    void loadDE069() {
        String element = Element.DE069;
        transactionRequestDto.setSettlementInstCountryCode("NA");
        elementUnLoadingService.loadDE069(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setSettlementInstCountryCode("0000");
        elementUnLoadingService.loadDE069(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
    @Test
    void loadDE090() {
        String element = Element.DE090;
        transactionRequestDto.setOriginalDataElements(null);
        elementUnLoadingService.loadDE090(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setOriginalDataElements("0000");
        elementUnLoadingService.loadDE090(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
    @Test
    void loadDE099() {
        String element = Element.DE099;
        transactionRequestDto.setSettlementInstIdCode("NA");
        elementUnLoadingService.loadDE099(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setSettlementInstIdCode("0000");
        elementUnLoadingService.loadDE099(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
    @Test
    void loadDE100() {
        String element = Element.DE100;
        transactionRequestDto.setReceivingInstIdCode("NA");
        elementUnLoadingService.loadDE100(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setReceivingInstIdCode("0000");
        elementUnLoadingService.loadDE100(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
    @Test
    void loadDE102() {
        String element = Element.DE102;
        transactionRequestDto.setAccountIdentification1("NA");
        elementUnLoadingService.loadDE102(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setAccountIdentification1("0000");
        elementUnLoadingService.loadDE102(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
    @Test
    void loadDE103() {
        String element = Element.DE103;
        transactionRequestDto.setAccountIdentification2("NA");
        elementUnLoadingService.loadDE103(isoBuffer, transactionRequestDto, element);
        assertEquals("*", isoBuffer.get(element));
        
        transactionRequestDto.setAccountIdentification2("0000");
        elementUnLoadingService.loadDE103(isoBuffer, transactionRequestDto, element);
        assertEquals("0000", isoBuffer.get(element));
    }
}
