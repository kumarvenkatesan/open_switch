package money.open.cards.visabase;

import money.open.cards.visabase.dto.Message;
import money.open.cards.visabase.dto.TransactionRequestDto;
import money.open.cards.visabase.exception.ReqInterepedException;
import money.open.cards.visabase.exception.TransactionException;
import money.open.cards.visabase.service.impl.DataManagingServiceImpl;
import money.open.cards.visabase.service.impl.ElementUnLoadingServiceImpl;
import money.open.cards.visabase.service.impl.VISAProcessAPIImpl;
import money.open.cards.visabase.service.impl.VisaFormatterImpl;
import money.open.cards.visabase.utility.Convertor;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.Hashtable;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class VISAProcessAPIImplTest {
    
    
    @BeforeAll
    public void before() {
        MockitoAnnotations.openMocks(this);
    }
    
    @InjectMocks
    VISAProcessAPIImpl visaProcessAPI;
    
    @InjectMocks
    VisaFormatterImpl visaFormatter;
    
    @InjectMocks
    DataManagingServiceImpl dataManagingService;
    
    @InjectMocks
    TransactionRequestDto transactionRequestDto;
    @InjectMocks
    Hashtable<String, String> isoBuffer;
    
    String defaultAmount = "0.0";
    
    
    @Test
    void loadPrimaryElements() throws TransactionException, ReqInterepedException {
        Message msgBuffer = new Message();
        msgBuffer.setData("000016010201EF00000000000000000000000000000000A102007EFD649128E1F8161047265701000001210100000000000021000000000250000000000250001114093616610000006100000000165015061611143003000060110356901002C4F0F0F0F0F0F1F0F006472657204726570100000121D300320612345639F2F3F1F8F0F9F0F0F1F6F5F0C1E3D4F0F1404040C3C1D9C440C1C3C3C5D7E3D6D94040E3C5E2E340E3D9C1D5E2C1C3E3C9D6D5404040404040404040C3C9E3E840D5C1D4C540404040E4E2FF5CC6C9C5D3C440F4F840E4E2C1C7C540F240C4C1E3C140E6C9E3C840D4C1E7C9D4E4D440D3C5D5C7E3C840F2F5F540C2E8E3C5E2406040F5F740F6F040F6F340F6F640F6F940F7F240F7F540F7F840F8F140F8F440F8F740F9F040F9F340F9F640F9F940F1F0F340F1F0F740F1F1F140F1F1F540F1F1F940F1F2F340F1F2F740F1F3F140F1F3F540F1F3F940F1F4F340F1F4F740F1F5F140F1F5F540F1F5F940F1F6F340F1F6F740F1F7F140F1F7F540F1F7F940F1F8F340F1F8F740F1F9F140F1F9F540F1F9F940F2F0F340F2F0F740F2F1F140F2F1F540F2F1F940F2F2F340F2F2F740F2F3F140F2F3F540F2F3F940F2F4F340F2F4F740F2F5F140F2F5F50356084008401C10FD3330EA73C620010101000000000122098000000000000000E8058000000002");
        msgBuffer.setMessageStatus("REQ");
        msgBuffer.setStationName("HOST");
        msgBuffer.setStationCode("VI");
        Convertor convertor = new Convertor();
        visaProcessAPI.setConvertor(convertor);
        visaFormatter.setConvertor(convertor);
        visaProcessAPI.setElementUnLoadingService(new ElementUnLoadingServiceImpl());
        transactionRequestDto.setMti("0200");
        transactionRequestDto.setCardNumber("1234512345123456");
        int[] mandatoryLoad = dataManagingService.getMandatoryBit(transactionRequestDto.getMti());
        msgBuffer.setData(convertor.alpha2Hex(msgBuffer.getData()));
        isoBuffer = visaFormatter.formatMessage(msgBuffer, isoBuffer);
        assertDoesNotThrow(()->visaFormatter.formatMessage(msgBuffer, isoBuffer));
        // visaProcessAPI.loadPrimaryElements(isoBuffer,transactionRequestDto,mandatoryLoad);
    }
    
    
}

