package money.open.cards.visabase;

import money.open.cards.visabase.constants.Element;
import money.open.cards.visabase.dto.Message;
import money.open.cards.visabase.dto.TransactionRequestDto;
import money.open.cards.visabase.exception.TransactionException;
import money.open.cards.visabase.exception.VisaBaseException;
import money.open.cards.visabase.service.impl.VisaFormatterImpl;
import money.open.cards.visabase.service.parsor.EMVParser;
import money.open.cards.visabase.utility.Convertor;
import money.open.cards.visabase.utility.LogUtils;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.math.BigInteger;
import java.util.Hashtable;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class VisaFormatterImplTest {
    
    
    @BeforeAll
    public void before() {
        MockitoAnnotations.openMocks(this);
    }
    
    @InjectMocks
    VisaFormatterImpl visaFormatter;
    
    @InjectMocks
    EMVParser emvParser;
    
    @InjectMocks
    TransactionRequestDto transactionRequestDto;
    @InjectMocks
    Hashtable<String, String> isoBuffer;
    
    String defaultAmount = "0.0";
    
    
    @Test
    void headerFormat() {
        String reserveField1="16010201D300000000000000000000000000000000B9";
        visaFormatter.headerFormat(reserveField1,isoBuffer);
        assertEquals("16", isoBuffer.get(Element.H01));
    }
    @Test
    void buildHeader() {
        String reserveField1="16010201D300000000000000000000000000000000B9";
        visaFormatter.headerFormat(reserveField1,isoBuffer);
        assertEquals("000016010201D300000000000000000000000000000000B9", visaFormatter.buildHeader(isoBuffer));
    }
    
    @Test
    void testARQC()
    {
        String hexValue="02FF";
        Convertor convertor = new Convertor();
        int decimalValue=convertor.hex2decimal(hexValue);
        String convertedString = this.formatToEven(decimalValue);
        String convertedLength=convertor.paddingZeroPrefix(String.valueOf(convertedString.length()/2),convertedString.length()/2);
        System.out.println(convertedLength+convertedString);
    }
    
    @Test
    void convertStringToHex()
    {
        String stringValue = "00";
        Convertor convertor = new Convertor();
        System.out.println(convertor.alpha2Hex(stringValue));
    }
    
    
    public String formatToEven(int decimalValue)
    {
        String value="";
        if(decimalValue%2!=0)
            value="0"+decimalValue;
        else
            value=""+decimalValue;
        return value;
    }
    
    
    
    
    
    @Test
    void formatTest() throws VisaBaseException,TransactionException {
        
        VisaFormatterImpl a = new VisaFormatterImpl();
        String t1 = "0000160102013E117930000000011000498C100F0104EA000100F67E648108F0A11600000000000200041047265701000019050000000000000050000000000532991213113029510659800024191700291213300412145972034401200806476119F2F3F4F7F1F1F0F0F2F4F1F9E3C5D9D4C9C4F0F1C3C1D9C440C1C3C3C5D7E3D6D94040E3C5E2E340E3D9C1D5E2C1C3E3C9D6D5404040404040404040C3C9E3E840D5C1D4C540404040C9D50B40404040404040404040D5034403562201001F011DE5F0F0F1F0F0F1F3F0F2F2F3F0F8F3F3F2F5F4F1F9F2F7F6F7F5F5F0F2010015400010000000000003023474143065680000530000058000000002003101002E8018E589A28140C995834B6B40C5A783888195878540D981A3858105C1F0F4F3F18208F4F0F1F0F6F5F9F88E01F10E0040000000000000F1F140F8F9F6";
        //String t1 = "00001601020160000000000000000000000000000000000002007EFD669128E0FA1610403456789012345601100000000000400000000002500000000002500005041322406100000061000000000444184802050403090000601108400510000100C4F0F0F0F0F0F0F0F00C012345678901204034567890123456D030912312345000F2F1F2F4F1F3F0F0F0F4F4F4C1E3D4F0F1404040C3C1D9C440C1C3C3C5D7E3D6D94040C1C3D8E4C9D9C5D940D5C1D4C5404040404040404040404040C3C9E3E840D5C1D4C540404040E4E208400840084062FAF4E84B13D45D2001010100000000670100649F3303204000950500000400009F37049BADBCAB9F100C0B010A03A0B00000000000009F26080123456789ABCDEF9F360200FF820200009C01019F1A0208409A030101019F02060000000123005F2A0208409F03060000000000008407A00000000310100425000010098000000000000000E8068020000002F0";
        System.out.println(t1.substring(70,86));
        a.setConvertor(new Convertor());
        Message msgBuffer = new Message();
        msgBuffer.setData(t1);
        msgBuffer.setMessageStatus("RSP");
        msgBuffer.setStationName("HOST");
        Hashtable<String, String> isoBuffer = new Hashtable<>();
        isoBuffer = a.formatMessage(msgBuffer,isoBuffer);
        LogUtils log = new LogUtils();
        log.setConvertor(new Convertor());
        log.writeRequestLog("REQ",isoBuffer);
        String asdf = a.buildISOMessage(isoBuffer,false);
        System.out.println(asdf);
        Hashtable<String, String> finalIsoBuffer1 = isoBuffer;
        System.out.println(a.formatMessage(msgBuffer, finalIsoBuffer1));
        
    }
    @Test
    @Disabled("TODO: Still need to work on it")
    void formatMessage() throws VisaBaseException, TransactionException {
        VisaFormatterImpl a = new VisaFormatterImpl();
        String t1 = "00001601020160000000000000000000000000000000000002007EFD669128E0FA1610403456789012345601100000000000400000000002500000000002500005041322406100000061000000000444184802050403090000601108400510000100C4F0F0F0F0F0F0F0F00C012345678901204034567890123456D030912312345000F2F1F2F4F1F3F0F0F0F4F4F4C1E3D4F0F1404040C3C1D9C440C1C3C3C5D7E3D6D94040C1C3D8E4C9D9C5D940D5C1D4C5404040404040404040404040C3C9E3E840D5C1D4C540404040E4E208400840084062FAF4E84B13D45D2001010100000000670100649F3303204000950500000400009F37049BADBCAB9F100C0B010A03A0B00000000000009F26080123456789ABCDEF9F360200FF820200009C01019F1A0208409A030101019F02060000000123005F2A0208409F03060000000000008407A00000000310100425000010098000000000000000E8068020000002F0";
        a.setConvertor(new Convertor());
        Message msgBuffer = new Message();
        msgBuffer.setData(t1);
        msgBuffer.setMessageStatus("RSP");
        msgBuffer.setStationName("HOST");
        Hashtable<String, String> isoBuffer = new Hashtable<>();
        isoBuffer = a.formatMessage(msgBuffer,isoBuffer);
        isoBuffer.put(Element.DE102,"0000");
        String asdf = a.buildISOMessage(isoBuffer,true);
        System.out.println(asdf);
        Hashtable<String, String> finalIsoBuffer1 = isoBuffer;
        assertDoesNotThrow(()->a.formatMessage(msgBuffer, finalIsoBuffer1));
    
        String t2 = "0000160102016B00000000000000000000000000000000000200FEFD669128E0FA16000000000400000010403456789012345601100000000000400000000002500000000002500005041322406100000061000000000444184802050403090000601108400510000100C4F0F0F0F0F0F0F0F00C012345678901204034567890123456D030912312345000F2F1F2F4F1F3F0F0F0F4F4F4C1E3D4F0F1404040C3C1D9C440C1C3C3C5D7E3D6D94040C1C3D8E4C9D9C5D940D5C1D4C5404040404040404040404040C3C9E3E840D5C1D4C540404040E4E208400840084062FAF4E84B13D45D2001010100000000670100649F3303204000950500000400009F37049BADBCAB9F100C0B010A03A0B00000000000009F26080123456789ABCDEF9F360200FF820200009C01019F1A0208409A030101019F02060000000123005F2A0208409F03060000000000008407A00000000310100425000010098000000000000000E8068020000002F0020000";
    
        msgBuffer.setData(t2);
        msgBuffer.setMessageStatus("RSP");
        msgBuffer.setStationName("HOST");
        isoBuffer = a.formatMessage(msgBuffer,isoBuffer);
        // isoBuffer.put(Element.DE102,"0000");
        Hashtable<String, String> finalIsoBuffer = isoBuffer;
        assertDoesNotThrow(()->a.formatMessage(msgBuffer, finalIsoBuffer));
    }
    @Test
    @Disabled("TODO: Still need to work on it")
    void doSignOn() throws TransactionException {
        VisaFormatterImpl a = new VisaFormatterImpl();
        String t1 = "00001601020160000000000000000000000000000000000002007EFD669128E0FA1610403456789012345601100000000000400000000002500000000002500005041322406100000061000000000444184802050403090000601108400510000100C4F0F0F0F0F0F0F0F00C012345678901204034567890123456D030912312345000F2F1F2F4F1F3F0F0F0F4F4F4C1E3D4F0F1404040C3C1D9C440C1C3C3C5D7E3D6D94040C1C3D8E4C9D9C5D940D5C1D4C5404040404040404040404040C3C9E3E840D5C1D4C540404040E4E208400840084062FAF4E84B13D45D2001010100000000670100649F3303204000950500000400009F37049BADBCAB9F100C0B010A03A0B00000000000009F26080123456789ABCDEF9F360200FF820200009C01019F1A0208409A030101019F02060000000123005F2A0208409F03060000000000008407A00000000310100425000010098000000000000000E8068020000002F0";
        a.setConvertor(new Convertor());
        Message msgBuffer = new Message();
        msgBuffer.setData(t1);
        msgBuffer.setMessageStatus("RSP");
        msgBuffer.setStationName("HOST");
        Hashtable<String, String> isoBuffer = new Hashtable<>();
        isoBuffer = a.formatMessage(msgBuffer,isoBuffer);
        isoBuffer.put(Element.DE102,"0000");
        String asdf = a.doSignOnMessage(isoBuffer);
        System.out.println(asdf);
        Hashtable<String, String> finalIsoBuffer1 = isoBuffer;
        assertDoesNotThrow(()->a.formatMessage(msgBuffer, finalIsoBuffer1));
    }
    @Test
    @Disabled("TODO: Still need to work on it")
    void doTransactionMessage() throws TransactionException {
        VisaFormatterImpl a = new VisaFormatterImpl();
        String t1 = "00001601020160000000000000000000000000000000000002007EFD669128E0FA1610403456789012345601100000000000400000000002500000000002500005041322406100000061000000000444184802050403090000601108400510000100C4F0F0F0F0F0F0F0F00C012345678901204034567890123456D030912312345000F2F1F2F4F1F3F0F0F0F4F4F4C1E3D4F0F1404040C3C1D9C440C1C3C3C5D7E3D6D94040C1C3D8E4C9D9C5D940D5C1D4C5404040404040404040404040C3C9E3E840D5C1D4C540404040E4E208400840084062FAF4E84B13D45D2001010100000000670100649F3303204000950500000400009F37049BADBCAB9F100C0B010A03A0B00000000000009F26080123456789ABCDEF9F360200FF820200009C01019F1A0208409A030101019F02060000000123005F2A0208409F03060000000000008407A00000000310100425000010098000000000000000E8068020000002F0";
        a.setConvertor(new Convertor());
        Message msgBuffer = new Message();
        msgBuffer.setData(t1);
        msgBuffer.setMessageStatus("RSP");
        msgBuffer.setStationName("HOST");
        Hashtable<String, String> isoBuffer = new Hashtable<>();
        isoBuffer = a.formatMessage(msgBuffer,isoBuffer);
        isoBuffer.put(Element.DE102,"0000");
        String asdf = a.doTransactionMessage(isoBuffer);
        System.out.println(asdf);
        Hashtable<String, String> finalIsoBuffer1 = isoBuffer;
        assertDoesNotThrow(()->a.formatMessage(msgBuffer, finalIsoBuffer1));
    }
    @Test
    @Disabled("TODO: Still need to work on it")
    void buildISOMessage() throws TransactionException {
        VisaFormatterImpl a = new VisaFormatterImpl();
        String t1 = "00001601020160000000000000000000000000000000000002007EFD669128E0FA1610403456789012345601100000000000400000000002500000000002500005041322406100000061000000000444184802050403090000601108400510000100C4F0F0F0F0F0F0F0F00C012345678901204034567890123456D030912312345000F2F1F2F4F1F3F0F0F0F4F4F4C1E3D4F0F1404040C3C1D9C440C1C3C3C5D7E3D6D94040C1C3D8E4C9D9C5D940D5C1D4C5404040404040404040404040C3C9E3E840D5C1D4C540404040E4E208400840084062FAF4E84B13D45D2001010100000000670100649F3303204000950500000400009F37049BADBCAB9F100C0B010A03A0B00000000000009F26080123456789ABCDEF9F360200FF820200009C01019F1A0208409A030101019F02060000000123005F2A0208409F03060000000000008407A00000000310100425000010098000000000000000E8068020000002F0";
        a.setConvertor(new Convertor());
        Message msgBuffer = new Message();
        msgBuffer.setData(t1);
        msgBuffer.setMessageStatus("RSP");
        msgBuffer.setStationName("HOST");
        Hashtable<String, String> isoBuffer = new Hashtable<>();
        isoBuffer = a.formatMessage(msgBuffer,isoBuffer);
        isoBuffer.put(Element.DE102,"0000");
        String asdf = a.buildMessage(isoBuffer);
        System.out.println(asdf);
        Hashtable<String, String> finalIsoBuffer1 = isoBuffer;
        assertDoesNotThrow(()->a.formatMessage(msgBuffer, finalIsoBuffer1));
    }
    
    @Test
    @Disabled("TODO: Still need to work on it")
    void buildISOErrorMessage() throws TransactionException {
        VisaFormatterImpl a = new VisaFormatterImpl();
        String t1 = "00001601020160000000000000000000000000000000000002007EFD669128E0FA1610403456789012345601100000000000400000000002500000000002500005041322406100000061000000000444184802050403090000601108400510000100C4F0F0F0F0F0F0F0F00C012345678901204034567890123456D030912312345000F2F1F2F4F1F3F0F0F0F4F4F4C1E3D4F0F1404040C3C1D9C440C1C3C3C5D7E3D6D94040C1C3D8E4C9D9C5D940D5C1D4C5404040404040404040404040C3C9E3E840D5C1D4C540404040E4E208400840084062FAF4E84B13D45D2001010100000000670100649F3303204000950500000400009F37049BADBCAB9F100C0B010A03A0B00000000000009F26080123456789ABCDEF9F360200FF820200009C01019F1A0208409A030101019F02060000000123005F2A0208409F03060000000000008407A00000000310100425000010098000000000000000E8068020000002F0";
        a.setConvertor(new Convertor());
        Message msgBuffer = new Message();
        msgBuffer.setData(t1);
        msgBuffer.setMessageStatus("RSP");
        msgBuffer.setStationName("HOST");
        Hashtable<String, String> isoBuffer = new Hashtable<>();
        isoBuffer = a.formatMessage(msgBuffer,isoBuffer);
        isoBuffer.put(Element.DE102,"0000");
        String asdf = a.buildISOErrorMessage(isoBuffer);
        System.out.println(asdf);
        Hashtable<String, String> finalIsoBuffer1 = isoBuffer;
        assertDoesNotThrow(()->a.formatMessage(msgBuffer, finalIsoBuffer1));
    }
    
    @Test
    void parseBitmap()
    {
        String iobsgBitmap = "FEFD648108E0E016";
        String losgUpperBitmap = "00000000000000000000000000000000";
    
        System.out.println(new BigInteger("FEFD648108E0E016", 16).toString(2));
    
    }
    
}
