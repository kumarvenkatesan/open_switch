package money.open.cards.visabase;

import money.open.cards.visabase.utility.Convertor;
import money.open.cards.visabase.utility.TPEGeneralUtil;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.LocalTime;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class VisaBaseInitTests {

    
    TPEGeneralUtil tpeGeneralUtil;
    @Autowired
    public void setTpeGeneralUtil(TPEGeneralUtil tpeGeneralUtil) {
        this.tpeGeneralUtil = tpeGeneralUtil;
    }
    
    Convertor convertor;
    @Autowired
    public void setConvertor(Convertor convertor) {
        this.convertor = convertor;
    }
    @BeforeAll
    public void before(){
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @Disabled("TODO: Still need to work on it")
    void convertorMethodTest(){
        this.setConvertor(new Convertor());
        Assertions.assertEquals("xxxx-xxxx-xxxx-3456", convertor.maskCardNumber("1234567890123456"));
        Assertions.assertEquals("54455354", convertor.alpha2Hex("TEST"));
        Assertions.assertEquals(18, convertor.hex2decimal("12"));
        Assertions.assertEquals("0C", convertor.convertToHex(12));
        Assertions.assertEquals(36, convertor.hexatoDecimal("24"));
        Assertions.assertEquals("TEST", convertor.hex2Alpha("54455354"));
        Assertions.assertEquals("0000012345", convertor.paddingZeroPrefix("12345",10));
        Assertions.assertEquals("<NUL>", convertor.ebcdicOfHex((char) 0x00));
        Assertions.assertEquals("4B", convertor.ebcdicToHex('.'));
        Assertions.assertEquals("TEST", convertor.convertEBCDICHexValue("E3C5E2E3"));
        Assertions.assertEquals("E3C5E2E3", convertor.convertToEBSDICHEXValue("TEST"));
        Assertions.assertEquals("4000000000000000", convertor.binary2hex("0100000000000000000000000000000000000000000000000000000000000000"));
        Assertions.assertEquals(LocalTime.of(10,12,59,0), convertor.getLocalTimeForString("101259"));
        Assertions.assertEquals(new BigDecimal("11.51"), convertor.convertStringToBigDecimal("000000001151"));
        Assertions.assertEquals("000000001151", convertor.convertBigDecimalToString(new BigDecimal("72416.9500")));
        Assertions.assertEquals("   ", convertor.addSpace(3));
        Assertions.assertEquals("0011", convertor.convertToBinary("3"));
        Assertions.assertEquals("0C", convertor.decimal2hex(12));
        
        
    }
    @Test
    @Disabled("TODO: Still need to work on it")
    void bigDecimalToString()
    {
        System.out.println(convertor.convertBigDecimalToString(new BigDecimal("72416.9500")));
    }
    
    
    @Test
    @Disabled("TODO: Still need to work on it")
    void tpeGeneralUtilMethodTest(){
        this.setTpeGeneralUtil(new TPEGeneralUtil());
        Assertions.assertEquals(10, tpeGeneralUtil.getDE007().length());
        Assertions.assertEquals(6, tpeGeneralUtil.getDE011().length());
        Assertions.assertEquals("232209124524", tpeGeneralUtil.getDE037("0509124524"));
        Assertions.assertEquals("ES", tpeGeneralUtil.getSubstring("TEST",1,3));
    }
}
