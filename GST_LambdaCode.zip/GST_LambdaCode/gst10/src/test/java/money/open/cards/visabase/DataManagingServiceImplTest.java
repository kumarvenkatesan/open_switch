package money.open.cards.visabase;

import money.open.cards.visabase.constants.Element;
import money.open.cards.visabase.dto.Message;
import money.open.cards.visabase.dto.TransactionRequestDto;
import money.open.cards.visabase.exception.TransactionException;
import money.open.cards.visabase.exception.VisaBaseException;
import money.open.cards.visabase.service.impl.DataManagingServiceImpl;
import money.open.cards.visabase.service.impl.VisaFormatterImpl;
import money.open.cards.visabase.service.parsor.EMVParser;
import money.open.cards.visabase.utility.Convertor;
import money.open.cards.visabase.utility.TPEGeneralUtil;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.Hashtable;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class DataManagingServiceImplTest {
    
    
    @BeforeAll
    public void before() {
        MockitoAnnotations.openMocks(this);
    }
    
    @InjectMocks
    DataManagingServiceImpl dataManagingService;
    
    @InjectMocks
    EMVParser emvParser;
    
    @InjectMocks
    TransactionRequestDto transactionRequestDto;
    @InjectMocks
    Hashtable<String, String> isoBuffer;
    
    String defaultAmount = "0.0";
    
    
    @Test
    void getServiceCode() {
        String track2Data = "4034567890123456D030912312345000";
        dataManagingService.setTpeGeneralUtil(new TPEGeneralUtil());
        assertEquals("123", dataManagingService.getServiceCode(track2Data));
        String track2Data2 = "4034567890123456=030912312345000";
        dataManagingService.setTpeGeneralUtil(new TPEGeneralUtil());
        assertEquals("123", dataManagingService.getServiceCode(track2Data2));
    }
    @Test
    void getCvv() {
        String track2Data = "4034567890123456D030912312345000";
        dataManagingService.setTpeGeneralUtil(new TPEGeneralUtil());
        assertEquals("000", dataManagingService.getCvv(track2Data));
        String track2Data2 = "4034567890123456=030912312345000";
        dataManagingService.setTpeGeneralUtil(new TPEGeneralUtil());
        assertEquals("000", dataManagingService.getCvv(track2Data2));
    }
    @Test
    void getExpDate() {
        String track2Data = "4034567890123456D030912312345000";
        dataManagingService.setTpeGeneralUtil(new TPEGeneralUtil());
        assertEquals("0309", dataManagingService.getExpDate(track2Data,transactionRequestDto));
        String track2Data2 = "4034567890123456=030912312345000";
        dataManagingService.setTpeGeneralUtil(new TPEGeneralUtil());
        assertEquals("0309", dataManagingService.getExpDate(track2Data2,transactionRequestDto));
    
        String track2Data3 = "";
        dataManagingService.setTpeGeneralUtil(new TPEGeneralUtil());
        transactionRequestDto.setExpiryDate("0309");
        assertEquals("0309", dataManagingService.getExpDate(track2Data3,transactionRequestDto));
    }
    
    
    
    @Test
    void formatMessage() throws VisaBaseException, TransactionException {
        VisaFormatterImpl a = new VisaFormatterImpl();
        String t1 = "00001601020160000000000000000000000000000000000002007EFD669128E0FA1610403456789012345601100000000000400000000002500000000002500005041322406100000061000000000444184802050403090000601108400510000100C4F0F0F0F0F0F0F0F00C012345678901204034567890123456D030912312345000F2F1F2F4F1F3F0F0F0F4F4F4C1E3D4F0F1404040C3C1D9C440C1C3C3C5D7E3D6D94040C1C3D8E4C9D9C5D940D5C1D4C5404040404040404040404040C3C9E3E840D5C1D4C540404040E4E208400840084062FAF4E84B13D45D2001010100000000670100649F3303204000950500000400009F37049BADBCAB9F100C0B010A03A0B00000000000009F26080123456789ABCDEF9F360200FF820200009C01019F1A0208409A030101019F02060000000123005F2A0208409F03060000000000008407A00000000310100425000010098000000000000000E8068020000002F0";
        a.setConvertor(new Convertor());
        Message msgBuffer = new Message();
        msgBuffer.setData(t1);
        msgBuffer.setMessageStatus("RSP");
        msgBuffer.setStationName("HOST");
        Hashtable<String, String> isoBuffer = new Hashtable<>();
        isoBuffer = a.formatMessage(msgBuffer, isoBuffer);
        isoBuffer.put(Element.DE102, "0000");
        String asdf = a.buildISOMessage(isoBuffer, true);
        System.out.println(asdf);
        Hashtable<String, String> finalIsoBuffer1 = isoBuffer;
        assertDoesNotThrow(() -> a.formatMessage(msgBuffer, finalIsoBuffer1));
        
        String t2 = "0000160102016B00000000000000000000000000000000000200FEFD669128E0FA16000000000400000010403456789012345601100000000000400000000002500000000002500005041322406100000061000000000444184802050403090000601108400510000100C4F0F0F0F0F0F0F0F00C012345678901204034567890123456D030912312345000F2F1F2F4F1F3F0F0F0F4F4F4C1E3D4F0F1404040C3C1D9C440C1C3C3C5D7E3D6D94040C1C3D8E4C9D9C5D940D5C1D4C5404040404040404040404040C3C9E3E840D5C1D4C540404040E4E208400840084062FAF4E84B13D45D2001010100000000670100649F3303204000950500000400009F37049BADBCAB9F100C0B010A03A0B00000000000009F26080123456789ABCDEF9F360200FF820200009C01019F1A0208409A030101019F02060000000123005F2A0208409F03060000000000008407A00000000310100425000010098000000000000000E8068020000002F0020000";
        
        msgBuffer.setData(t2);
        msgBuffer.setMessageStatus("RSP");
        msgBuffer.setStationName("HOST");
        isoBuffer = a.formatMessage(msgBuffer, isoBuffer);
        // isoBuffer.put(Element.DE102,"0000");
        Hashtable<String, String> finalIsoBuffer = isoBuffer;
        assertDoesNotThrow(() -> a.formatMessage(msgBuffer, finalIsoBuffer));
    }
    
    @Test
    void test()
    {
        String t1 = "0000160102019700000000000000000000000000000000000200FEFD669128E0FA16800000000000000075C1F8000000000010403456789012345601100000000000400000000002500000000002500011141419596100000061000000001683195000111403090000601103560510000100C4F0F0F0F0F0F0F0F006472657184034567890123456D0309206F2F3F1F8F1F4F0F0F1F6F8F3C1E3D4F0F1404040C3C1D9C440C1C3C3C5D7E3D6D94040E3C5E2E340E3D9C1D5E2C1C3E3C9D6D5404040404040404040C3C9E3E840D5C1D4C540404040E4E2035608400840AF05B0F3BD7F975420010101000000006201005F9F3303204000950500000400009F37009F100706010A03A000009F26080123456789ABCDEF9F360200FF820200009C01019F1A009A009F02005F2A009F03060000000000008407A000000003101020002800310029002E0069006E006900000425000010098000000000000000E8068020000002F020400006010A03A000000123456789ABCDEF00FF000000000000000000377C05C0008400A0963066CC89180810E88005B81679";
        System.out.println(t1.substring(52,68));
        System.out.println(t1.substring(68,84));
        System.out.println(t1.substring(84,100));
    }
}
