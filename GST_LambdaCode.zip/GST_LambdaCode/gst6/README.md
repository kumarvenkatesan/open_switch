# OpenSwitch-Protect

Open switch protect is a java based library/wrapper which contains function to work with cryptographic algorithms.
Below are the operations covered in this library:
* RSA
* AES
* Key Store Management (JCEKS, PKCS12, JKS)
* Digital Signature - creation and verification of digital signature.
* Certificate - generation of X509 certificate
* Hash - password hash