package money.open.protect.rsa;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;

import static money.open.protect.constants.Constants.RSA_TRANSFORMATION;

/**
 * Class containing method to perform encryption and decryption of a payload using private and public key.
 * @author govil.kumar
 */
public final class RSACipher {

    private RSACipher() {}

    public static byte[] encrypt(String data, PublicKey publicKey) {
        Cipher cipher = null;
        byte[] encryptedData;
        try {
            cipher = Cipher.getInstance(RSA_TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            encryptedData = cipher.doFinal(data.getBytes());
        } catch (NoSuchAlgorithmException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException |
                 InvalidKeyException e) {
            throw new RuntimeException(e);
        }
        return encryptedData;
    }

    public static String decrypt(byte[] data, PrivateKey privateKey) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        Cipher cipher = Cipher.getInstance(RSA_TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        return new String(cipher.doFinal(data));
    }

    public static String decrypt(String data, String base64PrivateKey) throws Exception {
        return decrypt(Base64.getDecoder().decode(data.getBytes()), RSAKeyGenerator.getPrivateKey(base64PrivateKey));
    }

}
