package money.open.protect.signature;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.util.Arrays;

import static money.open.protect.constants.Constants.SHA256_RSA;

/**
 * Utility class for creation and verification of digital signature.
 * @author govil.kumar
 */
public class DigitalSignature {

    private DigitalSignature() {}

    public static String createDigitalSignature(String input, PrivateKey privateKey) {
        try {
            Signature signature = Signature.getInstance(SHA256_RSA);
            signature.initSign(privateKey);
            signature.update(Byte.parseByte(input));
            return Arrays.toString(signature.sign());
        } catch (NoSuchAlgorithmException | InvalidKeyException | SignatureException e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean verifyDigitalSignature(String input, byte[] signatureToVerify, PublicKey publicKey) {
        try {
            Signature signature = Signature.getInstance(SHA256_RSA);
            signature.initVerify(publicKey);
            signature.update(signatureToVerify);
            return signature.verify(signatureToVerify);
        } catch (NoSuchAlgorithmException | SignatureException | InvalidKeyException e) {
            throw new RuntimeException(e);
        }
    }
}
