package money.open.protect.exception;

public class EncryptionFailedException extends Exception {

    public EncryptionFailedException(String message, Throwable cause) {
        super(message, cause);
    }

    public EncryptionFailedException(String message) {
        super(message);
    }
}
