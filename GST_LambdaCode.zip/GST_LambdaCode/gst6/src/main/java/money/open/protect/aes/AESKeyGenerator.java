package money.open.protect.aes;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;

import static money.open.protect.constants.Constants.AES_ALGORITHM;
import static money.open.protect.constants.Constants.AES_KEY_BIT_SIZE;
import static money.open.protect.constants.Constants.PBKDF2_HMAC_SHA256_PADDING;

/**
 * This class provides APIs to generate AES secret key.
 * @author govil.kumar
 */
public class AESKeyGenerator {

    private AESKeyGenerator() {}

    /**
     * Generate AES Secret key of 256 bits.
     *
     * @param keysize
     * @return
     * @throws NoSuchAlgorithmException
     */
    public static SecretKey generateAESKey() throws NoSuchAlgorithmException {
        KeyGenerator keyGen = KeyGenerator.getInstance(AES_ALGORITHM);
        keyGen.init(AES_KEY_BIT_SIZE, SecureRandom.getInstanceStrong());
        return keyGen.generateKey();
    }

    /**
     * Password derived AES 256 bits secret key
     * @param password
     * @param salt
     * @return
     * @throws NoSuchAlgorithmException
     * @throws InvalidKeySpecException
     */
    public static SecretKey generateAESKeyFromPassword(char[] password, byte[] salt)
            throws NoSuchAlgorithmException, InvalidKeySpecException {

        SecretKeyFactory factory = SecretKeyFactory.getInstance(PBKDF2_HMAC_SHA256_PADDING);
        // iterationCount = 65536
        // keyLength = 256
        KeySpec spec = new PBEKeySpec(password, salt, 65536, AES_KEY_BIT_SIZE);
        return new SecretKeySpec(factory.generateSecret(spec).getEncoded(), AES_ALGORITHM);
    }

}
