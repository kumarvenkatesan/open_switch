package money.open.protect.rsa;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.security.PrivateKey;
import java.security.PublicKey;

@Getter
@Setter
@Builder(toBuilder = true)
public class RSAKeys {

    private PrivateKey privateKey;
    private PublicKey publicKey;

}
