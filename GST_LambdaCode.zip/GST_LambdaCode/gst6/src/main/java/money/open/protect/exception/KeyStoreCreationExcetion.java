package money.open.protect.exception;

import java.security.KeyStoreException;

public class KeyStoreCreationExcetion extends KeyStoreException {

    public KeyStoreCreationExcetion(String exceptionMessage) {
        super(exceptionMessage);
    }

}
