package money.open.protect.constants;

/**
 * Constants that are used by the other classes.
 * @author govil.kumar
 */
public final class Constants {

    public static final String RSA_ALGORITHM = "RSA";
    public static final String AES_ALGORITHM = "AES";
    public static final String RSA_TRANSFORMATION = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding";//"RSA/ECB/PKCS1Padding";
    public static final String AES_ECB_TRANSFORMATION = "AES/ECB/PKCS5Padding";
    public static final String AES_CBC_TRANSFORMATION = "AES/CBC/PKCS5Padding";
    public static final String CHARACTER_ENCODING = "UTF-8";
    public static final int AES_KEY_BIT_SIZE = 256;
    public static final String SHA_512 = "SHA-512";
    public static final String SHA256_RSA = "SHA256withRSA";
    public static final String PBKDF2_HMAC_SHA256_PADDING = "PBKDF2WithHmacSHA256";

}
