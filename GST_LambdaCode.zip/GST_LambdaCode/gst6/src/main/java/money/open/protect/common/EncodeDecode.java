package money.open.protect.common;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

import static money.open.protect.constants.Constants.CHARACTER_ENCODING;

public class EncodeDecode {

    private EncodeDecode() {}

    /**
     * This method is used to encode bytes[] to base64 string.
     *
     * @param bytes : Bytes to encode
     * @return : Encoded Base64 String
     */
    public static String encodeBase64String(byte[] bytes) {
        return new String(Base64.getEncoder().encode(bytes));
    }
    /**
     * This method is used to decode the base64 encoded string to byte[]
     *
     * @param data : String to decode
     * @return : decoded String
     * @throws UnsupportedEncodingException
     */
    public static byte[] decodeBase64StringToByte(String data) throws Exception {
        return Base64.getDecoder().decode(data.getBytes(CHARACTER_ENCODING));
    }
}
