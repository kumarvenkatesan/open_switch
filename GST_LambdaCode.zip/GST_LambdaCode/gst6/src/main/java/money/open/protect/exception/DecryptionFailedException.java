package money.open.protect.exception;

public class DecryptionFailedException extends Exception {

    public DecryptionFailedException(String message, Throwable cause) {
        super(message, cause);
    }

    public DecryptionFailedException(String message) {
        super(message);
    }

}
