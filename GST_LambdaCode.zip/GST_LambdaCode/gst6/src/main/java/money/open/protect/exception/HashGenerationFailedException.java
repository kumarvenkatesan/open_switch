package money.open.protect.exception;

public class HashGenerationFailedException extends Exception {

    public HashGenerationFailedException(String message, Throwable cause) {
        super(message, cause);
    }

    public HashGenerationFailedException(String message) {
        super(message);
    }
}
