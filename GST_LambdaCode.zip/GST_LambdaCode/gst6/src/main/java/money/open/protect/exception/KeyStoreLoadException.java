package money.open.protect.exception;

import java.security.KeyStoreException;

public class KeyStoreLoadException extends KeyStoreException {

    public KeyStoreLoadException(String exceptionMessage) {
        super(exceptionMessage);
    }

}
