package money.open.protect.keystore;

import money.open.protect.exception.KeyStoreCreationExcetion;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableEntryException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.util.Enumeration;

/**
 * This class is a manager class to create, load and manage key store entries.
 * @author govil.kumar
 * @version 1.0
 */
public class KeyStoreManager {

    private static KeyStoreManager instance;

    private KeyStoreManager() {}

    public static KeyStoreManager getInstance() {
        if(instance == null) {
            synchronized (KeyStoreManager.class) {
                if (instance == null) {
                    instance = new KeyStoreManager();
                }
            }
        }
        return instance;
    }

    public KeyStore createKeyStore(String path, final String password, String keyStoreType) throws KeyStoreCreationExcetion {
        KeyStore keyStore = null;
        if(keyStoreType == null || keyStoreType.isEmpty()){
            keyStoreType = KeyStore.getDefaultType();
        }
        try {
            keyStore = KeyStore.getInstance(keyStoreType);
            //load
            char[] pwdArray = password.toCharArray();
            keyStore.load(null, pwdArray);
            storeKeyStore(keyStore, pwdArray, path);
        } catch (KeyStoreException | IOException | NoSuchAlgorithmException | CertificateException e) {
            throw new KeyStoreCreationExcetion(e.getMessage());
        }
        return keyStore;
    }

    public KeyStore loadKeyStore(final String password, String pathWithFileName, String keyStoreType) {
        char[] pwdArray = password.toCharArray();
        KeyStore keyStore = null;
        try (FileInputStream fis = new FileInputStream(pathWithFileName)) {
            keyStore = KeyStore.getInstance(keyStoreType);
            keyStore.load(fis, pwdArray);
            storeKeyStore(keyStore, pwdArray, pathWithFileName);
        } catch (KeyStoreException | IOException | NoSuchAlgorithmException | CertificateException e) {
            throw new RuntimeException(e);
        }
        return keyStore;
    }

    public void storeKeyStore(KeyStore keyStore, char[] password, String path) throws IOException, CertificateException, KeyStoreException, NoSuchAlgorithmException {
        try (FileOutputStream fileOutputStream = new FileOutputStream(path)) {
            keyStore.store(fileOutputStream, password);
        }
    }

    public boolean exists(final String path) {
        File file = new File(path);
        return file.exists();
    }

    public void setEntry(KeyStore keyStore, String alias, KeyStore.SecretKeyEntry secretKeyEntry, KeyStore.ProtectionParameter protectionParameter) throws KeyStoreException {
        keyStore.setEntry(alias, secretKeyEntry, protectionParameter);
    }

    public void setKeyEntry(KeyStore keyStore, String alias, Key key, String keyPassword, Certificate[] certificateChain) throws KeyStoreException {
        keyStore.setKeyEntry(alias, key, keyPassword.toCharArray(), certificateChain);
    }

    public KeyStore.Entry getEntry(KeyStore keyStore, String alias, String keyStorePassword) throws UnrecoverableEntryException, NoSuchAlgorithmException, KeyStoreException {
        KeyStore.ProtectionParameter protectionParameter = new KeyStore.PasswordProtection(keyStorePassword.toCharArray());
        return keyStore.getEntry(alias, protectionParameter);
    }

    public void setCertificateEntry(KeyStore keyStore, String alias, Certificate certificate) throws KeyStoreException {
        keyStore.setCertificateEntry(alias, certificate);
    }

    public Certificate getCertificate(KeyStore keyStore, String alias) throws KeyStoreException {
        return keyStore.getCertificate(alias);
    }

    public void deleteEntry(KeyStore keyStore, String alias) throws KeyStoreException {
        keyStore.deleteEntry(alias);
    }

    public void deleteKeyStore(KeyStore keyStore, String keyStorePath) throws KeyStoreException, IOException {
        Enumeration<String> aliases = keyStore.aliases();
        while (aliases.hasMoreElements()) {
            String alias = aliases.nextElement();
            keyStore.deleteEntry(alias);
        }
        Path keyStoreFile = Paths.get(keyStorePath);
        Files.delete(keyStoreFile);
    }
}
