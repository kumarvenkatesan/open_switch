package money.open;

import money.open.protect.exception.KeyStoreCreationExcetion;
import money.open.protect.keystore.CertificateGenerator;
import money.open.protect.keystore.KeyStoreManager;
import money.open.protect.rsa.RSAKeyGenerator;
import org.bouncycastle.operator.OperatorCreationException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.UnrecoverableEntryException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;


public class KeyStoreManagerTest {

    private KeyStoreManager keyStoreManager;
    private KeyStore keyStore;

    private static final String KEYSTORE_PWD = "abc123";
    private static final String KEYSTORE_NAME = "myKeyStore.jks";
    private static final String KEY_STORE_TYPE = "JKS";

    private static final String MY_SECRET_ENTRY = "mySecretEntry";
    private static final String DN_NAME = "CN=test, OU=test, O=test, L=test, ST=test, C=CY";
    private static final String SHA1WITHRSA = "SHA1withRSA";
    private static final String MY_PRIVATE_KEY = "myPrivateKey";
    private static final String MY_CERTIFICATE = "myCertificate";

    @BeforeEach
    public void setup() {
        keyStoreManager = KeyStoreManager.getInstance();
    }

    @AfterEach
    public void tearDown() throws KeyStoreException, IOException {
        keyStoreManager.deleteKeyStore(keyStore, KEYSTORE_NAME);
    }

    @Test
    public void createKeyStoreTest() throws Exception {
        keyStore = keyStoreManager.createKeyStore(KEYSTORE_NAME, KEYSTORE_PWD, KEY_STORE_TYPE);
        assertNotNull(keyStore);
    }

    @Test
    public void loadKeyStoreTest() throws KeyStoreCreationExcetion {
        keyStore = keyStoreManager.createKeyStore(KEYSTORE_NAME, KEYSTORE_PWD, KEY_STORE_TYPE);
        keyStore = keyStoreManager.loadKeyStore(KEYSTORE_PWD, KEYSTORE_NAME, KEY_STORE_TYPE);
        assertNotNull(keyStore);
    }

    @Test
    @Disabled
    void setEntryTest() throws NoSuchAlgorithmException, KeyStoreException, UnrecoverableEntryException {
        keyStore = keyStoreManager.createKeyStore(KEYSTORE_NAME, KEYSTORE_PWD, KEY_STORE_TYPE);
        keyStore = keyStoreManager.loadKeyStore(KEYSTORE_PWD, KEYSTORE_NAME, KEY_STORE_TYPE);
        KeyGenerator keygen = KeyGenerator.getInstance("HmacSHA256");
        SecretKey secretKey = keygen.generateKey();
        KeyStore.ProtectionParameter protParam = new KeyStore.PasswordProtection(KEYSTORE_PWD.toCharArray());
        KeyStore.SecretKeyEntry secretKeyEntry = new KeyStore.SecretKeyEntry(secretKey);
        keyStoreManager.setEntry(keyStore, MY_SECRET_ENTRY, secretKeyEntry, protParam);

        assertEquals(1, keyStore.size());
        KeyStore.Entry entry = keyStoreManager.getEntry(keyStore, MY_SECRET_ENTRY, KEYSTORE_PWD);
        assertNotNull(entry);
    }

    @Test
    void setKeyEntryTest() throws FileNotFoundException, CertificateException, UnrecoverableEntryException, KeyStoreException, NoSuchAlgorithmException {
        Certificate[] chain = getCertificates();
        keyStore = keyStoreManager.createKeyStore(KEYSTORE_NAME, KEYSTORE_PWD, KEY_STORE_TYPE);
        keyStore = keyStoreManager.loadKeyStore(KEYSTORE_PWD, KEYSTORE_NAME, KEY_STORE_TYPE);
        PrivateKey privateKey = RSAKeyGenerator.generateKeys().getPrivateKey();
        keyStoreManager.setKeyEntry(keyStore, "alias", privateKey, KEYSTORE_PWD, chain);
        PrivateKey key = (PrivateKey) keyStore.getKey("alias", KEYSTORE_PWD.toCharArray());
        assertNotNull(key);
        assertEquals(privateKey, key);
    }

    @Test
    void whenCreateAndLoadKeyStore_setCertificateEntry_thenGetCertificateEntry() throws CertificateException, KeyStoreException, NoSuchAlgorithmException, OperatorCreationException {
        Certificate cert = CertificateGenerator.getInstance()
                .generateCertificate(RSAKeyGenerator.generateKeys(), "open-money");
        keyStore = keyStoreManager.createKeyStore(KEYSTORE_NAME, KEYSTORE_PWD, KEY_STORE_TYPE);
        keyStore = keyStoreManager.loadKeyStore(KEYSTORE_PWD, KEYSTORE_NAME, KEY_STORE_TYPE);
        keyStoreManager.setCertificateEntry(keyStore, MY_SECRET_ENTRY, cert);
        Certificate certificate = keyStoreManager.getCertificate(keyStore, MY_SECRET_ENTRY);
        assertNotNull(certificate);
        assertEquals(cert, certificate);
    }

    private Certificate[] getCertificates() throws CertificateException, FileNotFoundException {
        CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
        X509Certificate certificate = (X509Certificate) certFactory.generateCertificate(new FileInputStream("src/test/resources/protect-test.cer"));
        Certificate[] chain = new Certificate[1];
        chain[0] = certificate;
        return chain;
    }
}
