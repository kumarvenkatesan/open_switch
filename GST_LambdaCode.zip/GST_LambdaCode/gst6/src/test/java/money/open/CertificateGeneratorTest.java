package money.open;

import money.open.protect.keystore.CertificateGenerator;
import money.open.protect.rsa.RSAKeyGenerator;
import money.open.protect.rsa.RSAKeys;
import org.bouncycastle.operator.OperatorCreationException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class CertificateGeneratorTest {

    private CertificateGenerator certificateGenerator;

    @BeforeEach
    void setup() {
        certificateGenerator = CertificateGenerator.getInstance();
    }

    @Test
    void generateCertificateTest() throws NoSuchAlgorithmException, CertificateException, OperatorCreationException {
        RSAKeys keys = RSAKeyGenerator.generateKeys();
        Certificate certificate = certificateGenerator.generateCertificate(keys, "open-cards");
        assertNotNull(certificate);
    }

}
