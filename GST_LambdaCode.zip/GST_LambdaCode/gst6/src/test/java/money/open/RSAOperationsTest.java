package money.open;

import money.open.protect.rsa.RSACipher;
import money.open.protect.rsa.RSAKeyGenerator;
import money.open.protect.rsa.RSAKeys;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class RSAOperationsTest {

    private static final String ENCRYPT_THIS_STRING = "encrypt this string";

    @Test
    void whenEnrypt_thenDecrypt() throws Exception {
        RSAKeys keys = RSAKeyGenerator.generateKeys();
        byte[] encryptedData = RSACipher.encrypt(ENCRYPT_THIS_STRING, keys.getPublicKey());
        String decryptedData = RSACipher.decrypt(encryptedData, keys.getPrivateKey());
        assertNotNull(decryptedData);
        assertEquals(ENCRYPT_THIS_STRING, decryptedData);
    }
}
