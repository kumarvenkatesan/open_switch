package money.open;

import money.open.protect.aes.AESCipher;
import money.open.protect.aes.AESKeyGenerator;
import money.open.protect.exception.DecryptionFailedException;
import money.open.protect.exception.EncryptionFailedException;
import money.open.protect.rsa.RSAKeyGenerator;
import money.open.protect.rsa.RSAKeys;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import java.security.NoSuchAlgorithmException;

import static money.open.protect.constants.Constants.AES_CBC_TRANSFORMATION;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AESCipherTest {

    @Test
    void encryptDecyrptAESKey() throws NoSuchAlgorithmException {
        RSAKeys keys = RSAKeyGenerator.generateKeys();
        SecretKey secretKey = AESKeyGenerator.generateAESKey();
        SecretKey decryptedAESKey = null;
        byte[] encryptedAESKey = null;
        try {
            encryptedAESKey = AESCipher.encryptAESSecretKey(secretKey, keys.getPublicKey());
            decryptedAESKey = AESCipher.decryptAESKey(encryptedAESKey, keys.getPrivateKey());
        } catch (EncryptionFailedException | DecryptionFailedException e) {
            throw new RuntimeException(e);
        }
        assertEquals(secretKey, decryptedAESKey);
    }

    @Test
    void givenString_whenEncrypt_thenSuccess() throws Exception {
        String input = "This is a secret text.";
        SecretKey key = AESKeyGenerator.generateAESKey();
        IvParameterSpec ivParameterSpec = AESCipher.generateIv();
        String cipherText = AESCipher.encrypt(AES_CBC_TRANSFORMATION, input, key, ivParameterSpec);
        String plainText = AESCipher.decrypt(AES_CBC_TRANSFORMATION, cipherText, key, ivParameterSpec);
        Assertions.assertEquals(input, plainText);
    }


}
