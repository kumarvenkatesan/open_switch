package money.open.cards.saf.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import money.open.cards.saf.dto.TransactionRequestDto;
import money.open.cards.saf.kafka.consumer.impl.KafkaConsumer1ServiceImpl;
import money.open.cards.saf.model.SAFTransaction;
import static money.open.cards.saf.helper.Helper.generateTransactionRequestJson;
import static money.open.cards.saf.helper.Helper.getPayload;
import static money.open.cards.saf.helper.Helper.saf_transaction_data_string;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class KafkaConsumerServiceTest {
	
	@Mock
	private SafTransactionService safTransactionService;

	@Mock
	private DataService dataService;
	
	private String payload;
	private TransactionRequestDto transactionRequestDto;
	private SAFTransaction safTransaction;
	private KafkaConsumer1ServiceImpl kafkaConsumer1ServiceImpl;
	
	@BeforeEach
	void setUp() throws JsonMappingException, JsonProcessingException {
		MockitoAnnotations.openMocks(this);
		payload = getPayload();
		transactionRequestDto = generateTransactionRequestJson();
		ObjectMapper objectMapper = new ObjectMapper();
		safTransaction = objectMapper.readValue(saf_transaction_data_string(), SAFTransaction.class);
	}
	
}
