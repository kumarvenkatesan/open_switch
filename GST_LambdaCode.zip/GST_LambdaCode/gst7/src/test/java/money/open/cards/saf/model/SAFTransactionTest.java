package money.open.cards.saf.model;

import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import static money.open.cards.saf.helper.Helper.convertTransactionRequestDtoToMap;
import static money.open.cards.saf.helper.Helper.convertTransactionResponseDtoToMap;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static money.open.cards.saf.helper.Helper.SAF_TRANSACTIONID;
import static money.open.cards.saf.helper.Helper.TRANSACTION_KEY;
import static money.open.cards.saf.helper.Helper.TRANSACTION_STATUS;
import static money.open.cards.saf.helper.Helper.REASON;
import static money.open.cards.saf.helper.Helper.RETRY_COUNT;
import static money.open.cards.saf.helper.Helper.SAF_TRANSACTION_ID;
import static money.open.cards.saf.helper.Helper.SAF_TRANSACTION_KEY;
import static money.open.cards.saf.helper.Helper.SAF_TRANSACTION_STATUS;
import static money.open.cards.saf.helper.Helper.SAF_REASON;
import static money.open.cards.saf.helper.Helper.SAF_RETRY_COUNT;
import static money.open.cards.saf.helper.Helper.convertSAFTransactionRequestDtoToMap;
import static money.open.cards.saf.helper.Helper.convertSAFTransactionResponseDtoToMap;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class SAFTransactionTest {
	
	private Map<String, Object> transaction_request_data;
	private Map<String, Object> transaction_response_data;
	private Map<String, Object> saf_transaction_request_data;
	private Map<String, Object> saf_transaction_response_data;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
		transaction_request_data = convertTransactionRequestDtoToMap();
		transaction_response_data = convertTransactionResponseDtoToMap();
		saf_transaction_request_data = convertSAFTransactionRequestDtoToMap();
		saf_transaction_response_data = convertSAFTransactionResponseDtoToMap();
	}
	
	@Test
	void testObjectMethod() {
		SAFTransaction safTransaction = new SAFTransaction();
		safTransaction.equals(new SAFTransaction());
		safTransaction.hashCode();
		safTransaction.toString();
	}
	
	@Test
	void testAll() {
		SAFTransaction safTransaction = new SAFTransaction();
		safTransaction.equals(SAFTransaction.builder().build());
	}
	
	@Test
	public void test_state_is_correct() {
		SAFTransaction safTransaction = new SAFTransaction(SAF_TRANSACTION_ID, TRANSACTION_KEY, transaction_request_data, transaction_response_data, TRANSACTION_STATUS, REASON, RETRY_COUNT);
		assertEquals(safTransaction.getSaf_transaction_id(), SAF_TRANSACTION_ID);
		assertEquals(safTransaction.getTransactionKey(), TRANSACTION_KEY);
		assertEquals(safTransaction.getTransaction_request_data(), transaction_request_data);
		assertEquals(safTransaction.getTransaction_response_data(), transaction_response_data);
		assertEquals(safTransaction.getTransaction_status(), TRANSACTION_STATUS);
		assertEquals(safTransaction.getReason(), REASON);
		assertEquals(safTransaction.getRetrycount(), RETRY_COUNT);
	}
	
	@Test
	public void test_equals_two_objects_with_different_values() {
		SAFTransaction safTransaction = new SAFTransaction(SAF_TRANSACTIONID, TRANSACTION_KEY, transaction_request_data, transaction_response_data, TRANSACTION_STATUS, REASON, RETRY_COUNT);
		assertThat(safTransaction).isNotEqualTo(new SAFTransaction(SAF_TRANSACTION_ID, SAF_TRANSACTION_KEY, saf_transaction_request_data, saf_transaction_response_data, SAF_TRANSACTION_STATUS, SAF_REASON, SAF_RETRY_COUNT) );
	}
}
