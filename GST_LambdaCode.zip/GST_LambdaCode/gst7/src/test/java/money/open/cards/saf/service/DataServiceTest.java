package money.open.cards.saf.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import money.open.cards.saf.Utils.SAFException;
import money.open.cards.saf.dto.TransactionRequestDto;
import money.open.cards.saf.model.SAFTransaction;
import money.open.cards.saf.model.SAFTransactionHistory;
import money.open.cards.saf.repository.SAFTransactionHistoryRespository;
import money.open.cards.saf.repository.SAFTransactionRepository;
import money.open.cards.saf.service.impl.DataServiceImpl;
import static money.open.cards.saf.helper.Helper.TRANSACTION_KEY;
import static money.open.cards.saf.helper.Helper.saf_transaction_data_string;
import static money.open.cards.saf.helper.Helper.getTransactionStatusMapData;
import static money.open.cards.saf.helper.Helper.generateTransactionRequestJson;
import static money.open.cards.saf.helper.Helper.generateTransactionResponseJson;
import static money.open.cards.saf.helper.Helper.RETRY_COUNT;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.Map;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class DataServiceTest {

	@Mock
	private SAFTransactionRepository safTransactionDao;

	@Mock
	private SAFTransactionHistoryRespository safTransactionHistoryDao;

	@Mock
	private ObjectMapper mapper;

	@InjectMocks
	private DataServiceImpl dataServiceImpl;

	private SAFTransaction safTransaction;

	private Map<String, String> transactionMapData;

	private TransactionRequestDto transactionRequest;

	private TransactionRequestDto transactionResponse;

	private SAFTransactionHistory safTransactionHistory;

	@BeforeEach
	void setUp() throws JsonMappingException, JsonProcessingException {
		MockitoAnnotations.openMocks(this);
		ObjectMapper objectMapper = new ObjectMapper();
		safTransaction = objectMapper.readValue(saf_transaction_data_string(), SAFTransaction.class);
		safTransactionHistory = objectMapper.readValue(saf_transaction_data_string(), SAFTransactionHistory.class);
		transactionMapData = getTransactionStatusMapData();
		transactionRequest = generateTransactionRequestJson();
		transactionResponse = generateTransactionResponseJson();
	}

	@Test
	void createNewSAFTransactionDataTest() {
		when(dataServiceImpl.createSAFTransactionData(transactionRequest, RETRY_COUNT)).thenReturn(safTransaction);
		SAFTransaction actualResponse = dataServiceImpl.createSAFTransactionData(transactionRequest, RETRY_COUNT);
		assertEquals(safTransaction.getTransactionKey(), actualResponse.getTransactionKey());
	}

	@Test
	void findByTransactionKeyTest() throws SAFException {
		when(safTransactionDao.findByTransactionKey(TRANSACTION_KEY)).thenReturn(safTransaction);
		assertThrows(SAFException.class, () -> dataServiceImpl.findByTransactionKey(null));
		SAFTransaction actualResponse = dataServiceImpl.findByTransactionKey(TRANSACTION_KEY);
		assertNotNull(actualResponse);
		assertEquals(safTransaction.getTransactionKey(), actualResponse.getTransactionKey());
	}

	@Test
	void updateSAFTransactionResponseDataTest() throws SAFException {
		when(safTransactionDao.findByTransactionKey(TRANSACTION_KEY)).thenReturn(safTransaction);
		when(dataServiceImpl.updateSAFTransactionResponseData(TRANSACTION_KEY, transactionResponse))
				.thenReturn(safTransaction);
		SAFTransaction actualResponse = dataServiceImpl.updateSAFTransactionResponseData(TRANSACTION_KEY,
				transactionResponse);
		assertEquals(safTransaction.getTransactionKey(), actualResponse.getTransactionKey());
	}

	@Test
	void updateSAFTransactionStatusTest() throws Exception {
		assertThrows(SAFException.class, () -> dataServiceImpl.throwExceptionIfEmpty(null));
		when(safTransactionDao.findByTransactionKey(TRANSACTION_KEY)).thenReturn(safTransaction);
		when(dataServiceImpl.updateSAFTransactionStatus(transactionMapData, transactionRequest))
				.thenReturn(safTransaction);
		SAFTransaction actualResponse = dataServiceImpl.updateSAFTransactionStatus(transactionMapData,
				transactionRequest);
		assertEquals(safTransaction.getTransactionKey(), actualResponse.getTransactionKey());
	}

	@Test
	void saveSAFTransactionHistoryDataTest() throws Exception {
		when(safTransactionHistoryDao.save(safTransactionHistory)).thenReturn(safTransactionHistory);
		dataServiceImpl.saveSAFTransactionHistoryData(safTransactionHistory);
		verify(safTransactionHistoryDao, times(1)).save(safTransactionHistory);
	}

	@Test
	void deleteSAFTransactionDataTest() throws Exception {
		doNothing().when(safTransactionDao).deleteByTransactionKey(TRANSACTION_KEY);
		dataServiceImpl.deleteSAFTransactionData(TRANSACTION_KEY);
		verify(safTransactionDao, times(1)).deleteByTransactionKey(TRANSACTION_KEY);
	}

	@Test
	void updateRetryCountTest() throws SAFException {
		when(safTransactionDao.findByTransactionKey(TRANSACTION_KEY)).thenReturn(safTransaction);
		when(dataServiceImpl.updateRetryCount(TRANSACTION_KEY, RETRY_COUNT)).thenReturn(safTransaction);
		SAFTransaction actualResponse = dataServiceImpl.updateRetryCount(TRANSACTION_KEY, RETRY_COUNT);
		assertEquals(safTransaction.getRetrycount(), actualResponse.getRetrycount());
	}
	
	@Test
	void updateSAFTransactionRequestDataTest() throws SAFException {
		when(safTransactionDao.findByTransactionKey(TRANSACTION_KEY)).thenReturn(safTransaction);
		when(dataServiceImpl.updateSAFTransactionRequestData(TRANSACTION_KEY, transactionRequest))
				.thenReturn(safTransaction);
		SAFTransaction actualResponse = dataServiceImpl.updateSAFTransactionResponseData(TRANSACTION_KEY,
				transactionRequest);
		assertEquals(safTransaction.getTransactionKey(), actualResponse.getTransactionKey());
		
	}	
}
