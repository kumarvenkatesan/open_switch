package money.open.cards.saf.service;

import static money.open.cards.saf.helper.Helper.generateEATransactionRequestJson;
import static money.open.cards.saf.helper.Helper.generateTransactionRequestJson;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import money.open.cards.saf.Utils.SAFException;
import money.open.cards.saf.dto.TransactionRequestDto;
import money.open.cards.saf.redis.model.NetworkMasterRedis;
import money.open.cards.saf.service.impl.ExternalAdapterServiceImpl;
import open.money.external.adapters.ExternalHostService;
import open.money.external.adapters.dto.EaTransactionRequestDto;
import static money.open.cards.saf.helper.Helper.network_endpoint;
import static money.open.cards.saf.helper.Helper.network_name;
import static money.open.cards.saf.helper.Helper.getNetworkMasterRedisData;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class ExternalAdapterServiceTest {

	@Mock
	private ExternalHostService externalHost;

	@Mock
	private ObjectMapper objectMapper;

	@InjectMocks
	private ExternalAdapterServiceImpl externalAdapterServiceImpl;

	private EaTransactionRequestDto eaTransactionRequest;

	private TransactionRequestDto transactionRequest;

	private Optional<NetworkMasterRedis> networkMasterRedis;

	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		eaTransactionRequest = generateEATransactionRequestJson();
		transactionRequest = generateTransactionRequestJson();
		networkMasterRedis = getNetworkMasterRedisData();
	}

	@Test
	void callExternalAdapterTest() throws JsonProcessingException, SAFException {
		when(externalHost.sendExternalCall(eaTransactionRequest,network_endpoint,
				network_name)).thenReturn(eaTransactionRequest);
		when(objectMapper.convertValue(eaTransactionRequest,TransactionRequestDto.class)).thenReturn(transactionRequest);
		assertThrows(SAFException.class,()-> externalAdapterServiceImpl.throwExceptionIfEmpty(null, null));
	}
}
