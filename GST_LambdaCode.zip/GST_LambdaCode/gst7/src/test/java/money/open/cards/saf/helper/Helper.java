package money.open.cards.saf.helper;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.saf.Utils.ResponseCodes;
import money.open.cards.saf.constants.SAFTransactionStatusConstants;
import money.open.cards.saf.dto.TransactionRequestDto;
import money.open.cards.saf.enums.CutOverFlagEnum;
import money.open.cards.saf.enums.EchoFlagEnum;
import money.open.cards.saf.enums.EndPointTypeEnum;
import money.open.cards.saf.enums.NetworkTypeEnum;
import money.open.cards.saf.enums.SignonFlagEnum;
import money.open.cards.saf.enums.TimeoutActionEnum;
import money.open.cards.saf.model.TransactionMaster;
import money.open.cards.saf.redis.model.NetworkMasterRedis;
import open.money.external.adapters.dto.EaTransactionRequestDto;

@Slf4j
public class Helper {

	private Helper() {

	}

	public static final String TRANSACTION_KEY = "0200166316018400012345678901317612";
	public static final int RETRY_COUNT = 1;
	public static final String network_endpoint = "API";
	public static final String network_name = "OPEN CAS HOST";
	public static final int network_timeoutperiod = 3000;
	public static final String ISSUER_BIN = "472657";
	public static final String CHANNEL_TYPE = "ATM";
	public static final String ISSUER_SELECT_ID = "YES_PREPAID";
	public static final String NETWORK_ID = "OPEN_CAS";
	public static final long SAF_TRANSACTIONID = 33;
	public static final String TRANSACTION_STATUS = "SKIPPPED";
	public static final String REASON = "Card Not Active / Card Number Not Present with response code:: 14";
	public static final String SAF_TRANSACTION_KEY = "0200166316065100012345678901317612";
	public static final int SAF_RETRY_COUNT = 1;
	public static final long SAF_TRANSACTION_ID = 2;
	public static final String SAF_TRANSACTION_STATUS = "SKIPPPED";
	public static final String SAF_REASON = "Card Not Active / Card Number Not Present with response code:: 14";

	public static String saf_transaction_data_string() throws JsonProcessingException {
		String transactionRequestData = transaction_request_data_string();
		log.info(transactionRequestData);
		String transactionResponseData = transaction_response_data_string();
		log.info(transactionResponseData);
		return "{\n" + "       \"saf_transaction_id\": 33,\n"
				+ "            \"transactionKey\": \"0200166316018400012345678901317612\",\n"
				+ "            \"transaction_request_data\": " + transactionRequestData + ",\n"
				+ "            \"transaction_response_data\": " + transactionResponseData + ",\n"
				+ "            \"transaction_status\": \"SKIPPED\",\n"
				+ "            \"reason\": \"Card Not Active / Card Number Not Present with response code:: 14\",\n"
				+ "            \"retrycount\": 1       " + "}";
	}

	public static TransactionRequestDto generateTransactionRequestJson() {
		TransactionRequestDto transactionRequestDto = TransactionRequestDto.builder().accountIdentification1("_")
				.accountIdentification2("_").accountNumber("087978").accumFlag("*").acqInstCountryCode(356)
				.transactionKey(TRANSACTION_KEY).transactionAmount(new BigDecimal(17)).channelType("ATM")
				.transactionType("00").issuerBin(ISSUER_BIN).maskedPan("xxxx-xxxx-xxxx-3456")
				.hashedPan(
						"ad7e47739641e52f799b40b98bcc946f146da3503a3c807a14faa7335db544dc048a0d7104f884feb0f9c385c8ff5d4eacc098d03f59f313588e19383c71655e")
				.accountNumber("0000000").acquirerId("VISA").apiRefNo("95705728").build();
		return transactionRequestDto;

	}

	public static Map<String, Object> convertTransactionRequestDtoToMap() {
		ObjectMapper objectMapper = new ObjectMapper();
		TransactionRequestDto transactionRequestDto = generateTransactionRequestJson();
		return objectMapper.convertValue(transactionRequestDto, new TypeReference<Map<String, Object>>() {
		});
	}

	public static String transaction_request_data_string() throws JsonProcessingException {
		Map<String, Object> map = convertTransactionRequestDtoToMap();
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(map);
	}

	public static TransactionRequestDto generateTransactionResponseJson() {
		TransactionRequestDto transactionRequestDto = TransactionRequestDto.builder().accountIdentification1("_")
				.accountIdentification2("_").accountNumber("087978").accumFlag("*").acqInstCountryCode(356)
				.transactionKey(TRANSACTION_KEY).transactionAmount(new BigDecimal(17)).channelType("ATM")
				.transactionType("00").issuerBin(ISSUER_BIN).maskedPan("xxxx-xxxx-xxxx-3456").channelType("ATM")
				.transactionType("00")
				.hashedPan(
						"ad7e47739641e52f799b40b98bcc946f146da3503a3c807a14faa7335db544dc048a0d7104f884feb0f9c385c8ff5d4eacc098d03f59f313588e19383c71655e")
				.accountNumber("0000000").acquirerId("VISA").apiRefNo("95705728").reasonCode("Success Transaction")
				.responseCode("00").build();
		return transactionRequestDto;

	}

	public static Map<String, Object> convertTransactionResponseDtoToMap() {
		ObjectMapper objectMapper = new ObjectMapper();
		TransactionRequestDto transactionRequestDto = generateTransactionResponseJson();
		return objectMapper.convertValue(transactionRequestDto, new TypeReference<Map<String, Object>>() {
		});
	}

	public static String transaction_response_data_string() throws JsonProcessingException {
		Map<String, Object> map = convertTransactionResponseDtoToMap();
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(map);
	}

	public static Map<String, String> getTransactionStatusMapData() {
		Map<String, String> map = new HashMap<>();
		map.put("reason", "Success Transaction");
		map.put("transaction_status", SAFTransactionStatusConstants.SUCCESS);
		return map;
	}

	public static EaTransactionRequestDto generateEATransactionRequestJson() {
		EaTransactionRequestDto transactionRequestDto = EaTransactionRequestDto.builder().accountIdentification1("_")
				.accountIdentification2("_").accountNumber("087978").accumFlag("*").acqInstCountryCode(356)
				.transactionKey(TRANSACTION_KEY).transactionAmount(new BigDecimal(17)).channelType("ATM")
				.transactionType("00").issuerBin(ISSUER_BIN).maskedPan("xxxx-xxxx-xxxx-3456")
				.hashedPan(
						"ad7e47739641e52f799b40b98bcc946f146da3503a3c807a14faa7335db544dc048a0d7104f884feb0f9c385c8ff5d4eacc098d03f59f313588e19383c71655e")
				.accountNumber("0000000").acquirerId("VISA").apiRefNo("95705728").build();
		return transactionRequestDto;

	}

	public static Optional<NetworkMasterRedis> getNetworkMasterRedisData() {
		return Optional.of(NetworkMasterRedis.builder().networkId("OPEN_CAS")
				.endPoint("https://uat-cas-auth.bankopen.co/v1/opencas/transaction").endPointType(EndPointTypeEnum.API)
				.networkName("OPEN CAS HOST").networkType(NetworkTypeEnum.I).timeoutPeriod(5)
				.timeoutAction(TimeoutActionEnum.R).signonFlag(SignonFlagEnum.N).echoFlag(EchoFlagEnum.N)
				.cutOverFlag(CutOverFlagEnum.N).echoInterval(30).build());

	}

	public static TransactionMaster getTransactionMaster() {
		return TransactionMaster.builder().accountIdentification1("_").accountIdentification2("_").mti("0200")
				.proxyCardNumber("OPEN0000007663").tpCode("010000").transactionAmount(new BigDecimal(17))
				.billingAmount(new BigDecimal(25000)).billingFeeAmount(new BigDecimal(0))
				.transactionFeeAmount(new BigDecimal(0)).settlementFeeAmount(new BigDecimal(0))
				.transactionProcessingFeeAmount(new BigDecimal(0)).settlementProcessingFeeAmount(new BigDecimal(0))
				.stan("317612").expiryDate("2501").mcc("6011").acqInstCountryCode("356").posEntryMode("0510")
				.cardSeqNum("0001").posConditionCode("00").acquirerBin("012345678901")
				.track2Data("4034567890123456D030912312345000").rrn("166134430300").cardAcceptorTerminalId("santhosh")
				.cardAcceptorId("CARD ACCEPTOR").transactionCurrencyCode("0840").settlementCurrencyCode("0840")
				.billingCurrencyCode("0840").pinData("06721FFCE82D167E")
				.securityRelatedControlInformation("2001010100000000").securityInfo("NNNNNN").networkType("VISA")
				.channelType("ATM").transactionType("00").issuerBin(ISSUER_BIN).transactionKey(TRANSACTION_KEY)
				.maskedPan("xxxx-xxxx-xxxx-3456")
				.hashedPan(
						"ad7e47739641e52f799b40b98bcc946f146da3503a3c807a14faa7335db544dc048a0d7104f884feb0f9c385c8ff5d4eacc098d03f59f313588e19383c71655e")
				.accountNumber("0000000").acquirerId("VISA").apiRefNo("95705728").availableBalance(new BigDecimal(0))
				.reasonCode("Success Transaction").responseCode("00").transactionStatus("P")
				.reserverFld1("000016010201600000000000000000000000000000000000").transactionAmount(new BigDecimal(17))
				.build();
	}

	public static String getPayload() {
		return "{\n" + "       \"transactionKey\": \"0200166316018400012345678901317612\",\n"
				+ "            \"issuerBin\": \"472657\",\n" + "}";
	}

	public static TransactionRequestDto generateAnotherTransactionRequestJson() {
		TransactionRequestDto transactionRequestDto = TransactionRequestDto.builder().accountIdentification1("_")
				.accountIdentification2("_").accountNumber("087978").accumFlag("*").acqInstCountryCode(356)
				.transactionKey(SAF_TRANSACTION_KEY).transactionAmount(new BigDecimal(17)).channelType("ATM")
				.transactionType("00").issuerBin(ISSUER_BIN).maskedPan("xxxx-xxxx-xxxx-3456")
				.hashedPan(
						"ad7e47739641e52f799b40b98bcc946f146da3503a3c807a14faa7335db544dc048a0d7104f884feb0f9c385c8ff5d4eacc098d03f59f313588e19383c71655e")
				.accountNumber("0000000").acquirerId("VISA").apiRefNo("95705728").build();
		return transactionRequestDto;

	}

	public static TransactionRequestDto generateAnotherTransactionResponseJson() {
		TransactionRequestDto transactionRequestDto = TransactionRequestDto.builder().accountIdentification1("_")
				.accountIdentification2("_").accountNumber("087978").accumFlag("*").acqInstCountryCode(356)
				.transactionKey(SAF_TRANSACTION_KEY).transactionAmount(new BigDecimal(17)).channelType("ATM")
				.transactionType("00").issuerBin(ISSUER_BIN).maskedPan("xxxx-xxxx-xxxx-3456").channelType("ATM")
				.transactionType("00")
				.hashedPan(
						"ad7e47739641e52f799b40b98bcc946f146da3503a3c807a14faa7335db544dc048a0d7104f884feb0f9c385c8ff5d4eacc098d03f59f313588e19383c71655e")
				.accountNumber("0000000").acquirerId("VISA").apiRefNo("95705728").reasonCode("Success Transaction")
				.responseCode("00").build();
		return transactionRequestDto;
	}

	public static Map<String, Object> convertSAFTransactionRequestDtoToMap() {
		ObjectMapper objectMapper = new ObjectMapper();
		TransactionRequestDto transactionRequestDto = generateAnotherTransactionRequestJson();
		return objectMapper.convertValue(transactionRequestDto, new TypeReference<Map<String, Object>>() {
		});
	}

	public static Map<String, Object> convertSAFTransactionResponseDtoToMap() {
		ObjectMapper objectMapper = new ObjectMapper();
		TransactionRequestDto transactionRequestDto = generateAnotherTransactionResponseJson();
		return objectMapper.convertValue(transactionRequestDto, new TypeReference<Map<String, Object>>() {
		});
	}
}
