package money.open.cards.saf.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import money.open.cards.saf.Utils.ProgramNameFinder;
import money.open.cards.saf.Utils.SAFException;
import money.open.cards.saf.Utils.TransactionMasterFinder;
import money.open.cards.saf.dto.TransactionRequestDto;
import money.open.cards.saf.model.SAFTransaction;
import money.open.cards.saf.model.TransactionMaster;
import money.open.cards.saf.redis.model.NetworkMasterRedis;
import money.open.cards.saf.redis.repository.NetworkMasterRedisDao;
import money.open.cards.saf.repository.SAFTransactionRepository;
import money.open.cards.saf.service.impl.SafTransactionServiceImpl;
import static money.open.cards.saf.helper.Helper.generateTransactionRequestJson;
import static money.open.cards.saf.helper.Helper.getTransactionMaster;
import static money.open.cards.saf.helper.Helper.saf_transaction_data_string;
import static money.open.cards.saf.helper.Helper.ISSUER_BIN;
import static money.open.cards.saf.helper.Helper.CHANNEL_TYPE;
import static money.open.cards.saf.helper.Helper.ISSUER_SELECT_ID;
import static money.open.cards.saf.helper.Helper.NETWORK_ID;
import static money.open.cards.saf.helper.Helper.getNetworkMasterRedisData;
import static money.open.cards.saf.helper.Helper.generateTransactionResponseJson;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class SAFTransactionServiceTest {

	@Mock
	private ProgramNameFinder programNameFinder;

	@Mock
	private TransactionMasterFinder transactionMasterFinder;

	@Mock
	private IssuerSelectService issuerSelectUtils;

	@Mock
	private NetworkSelectService networkSelectUtils;

	@Mock
	private NetworkMasterRedisDao networkMasterRedisDao;

	@Mock
	private ExternalAdapterService externalAdapterService;

	@Mock
	private DataService dataService;

	@Mock
	private SAFTransactionRepository safTransactionDao;

	@InjectMocks
	private SafTransactionServiceImpl safTransactionServiceImpl;

	private TransactionMaster transactionMaster;

	private TransactionRequestDto transactionRequest;

	private SAFTransaction safTransaction;
	
	private TransactionRequestDto trasactionResponse;

	private Optional<NetworkMasterRedis> networkMasterRedisData;

	@BeforeEach
	void setUp() throws JsonMappingException, JsonProcessingException {
		MockitoAnnotations.openMocks(this);
		transactionMaster = getTransactionMaster();
		transactionRequest = generateTransactionRequestJson();
		trasactionResponse = generateTransactionResponseJson();
		ObjectMapper objectMapper = new ObjectMapper();
		safTransaction = objectMapper.readValue(saf_transaction_data_string(), SAFTransaction.class);
		networkMasterRedisData = getNetworkMasterRedisData();
	}

	@Test
	void getNetworkMasterDataTest() throws SAFException, JsonProcessingException {
		when(issuerSelectUtils.issuerSelectRedisData(ISSUER_BIN, CHANNEL_TYPE)).thenReturn(ISSUER_SELECT_ID);
		when(networkSelectUtils.networkSelectRedisData(transactionRequest, ISSUER_SELECT_ID)).thenReturn(NETWORK_ID);
		when(networkMasterRedisDao.findById(NETWORK_ID)).thenReturn(networkMasterRedisData);
		Optional<NetworkMasterRedis> actualNetworkMasterRedisData = safTransactionServiceImpl
				.getNetworkMasterData(transactionRequest, transactionMaster);
		assertNotNull(actualNetworkMasterRedisData);
		assertEquals(networkMasterRedisData.get().getNetworkId(), actualNetworkMasterRedisData.get().getNetworkId());
	}	
	
}
