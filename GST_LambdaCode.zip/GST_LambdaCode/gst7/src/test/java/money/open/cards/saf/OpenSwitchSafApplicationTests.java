package money.open.cards.saf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenSwitchSafApplicationTests {

	@Test
	void contextLoads() {
	}

}
