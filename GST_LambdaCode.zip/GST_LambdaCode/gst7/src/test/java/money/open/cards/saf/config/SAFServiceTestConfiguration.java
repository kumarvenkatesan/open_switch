package money.open.cards.saf.config;

import org.springframework.boot.test.context.TestConfiguration;

@TestConfiguration
public class SAFServiceTestConfiguration {

}
