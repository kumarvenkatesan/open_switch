package money.open.cards.saf.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class TransactionMasterTest {

	
	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	void testObjectMethod() {
		TransactionMaster transactionMaster = new TransactionMaster();
		transactionMaster.equals(new TransactionMaster());
		transactionMaster.toString();
		transactionMaster.hashCode();
	}
	
	@Test
	void testAll() {
		TransactionMaster transactionMaster = new TransactionMaster();
		transactionMaster.equals(TransactionMaster.builder().build());
	}
}
