package money.open.cards.saf.mappers;

import org.mapstruct.Mapper;

import money.open.cards.saf.dto.TransactionRequestDto;
import money.open.cards.saf.model.TransactionMaster;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring",unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface TransactionMasterModelMapper {	
	  
	 /**
     * Map entity to data transfer object.
     * @param transactionMaster - transaction master entity.
     * @return transaction request DTO data transfer object
     */
	
	@Mapping(target = "acqInstitutionId" , source = "acquirerInstitutionId")
	@Mapping(target = "acqNetworkId" , source = "networkType")
	@Mapping(target = "cardAcceptorLocation" , source = "cardAcceptorTerminalLocation")
	@Mapping(target = "cardNumber" , source = "proxyCardNumber")
	@Mapping(target = "emvValue" , source = "securityInfo")
	@Mapping(target = "issuerInstId" , source = "issuerInstitutionId")
	@Mapping(target = "cavv" , source = "securityInfo")
	@Mapping(target = "cvv1" , source = "securityInfo")
	@Mapping(target = "cvv2" , source = "securityInfo")
	@Mapping(target = "iCvv" , source = "securityInfo")
	TransactionRequestDto toTransactionRequestDto(TransactionMaster transactionMaster);
}
