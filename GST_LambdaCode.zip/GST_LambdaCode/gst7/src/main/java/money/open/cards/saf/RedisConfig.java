package money.open.cards.saf;

import money.open.cards.saf.Utils.ByteArrToCharacterConverter;
import money.open.cards.saf.Utils.ByteArrayToLocalDateTimeConverter;
import money.open.cards.saf.Utils.CharacterToByteArrConverter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.convert.RedisCustomConversions;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import lombok.extern.slf4j.Slf4j;
import java.util.Arrays;

@Configuration
@Slf4j
@EnableRedisRepositories(basePackages = "money.open.cards.saf.redis.repository")
public class RedisConfig {

    @Value("${redis.host}")
    private String redisHost;

    @Value("${redis.port}")
    private int redisPort;

    @Value("${redis.database.index}")
    private int redisDatabaseIndex;

    @Value("${redis.password}")
    private String redisPassword;

    @Bean
    @Profile("!test")
    public JedisConnectionFactory jedisConnectionFactory(){
        RedisStandaloneConfiguration config = new RedisStandaloneConfiguration(redisHost,redisPort);
        if(StringUtils.isNotEmpty(redisPassword)){
            config.setPassword(redisPassword);
        }
        config.setDatabase(redisDatabaseIndex);
        JedisConnectionFactory connectionFactory = new JedisConnectionFactory(config);
        connectionFactory.afterPropertiesSet();
        log.info("Checking connection with redis :: {}", connectionFactory.getConnection().ping());
        return connectionFactory;
    }

    @Bean
    @Profile("!test")
    public RedisTemplate<String,Object> redisTemplate(){
        RedisTemplate<String,Object> template = new RedisTemplate<>();
        template.setConnectionFactory(jedisConnectionFactory());
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(new StringRedisSerializer());
        return template;
    }

    @Bean
    public RedisCustomConversions redisCustomConversionss() {
        return new RedisCustomConversions(Arrays.asList(new ByteArrayToLocalDateTimeConverter(), new CharacterToByteArrConverter(), new ByteArrToCharacterConverter()));
    }
}
