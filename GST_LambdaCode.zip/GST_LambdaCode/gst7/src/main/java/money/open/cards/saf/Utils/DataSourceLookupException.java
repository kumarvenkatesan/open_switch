package money.open.cards.saf.Utils;

import lombok.Getter;

public class DataSourceLookupException extends RuntimeException{
	
	private static final long serialVersionUID = 1;

    @Getter
    private ResponseCodes responseCodes;

    public DataSourceLookupException(ResponseCodes responseCodes){
        super(responseCodes.getMessage());
        this.responseCodes = responseCodes;
    }


}
