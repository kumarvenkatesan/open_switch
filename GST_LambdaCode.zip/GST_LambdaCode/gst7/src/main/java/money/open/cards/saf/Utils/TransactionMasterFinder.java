package money.open.cards.saf.Utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.saf.model.TransactionMaster;
import money.open.cards.saf.repository.TransactionMasterRepository;

@Slf4j
@Service
public class TransactionMasterFinder {

	@Autowired
    private TransactionMasterRepository transactionMasterRepository;
	
	public TransactionMaster findTransactionKey(String transactionKey) {
		TransactionMaster transactionMaster = transactionMasterRepository.findByTransactionKey(transactionKey);
        log.info("Transaction master data fetched :: {} ", transactionMaster);
		return transactionMaster;	
	}
}
