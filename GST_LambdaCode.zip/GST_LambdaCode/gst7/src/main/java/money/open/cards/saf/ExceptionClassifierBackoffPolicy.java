package money.open.cards.saf;

import java.util.HashMap;
import java.util.Map;

import org.springframework.classify.Classifier;
import org.springframework.classify.ClassifierSupport;
import org.springframework.classify.SubclassClassifier;
import org.springframework.retry.RetryContext;
import org.springframework.retry.backoff.BackOffContext;
import org.springframework.retry.backoff.BackOffInterruptedException;
import org.springframework.retry.backoff.BackOffPolicy;
import org.springframework.retry.backoff.NoBackOffPolicy;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class ExceptionClassifierBackoffPolicy implements BackOffPolicy{

	@Getter
	@Setter
    private class ExceptionClassifierBackoffContext implements BackOffContext, BackOffPolicy {
        private static final long serialVersionUID = 1L;
		Classifier<Throwable, BackOffPolicy> exceptionClassifier = null;
        RetryContext retryContext = null;
        Map<BackOffPolicy, BackOffContext> policyContextMap = new HashMap<>();
        
		public ExceptionClassifierBackoffContext(Classifier<Throwable, BackOffPolicy> exceptionClassifier,
				RetryContext retryContext) {
			super();
			this.exceptionClassifier = exceptionClassifier;
			this.retryContext = retryContext;
		}
		@Override
		public BackOffContext start(RetryContext context) {
			return null;
		}
		@Override
		public void backOff(BackOffContext backOffContext) throws BackOffInterruptedException {
			  BackOffPolicy policy = exceptionClassifier.classify(retryContext.getLastThrowable());
			  BackOffContext policyContext = policyContextMap.get(policy);
			   if (policyContext!=null) {
			          policyContext = policy.start(retryContext);
			          policyContextMap.put(policy, policyContext);
			       }
			    policy.backOff(policyContext);
			
		}
    }
    private Classifier<Throwable, BackOffPolicy> exceptionClassifier = new ClassifierSupport<Throwable, BackOffPolicy>(new NoBackOffPolicy());

    void setPolicyMap(Map<Class<? extends Throwable>, BackOffPolicy> policyMap) {
        exceptionClassifier = new SubclassClassifier<Throwable, BackOffPolicy>(policyMap, new NoBackOffPolicy());
    }

    @Override
	public BackOffContext start(RetryContext context) {
    	return new ExceptionClassifierBackoffContext(exceptionClassifier, context);
    }

    @Override
	public void backOff(BackOffContext backOffContext) throws BackOffInterruptedException {
    	ExceptionClassifierBackoffContext classifierBackOffContext = (ExceptionClassifierBackoffContext) backOffContext;
        classifierBackOffContext.backOff(backOffContext);
    }	
}
