package money.open.cards.saf.enums;

public enum KeyExchgFlagEnum {

    Y,N
}
