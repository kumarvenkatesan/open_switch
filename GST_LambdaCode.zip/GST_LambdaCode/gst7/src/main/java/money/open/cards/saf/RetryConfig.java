package money.open.cards.saf;
import java.util.HashMap;
import java.util.Map;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.backoff.BackOffPolicy;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.ExceptionClassifierRetryPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import money.open.cards.saf.Utils.CallsNotPermittedException;
import money.open.cards.saf.Utils.ConnectionException;
import money.open.cards.saf.Utils.FeignRetryException;
import money.open.cards.saf.Utils.RequestNotPermittedException;

@Configuration
public class RetryConfig {
	
	@Bean
	public RetryTemplate retryTemplate() {
		
		SimpleRetryPolicy timeOutRetryPolicy = new SimpleRetryPolicy();
		timeOutRetryPolicy.setMaxAttempts(2);
		SimpleRetryPolicy exceptionRetryPolicy = new SimpleRetryPolicy();
		exceptionRetryPolicy.setMaxAttempts(3);
		Map<Class<? extends Throwable>, RetryPolicy> policyMap = new HashMap<>();
		policyMap.put(ConnectionException.class, timeOutRetryPolicy);
		policyMap.put(FeignRetryException.class, timeOutRetryPolicy);
		policyMap.put(CallsNotPermittedException.class, exceptionRetryPolicy);
		policyMap.put(RequestNotPermittedException.class, exceptionRetryPolicy);
		ExceptionClassifierRetryPolicy retryPolicy = new ExceptionClassifierRetryPolicy();
		retryPolicy.setPolicyMap(policyMap);
		
		FixedBackOffPolicy timeOutBackOffPolicy = new FixedBackOffPolicy();
		timeOutBackOffPolicy.setBackOffPeriod(5001);
		FixedBackOffPolicy exceptionBackOffPolicy = new FixedBackOffPolicy();
		exceptionBackOffPolicy.setBackOffPeriod(2001);
		Map<Class<? extends Throwable>, BackOffPolicy> backOffPolicyMap = new HashMap<>();
		backOffPolicyMap.put(ConnectionException.class, timeOutBackOffPolicy);
		backOffPolicyMap.put(FeignRetryException.class, timeOutBackOffPolicy);
		backOffPolicyMap.put(CallsNotPermittedException.class, exceptionBackOffPolicy);
		backOffPolicyMap.put(RequestNotPermittedException.class, exceptionBackOffPolicy);
		ExceptionClassifierBackoffPolicy backOffPolicy = new ExceptionClassifierBackoffPolicy();
		backOffPolicy.setPolicyMap(backOffPolicyMap);
	
		RetryTemplate retryTemplate = new RetryTemplate();
		retryTemplate.setRetryPolicy(retryPolicy);
		retryTemplate.setBackOffPolicy(backOffPolicy);
		return retryTemplate;
	}

}
