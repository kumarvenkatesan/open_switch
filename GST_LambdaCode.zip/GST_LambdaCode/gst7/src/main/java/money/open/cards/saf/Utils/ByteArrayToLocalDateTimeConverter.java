package money.open.cards.saf.Utils;

import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.stereotype.Component;
import java.time.LocalDateTime;

@Component
@ReadingConverter
public class ByteArrayToLocalDateTimeConverter implements Converter<byte[], LocalDateTime> {

    @Override
    public LocalDateTime convert(byte[] source) {
        return LocalDateTime.parse(new String(source));
    }
}
