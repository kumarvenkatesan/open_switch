package money.open.cards.saf.service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;
import money.open.cards.saf.Utils.SAFException;
import money.open.cards.saf.redis.model.IssuerSelectRedis;
import money.open.cards.saf.redis.repository.IssuerSelectRedisDao;

@Service
@Slf4j
public class IssuerSelectService {

	@Autowired
	private IssuerSelectRedisDao issuerSelectRedisDao;

	public String issuerSelectRedisData(String issuerBin, String channelType) throws SAFException {

		String issuerSelectId = null;
		List<IssuerSelectRedis> issuerSelectData = issuerSelectRedisDao.findByIssuerBinAndChannelType(issuerBin,
				channelType);
		if (!issuerSelectData.isEmpty()) {
			issuerSelectId = issuerSelectData.get(0).getIssuerSelectId();
		} else {
			List<IssuerSelectRedis> issuerSelectAllData = issuerSelectRedisDao.findByIssuerBinAndChannelType(issuerBin,
					"*");
			if (!issuerSelectAllData.isEmpty()) {
				List<IssuerSelectRedis> issuerSelect =	issuerSelectAllData.stream().filter((p ->(p.getChannelType().equals("*")))).collect(Collectors.toList());
				if(!issuerSelect.isEmpty()) {
				issuerSelectId = issuerSelect.get(0).getIssuerSelectId();	
				}		
			} else {
				log.info("Configuration Not found for aquirer and channel type for issuer bin {} and Channel Type {}",
						issuerBin, channelType);
			}
		}
		log.info("Issuer Select Id:: {}", issuerSelectId);
		return issuerSelectId;	
	}
}
