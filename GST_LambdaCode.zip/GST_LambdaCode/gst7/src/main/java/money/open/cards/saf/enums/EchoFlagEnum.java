package money.open.cards.saf.enums;

public enum EchoFlagEnum {
    Y,N
}
