package money.open.cards.saf.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CustomerIdGenEnum {

    P("Pass"),S("Sequence");
    final String description;
}
