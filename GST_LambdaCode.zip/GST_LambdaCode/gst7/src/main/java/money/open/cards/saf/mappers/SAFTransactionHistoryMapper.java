package money.open.cards.saf.mappers;

import org.mapstruct.Mapper;

import money.open.cards.saf.model.SAFTransaction;
import money.open.cards.saf.model.SAFTransactionHistory;

@Mapper(componentModel = "spring")
public interface SAFTransactionHistoryMapper {

	SAFTransactionHistory toSAFTransactionHistory(SAFTransaction safTransaction);
}
