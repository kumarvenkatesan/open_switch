package money.open.cards.saf.enums;

public enum SignonFlagEnum {
    Y,N
}
