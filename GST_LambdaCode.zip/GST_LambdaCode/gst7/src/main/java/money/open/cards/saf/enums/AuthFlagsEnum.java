package money.open.cards.saf.enums;

public enum AuthFlagsEnum {

    Y,P;
}
