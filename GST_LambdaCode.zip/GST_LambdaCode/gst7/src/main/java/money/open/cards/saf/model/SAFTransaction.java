package money.open.cards.saf.model;

import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;
import com.vladmihalcea.hibernate.type.json.JsonStringType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import money.open.cards.saf.Utils.AbstractEntity;

@Entity
@Table(name="saf_transaction")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@TypeDefs({
    @TypeDef(name = "json", typeClass = JsonStringType.class),
    @TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
})
@Builder(toBuilder = true)
public class SAFTransaction extends AbstractEntity{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="saf_transaction_id")
	private Long saf_transaction_id;
	
	@Column(name = "transaction_key")
	private String transactionKey;
	
	@Type(type="jsonb")
	@Column(name="transaction_request_data",columnDefinition = "json")
	private Map<String, Object> transaction_request_data;
	
	@Type(type = "jsonb")
	@Column(name="transaction_response_data",columnDefinition = "json")
	private Map<String, Object> transaction_response_data;

	@Column(name="transaction_status")
	private String transaction_status;
	
	@Column(name="reason")
	private String reason;
	
	@Column(name="retrycount")
	private int retrycount;
}

