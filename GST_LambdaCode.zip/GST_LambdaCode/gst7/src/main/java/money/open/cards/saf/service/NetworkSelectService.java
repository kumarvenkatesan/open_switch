package money.open.cards.saf.service;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.saf.Utils.ResponseCodes;
import money.open.cards.saf.Utils.SAFException;
import money.open.cards.saf.dto.TransactionRequestDto;
import money.open.cards.saf.redis.model.NetworkSelectRedis;
import money.open.cards.saf.redis.repository.NetworkSelectRedisDao;
import money.open.cards.saf.redis.repository.TransactionKeyRedisDao;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
public class NetworkSelectService {

	@Autowired
	private NetworkSelectRedisDao networkSelectRedisDao;

	@Autowired
	TransactionKeyRedisDao transactionKeyRedisDao;

	public String networkSelectRedisData(TransactionRequestDto transactionRequestDto, String issuerSelectId)
			throws SAFException {

		String acquirerId = transactionRequestDto.getAcquirerId();
		String cardProduct;
		String networkId = null;
		if (StringUtils.isEmpty(transactionRequestDto.getCardProduct())) {
			cardProduct = "*";
		} else {
			cardProduct = transactionRequestDto.getCardProduct();
		}
		String channelType = transactionRequestDto.getChannelType();
		String mti = transactionRequestDto.getMti();
		String tpCode = transactionRequestDto.getTpCode();

		throwExceptionIfEmpty(acquirerId, cardProduct, channelType, mti, tpCode);

		List<NetworkSelectRedis> networkSelectData = networkSelectRedisDao.findByAcquirerIdAndIssuerId(acquirerId,
				issuerSelectId);
		if (!networkSelectData.isEmpty()) {
			List<NetworkSelectRedis> networkSelect = networkSelectData
					.stream().filter(p -> (p.getAcquirerId().equals(acquirerId)
							&& p.getIssuerId().equals(issuerSelectId) && p.getCardProduct().equals(cardProduct)))
					.collect(Collectors.toList());
			if (!networkSelect.isEmpty()) {
				List<NetworkSelectRedis> networkSelect11 = networkSelect.stream()
						.filter(p -> (p.getAcquirerId().equals(acquirerId) && p.getIssuerId().equals(issuerSelectId)
								&& p.getCardProduct().equals(cardProduct) && p.getChannelType().equals(channelType)))
						.collect(Collectors.toList());
				if (!networkSelect11.isEmpty()) {
					List<NetworkSelectRedis> networkSelect111 = networkSelect11.stream()
							.filter(p -> (p.getAcquirerId().equals(acquirerId) && p.getIssuerId().equals(issuerSelectId)
									&& p.getCardProduct().equals(cardProduct) && p.getChannelType().equals(channelType)
									&& p.getMti().equals(mti)))
							.collect(Collectors.toList());
					if (!networkSelect111.isEmpty()) {
						List<NetworkSelectRedis> networkSelect20 = networkSelect111.stream()
								.filter(p -> (p.getAcquirerId().equals(acquirerId)
										&& p.getIssuerId().equals(issuerSelectId)
										&& p.getCardProduct().equals(cardProduct)
										&& p.getChannelType().equals(channelType) && p.getMti().equals(mti)
										&& p.getTpCode().equals(tpCode.substring(0, 2))))
								.collect(Collectors.toList());
						if (!networkSelect20.isEmpty()) {
							networkId = networkSelect20.get(0).getNetworkId();
						} else {
							List<NetworkSelectRedis> networkSelect21 = networkSelect111.stream()
									.filter(p -> (p.getAcquirerId().equals(acquirerId)
											&& p.getIssuerId().equals(issuerSelectId)
											&& p.getCardProduct().equals(cardProduct)
											&& p.getChannelType().equals(channelType) && p.getMti().equals(mti)
											&& p.getTpCode().equals(tpCode.substring(0, 6))))
									.collect(Collectors.toList());
							if (!networkSelect21.isEmpty()) {
								networkId = networkSelect21.get(0).getNetworkId();
							} else {
								List<NetworkSelectRedis> networkSelect8 = networkSelect111.stream()
										.filter(p -> (p.getAcquirerId().equals(acquirerId)
												&& p.getIssuerId().equals(issuerSelectId)
												&& p.getCardProduct().equals(cardProduct)
												&& p.getChannelType().equals(channelType) && p.getMti().equals(mti)
												&& p.getTpCode().equals("*")))
										.collect(Collectors.toList());
								if (!networkSelect8.isEmpty()) {
									networkId = networkSelect8.get(0).getNetworkId();
								} else {
									log.info("Value not Found");
								}
							}
						}
					} else {
						List<NetworkSelectRedis> networkSelect121 = networkSelect11.stream()
								.filter(p -> (p.getAcquirerId().equals(acquirerId)
										&& p.getIssuerId().equals(issuerSelectId)
										&& p.getCardProduct().equals(cardProduct)
										&& p.getChannelType().equals(channelType) && p.getMti().equals("*")))
								.collect(Collectors.toList());
						if (!networkSelect121.isEmpty()) {
							List<NetworkSelectRedis> networkSelect20 = networkSelect121.stream()
									.filter(p -> (p.getAcquirerId().equals(acquirerId)
											&& p.getIssuerId().equals(issuerSelectId)
											&& p.getCardProduct().equals(cardProduct)
											&& p.getChannelType().equals(channelType) && p.getMti().equals("*")
											&& p.getTpCode().equals(tpCode.substring(0, 2))))
									.collect(Collectors.toList());
							if (!networkSelect20.isEmpty()) {
								networkId = networkSelect20.get(0).getNetworkId();
							} else {
								List<NetworkSelectRedis> networkSelect21 = networkSelect121.stream()
										.filter(p -> (p.getAcquirerId().equals(acquirerId)
												&& p.getIssuerId().equals(issuerSelectId)
												&& p.getCardProduct().equals(cardProduct)
												&& p.getChannelType().equals(channelType) && p.getMti().equals("*")
												&& p.getTpCode().equals(tpCode.substring(0, 6))))
										.collect(Collectors.toList());
								if (!networkSelect21.isEmpty()) {
									networkId = networkSelect21.get(0).getNetworkId();
								} else {
									List<NetworkSelectRedis> networkSelect8 = networkSelect121.stream()
											.filter(p -> (p.getAcquirerId().equals(acquirerId)
													&& p.getIssuerId().equals(issuerSelectId)
													&& p.getCardProduct().equals(cardProduct)
													&& p.getChannelType().equals(channelType) && p.getMti().equals("*")
													&& p.getTpCode().equals("*")))
											.collect(Collectors.toList());
									if (!networkSelect8.isEmpty()) {
										networkId = networkSelect8.get(0).getNetworkId();
									} else {
										log.info("Value not Found");
									}
								}
							}
						}
					}
				} else {
					List<NetworkSelectRedis> networkSelect12 = networkSelect.stream()
							.filter(p -> (p.getAcquirerId().equals(acquirerId) && p.getIssuerId().equals(issuerSelectId)
									&& p.getCardProduct().equals(cardProduct) && p.getChannelType().equals("*")))
							.collect(Collectors.toList());
					if (!networkSelect12.isEmpty()) {
						List<NetworkSelectRedis> networkSelect13 = networkSelect12.stream()
								.filter(p -> (p.getAcquirerId().equals(acquirerId)
										&& p.getIssuerId().equals(issuerSelectId)
										&& p.getCardProduct().equals(cardProduct) && p.getChannelType().equals("*")
										&& p.getMti().equals(mti)))
								.collect(Collectors.toList());
						if (!networkSelect13.isEmpty()) {
							List<NetworkSelectRedis> networkSelect20 = networkSelect13.stream()
									.filter(p -> (p.getAcquirerId().equals(acquirerId)
											&& p.getIssuerId().equals(issuerSelectId)
											&& p.getCardProduct().equals(cardProduct) && p.getChannelType().equals("*")
											&& p.getMti().equals(mti) && p.getTpCode().equals(tpCode.substring(0, 2))))
									.collect(Collectors.toList());
							if (!networkSelect20.isEmpty()) {
								networkId = networkSelect20.get(0).getNetworkId();
							} else {
								List<NetworkSelectRedis> networkSelect21 = networkSelect13.stream()
										.filter(p -> (p.getAcquirerId().equals(acquirerId)
												&& p.getIssuerId().equals(issuerSelectId)
												&& p.getCardProduct().equals(cardProduct)
												&& p.getChannelType().equals("*") && p.getMti().equals(mti)
												&& p.getTpCode().equals(tpCode.substring(0, 6))))
										.collect(Collectors.toList());
								if (!networkSelect21.isEmpty()) {
									networkId = networkSelect21.get(0).getNetworkId();
								} else {
									List<NetworkSelectRedis> networkSelect8 = networkSelect20.stream()
											.filter(p -> (p.getAcquirerId().equals(acquirerId)
													&& p.getIssuerId().equals(issuerSelectId)
													&& p.getCardProduct().equals(cardProduct)
													&& p.getChannelType().equals("*") && p.getMti().equals(mti)
													&& p.getTpCode().equals("*")))
											.collect(Collectors.toList());
									if (!networkSelect8.isEmpty()) {
										networkId = networkSelect8.get(0).getNetworkId();
									} else {
										log.info("Value not Found");
									}
								}
							}
						} else {
							List<NetworkSelectRedis> networkSelect14 = networkSelect12.stream()
									.filter(p -> (p.getAcquirerId().equals(acquirerId)
											&& p.getIssuerId().equals(issuerSelectId)
											&& p.getCardProduct().equals(cardProduct) && p.getChannelType().equals("*")
											&& p.getMti().equals("*")))
									.collect(Collectors.toList());
							if (!networkSelect14.isEmpty()) {
								List<NetworkSelectRedis> networkSelect15 = networkSelect14.stream()
										.filter(p -> (p.getAcquirerId().equals(acquirerId)
												&& p.getIssuerId().equals(issuerSelectId)
												&& p.getCardProduct().equals(cardProduct)
												&& p.getChannelType().equals("*") && p.getMti().equals("*")
												&& p.getTpCode().equals(tpCode.substring(0, 2))))
										.collect(Collectors.toList());
								if (!networkSelect15.isEmpty()) {
									networkId = networkSelect15.get(0).getNetworkId();
								} else {
									List<NetworkSelectRedis> networkSelect7 = networkSelect14.stream()
											.filter(p -> (p.getAcquirerId().equals(acquirerId)
													&& p.getIssuerId().equals(issuerSelectId)
													&& p.getCardProduct().equals(cardProduct)
													&& p.getChannelType().equals("*") && p.getMti().equals("*")
													&& p.getTpCode().equals(tpCode.substring(0, 6))))
											.collect(Collectors.toList());
									if (!networkSelect7.isEmpty()) {
										networkId = networkSelect7.get(0).getNetworkId();
									} else {
										List<NetworkSelectRedis> networkSelect8 = networkSelect14.stream()
												.filter(p -> (p.getAcquirerId().equals(acquirerId)
														&& p.getIssuerId().equals(issuerSelectId)
														&& p.getCardProduct().equals(cardProduct)
														&& p.getChannelType().equals("*") && p.getMti().equals("*")
														&& p.getTpCode().equals("*")))
												.collect(Collectors.toList());
										if (!networkSelect8.isEmpty()) {
											networkId = networkSelect8.get(0).getNetworkId();
										} else {
											log.info("Value not Found");
										}
									}
								}
							}
						}
					}
				}
			} else {
				List<NetworkSelectRedis> networkSelect1 = networkSelectData
						.stream().filter(p -> (p.getAcquirerId().equals(acquirerId)
								&& p.getIssuerId().equals(issuerSelectId) && p.getCardProduct().equals("*")))
						.collect(Collectors.toList());
				if (!networkSelect1.isEmpty()) {
					List<NetworkSelectRedis> networkSelect3 = networkSelect1.stream()
							.filter(p -> (p.getAcquirerId().equals(acquirerId) && p.getIssuerId().equals(issuerSelectId)
									&& p.getCardProduct().equals("*") && p.getChannelType().equals(channelType)))
							.collect(Collectors.toList());
					if (!networkSelect3.isEmpty()) {
						List<NetworkSelectRedis> networkSelect5 = networkSelect3.stream()
								.filter(p -> (p.getAcquirerId().equals(acquirerId)
										&& p.getIssuerId().equals(issuerSelectId) && p.getCardProduct().equals("*")
										&& p.getChannelType().equals(channelType) && p.getMti().equals(mti)))
								.collect(Collectors.toList());
						if (!networkSelect5.isEmpty()) {
							List<NetworkSelectRedis> networkSelect27 = networkSelect5.stream()
									.filter(p -> (p.getAcquirerId().equals(acquirerId)
											&& p.getIssuerId().equals(issuerSelectId) && p.getCardProduct().equals("*")
											&& p.getChannelType().equals(channelType) && p.getMti().equals(mti)
											&& p.getTpCode().equals(tpCode.substring(0, 2))))
									.collect(Collectors.toList());
							if (!networkSelect27.isEmpty()) {
								networkId = networkSelect27.get(0).getNetworkId();
							} else {
								List<NetworkSelectRedis> networkSelect28 = networkSelect5.stream()
										.filter(p -> (p.getAcquirerId().equals(acquirerId)
												&& p.getIssuerId().equals(issuerSelectId)
												&& p.getCardProduct().equals("*")
												&& p.getChannelType().equals(channelType) && p.getMti().equals(mti)
												&& p.getTpCode().equals(tpCode.substring(0, 6))))
										.collect(Collectors.toList());
								if (!networkSelect28.isEmpty()) {
									networkId = networkSelect28.get(0).getNetworkId();
								} else {
									List<NetworkSelectRedis> networkSelect9 = networkSelect5.stream()
											.filter(p -> (p.getAcquirerId().equals(acquirerId)
													&& p.getIssuerId().equals(issuerSelectId)
													&& p.getCardProduct().equals("*")
													&& p.getChannelType().equals(channelType) && p.getMti().equals(mti)
													&& p.getTpCode().equals("*")))
											.collect(Collectors.toList());
									if (!networkSelect9.isEmpty()) {
										networkId = networkSelect9.get(0).getNetworkId();
									} else {
										log.info("Value Not Found");
									}
								}
							}
						} else {
							List<NetworkSelectRedis> networkSelect6 = networkSelect3.stream()
									.filter(p -> (p.getAcquirerId().equals(acquirerId)
											&& p.getIssuerId().equals(issuerSelectId) && p.getCardProduct().equals("*")
											&& p.getChannelType().equals(channelType) && p.getMti().equals("*")))
									.collect(Collectors.toList());
							if (!networkSelect6.isEmpty()) {
								List<NetworkSelectRedis> networkSelect7 = networkSelect5.stream()
										.filter(p -> (p.getAcquirerId().equals(acquirerId)
												&& p.getIssuerId().equals(issuerSelectId)
												&& p.getCardProduct().equals("*")
												&& p.getChannelType().equals(channelType) && p.getMti().equals("*")
												&& p.getTpCode().equals(tpCode.substring(0, 2))))
										.collect(Collectors.toList());
								if (!networkSelect7.isEmpty()) {
									networkId = networkSelect7.get(0).getNetworkId();
								} else {
									List<NetworkSelectRedis> networkSelect8 = networkSelect5.stream()
											.filter(p -> (p.getAcquirerId().equals(acquirerId)
													&& p.getIssuerId().equals(issuerSelectId)
													&& p.getCardProduct().equals("*")
													&& p.getChannelType().equals(channelType) && p.getMti().equals("*")
													&& p.getTpCode().equals(tpCode.substring(0, 6))))
											.collect(Collectors.toList());
									if (!networkSelect8.isEmpty()) {
										networkId = networkSelect8.get(0).getNetworkId();
									} else {
										List<NetworkSelectRedis> networkSelect9 = networkSelect6.stream()
												.filter(p -> (p.getAcquirerId().equals(acquirerId)
														&& p.getIssuerId().equals(issuerSelectId)
														&& p.getCardProduct().equals("*")
														&& p.getChannelType().equals(channelType)
														&& p.getMti().equals("*") && p.getTpCode().equals("*")))
												.collect(Collectors.toList());
										if (!networkSelect9.isEmpty()) {
											networkId = networkSelect9.get(0).getNetworkId();
										} else {
											log.info("Value Not Found");
										}
									}
								}
							}
						}
					} else {
						List<NetworkSelectRedis> networkSelect4 = networkSelect1.stream()
								.filter(p -> (p.getAcquirerId().equals(acquirerId)
										&& p.getIssuerId().equals(issuerSelectId) && p.getCardProduct().equals("*")
										&& p.getChannelType().equals("*")))
								.collect(Collectors.toList());
						if (!networkSelect4.isEmpty()) {
							List<NetworkSelectRedis> networkSelect5 = networkSelect4.stream()
									.filter(p -> (p.getAcquirerId().equals(acquirerId)
											&& p.getIssuerId().equals(issuerSelectId) && p.getCardProduct().equals("*")
											&& p.getChannelType().equals("*") && p.getMti().equals(mti)))
									.collect(Collectors.toList());
							if (!networkSelect5.isEmpty()) {
								List<NetworkSelectRedis> networkSelect7 = networkSelect5.stream()
										.filter(p -> (p.getAcquirerId().equals(acquirerId)
												&& p.getIssuerId().equals(issuerSelectId)
												&& p.getCardProduct().equals("*") && p.getChannelType().equals("*")
												&& p.getMti().equals(mti)
												&& p.getTpCode().equals(tpCode.substring(0, 2))))
										.collect(Collectors.toList());
								if (!networkSelect7.isEmpty()) {
									networkId = networkSelect7.get(0).getNetworkId();
								} else {
									List<NetworkSelectRedis> networkSelect17 = networkSelect5.stream()
											.filter(p -> (p.getAcquirerId().equals(acquirerId)
													&& p.getIssuerId().equals(issuerSelectId)
													&& p.getCardProduct().equals("*") && p.getChannelType().equals("*")
													&& p.getMti().equals(mti)
													&& p.getTpCode().equals(tpCode.substring(0, 6))))
											.collect(Collectors.toList());
									if (!networkSelect7.isEmpty()) {
										networkId = networkSelect17.get(0).getNetworkId();
									} else {
										List<NetworkSelectRedis> networkSelect18 = networkSelect5.stream()
												.filter(p -> (p.getAcquirerId().equals(acquirerId)
														&& p.getIssuerId().equals(issuerSelectId)
														&& p.getCardProduct().equals("*")
														&& p.getChannelType().equals("*") && p.getMti().equals(mti)
														&& p.getTpCode().equals("*")))
												.collect(Collectors.toList());
										if (!networkSelect18.isEmpty()) {
											networkId = networkSelect18.get(0).getNetworkId();
										} else {
											log.info("Value not Found");
										}
									}
								}
							} else {
								List<NetworkSelectRedis> networkSelect6 = networkSelect4.stream()
										.filter(p -> (p.getAcquirerId().equals(acquirerId)
												&& p.getIssuerId().equals(issuerSelectId)
												&& p.getCardProduct().equals("*") && p.getChannelType().equals("*")
												&& p.getMti().equals("*")
												&& p.getTpCode().equals(tpCode.substring(0, 2))))
										.collect(Collectors.toList());
								if (!networkSelect6.isEmpty()) {
									networkId = networkSelect6.get(0).getNetworkId();
								} else {
									List<NetworkSelectRedis> networkSelect7 = networkSelect4.stream()
											.filter(p -> (p.getAcquirerId().equals(acquirerId)
													&& p.getIssuerId().equals(issuerSelectId)
													&& p.getCardProduct().equals("*") && p.getChannelType().equals("*")
													&& p.getMti().equals("*")
													&& p.getTpCode().equals(tpCode.substring(0, 6))))
											.collect(Collectors.toList());
									if (!networkSelect7.isEmpty()) {
										networkId = networkSelect7.get(0).getNetworkId();
									} else {
										List<NetworkSelectRedis> networkSelect8 = networkSelect4.stream()
												.filter(p -> (p.getAcquirerId().equals(acquirerId)
														&& p.getIssuerId().equals(issuerSelectId)
														&& p.getCardProduct().equals("*")
														&& p.getChannelType().equals("*") && p.getMti().equals("*")
														&& p.getTpCode().equals("*")))
												.collect(Collectors.toList());
										if (!networkSelect8.isEmpty()) {
											networkId = networkSelect8.get(0).getNetworkId();
										} else {
											log.info("Value not Found");
										}
									}
								}
							}
						}
					}
				} else {
					log.info("Card Product Value not Found");
				}
			}
		}
		log.info("Network Id :: {}", networkId);
		return networkId;
	}

	private void throwExceptionIfEmpty(String acquirerId, String cardProduct, String channelType, String mti,
			String tpCode) throws SAFException {
		Optional.ofNullable(acquirerId).orElseThrow(() -> new SAFException(ResponseCodes.INVALID_ACQUIRER_ID));
		Optional.ofNullable(cardProduct).orElseThrow(() -> new SAFException(ResponseCodes.INVALID_CARD_PRODUCT));
		Optional.ofNullable(channelType).orElseThrow(() -> new SAFException(ResponseCodes.INVALID_CHANNEL_TYPE));
		Optional.ofNullable(mti).orElseThrow(() -> new SAFException(ResponseCodes.INVALID_MTI));
		Optional.ofNullable(tpCode).orElseThrow(() -> new SAFException(ResponseCodes.INVALID_TPCODE));
	}
}
