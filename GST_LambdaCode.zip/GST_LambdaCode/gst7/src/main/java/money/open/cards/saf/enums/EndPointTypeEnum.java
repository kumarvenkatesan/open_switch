package money.open.cards.saf.enums;

public enum EndPointTypeEnum {

    TCP,API
}
