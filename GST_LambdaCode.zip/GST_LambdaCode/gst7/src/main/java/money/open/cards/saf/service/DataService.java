package money.open.cards.saf.service;

import java.util.Map;
import money.open.cards.saf.Utils.SAFException;
import money.open.cards.saf.dto.TransactionRequestDto;
import money.open.cards.saf.model.SAFTransaction;
import money.open.cards.saf.model.SAFTransactionHistory;
import money.open.cards.saf.model.TransactionMaster;

public interface DataService {
	public SAFTransaction createSAFTransactionData(TransactionRequestDto transactionRequest,int retryCount);
	public SAFTransaction updateSAFTransactionResponseData(String transactionKey,TransactionRequestDto transactionResponse) throws SAFException;
    public SAFTransaction updateSAFTransactionStatus(Map<String,String> map,TransactionRequestDto transactionRequest) throws Exception;
    SAFTransaction updateSAFTransactionRequestData(String transactionKey, TransactionRequestDto transactionRequest)
			throws SAFException;
	SAFTransaction updateRetryCount(String transactionKey, int retryCount) throws SAFException;
    TransactionMaster updateTransactionMasterData(TransactionMaster transactionMaster, TransactionRequestDto transactionRequest);
    public void saveSAFTransactionHistoryData(SAFTransactionHistory safTransactionHistory) throws Exception;
    public void deleteSAFTransactionData(String transactionKey) throws Exception;
}
