package money.open.cards.saf.enums;

public enum CardSchemesEnum {

    VISA,MASTER,RUPAY,CUP;
}
