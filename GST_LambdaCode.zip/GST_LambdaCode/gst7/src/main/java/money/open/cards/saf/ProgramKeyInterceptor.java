package money.open.cards.saf;
import money.open.cards.saf.Utils.ResponseCodes;
import money.open.cards.saf.Utils.SAFException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class ProgramKeyInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String programId = request.getHeader("program");
        // Enable this code after multi tenant routing is done
        if(StringUtils.isEmpty(programId))
            throw new SAFException(ResponseCodes.INVALID_PROGRAM_ID);
        ProgramContextHolder.setProgram(programId);
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        ProgramContextHolder.removeCurrentProgram();
    }
}
