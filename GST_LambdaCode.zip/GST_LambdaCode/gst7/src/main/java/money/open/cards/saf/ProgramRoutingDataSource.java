package money.open.cards.saf;

import money.open.cards.saf.Utils.DataSourceLookupException;
import money.open.cards.saf.Utils.ResponseCodes;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import javax.sql.DataSource;

public class ProgramRoutingDataSource extends AbstractRoutingDataSource {
    @Override
    protected Object determineCurrentLookupKey() {
        return ProgramContextHolder.getProgram();
    }

    @Override
    protected DataSource determineTargetDataSource() {
        try {
            return super.determineTargetDataSource();
        } catch (IllegalStateException e){
            throw new DataSourceLookupException(ResponseCodes.INVALID_PROGRAM_ID);
        }
    }
}
