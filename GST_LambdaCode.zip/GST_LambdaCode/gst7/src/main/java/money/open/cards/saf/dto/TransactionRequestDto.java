package money.open.cards.saf.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import money.open.cards.saf.enums.CountryModesEnum;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder(toBuilder = true)
public class TransactionRequestDto {

    private String apiRefNo;
    private String mti;
    private String proxyCardNumber;// proxyCardNo
    private String tpCode;// transaction processing code
    private BigDecimal transactionAmount;// transaction amount
    private BigDecimal settlementAmount;
    private BigDecimal billingAmount;// billing amount
    private BigDecimal billingFeeAmount;
    private BigDecimal transactionFeeAmount;// transaction fee
    private BigDecimal settlementFeeAmount;
    private BigDecimal transactionProcessingFeeAmount;
    private BigDecimal settlementProcessingFeeAmount;
    private String settlementConversionRate;
    private String billingConversionRate;
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime transactionDateTime;// transaction datetime
    private String stan;// stan
    private String localTime;
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "yyyy-MM-dd")
    private LocalDate localDate;
    private String expiryDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "yyyy-MM-dd")
    private LocalDate settlementDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "yyyy-MM-dd")
    private LocalDate conversionDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "yyyy-MM-dd")
    private LocalDate captureDate;
    private String mcc;// mcc
    private int acqInstCountryCode;
    private String fwdInstCountryCode;
    private String posEntryMode;// pos entry mode
    private String cardSeqNum;
    private String posConditionCode;// pos condition code
    private String posPinCaptureCode;
    private String authIdResp;
    private String acquirerBin;// acquirerBin
    private String forwardingInstIdCode;
    private String track2Data;
    private String rrn;// rrn
    private String cardAcceptorTerminalId;// terminalId
    private String cardAcceptorId;// merchantId
    private String cardAcceptorLocation;// terminalLocation
    private String transactionCurrencyCode;
    private String settlementCurrencyCode;
    private String billingCurrencyCode;
    private String pinData;
    private String securityRelatedControlInformation;
    private String settlementInstIdCode;
    private String receivingInstIdCode;
    private String settlementCode;
    private String receivingInstCountryCode;
    private String settlementInstCountryCode;
    private String originalDataElements;
    private String accountIdentification1;
    private String accountIdentification2;
    private String acqNetworkId; // Network Type
    private String acqInstitutionId;// Acquirer Institution Id
    private String channelType;// Channel Type // acquirerChannel
    private String transactionType;// Transaction Type
    private String issuerBin;// IssuerId/IssuerBin
    private String issuerInstId;// Issuer Institution Id
    private String transactionKey;
    private String securityInfo;//<PIN/CVV1/CCV2/EMV/iCVV/CAVV>
    private String securityResult;//<S/F>
    private String accountNumber;
    private String accumFlag;
    private String acquirerId;
    private String issuerId;
    private String networkId;
    private String authNumber;
    private String availableBalance;
    private Date businessDate;
    private String chargeAccumFlag;
    private String cin;
    private BigDecimal drCrAmount;
    private String drCrFlag;
    private String issConvRate;
    private String issCurrencyCode;
    private String kycFlag;
    private String productId;
    private String reasonCode;
    private String responseCode;
    private String responseType; // to identify business or finacial Decline
    private String revAmount;
    private String revFlag;
    private String transactionStatus;
    private int incTxnCount;
    private String reserverFld1;
    private String reserverFld2;
    private String reserverFld3;
    private String reserverFld4;
    private String reserverFld5;
    private String reserverFld6;
    private String reserverFld7;
    private String reserverFld8;
    private String reserverFld9;
    private String reserverFld10;
    private String cardProduct;
    private String acquirerInstitutionId;
    private String networkType;
    private String replyTopic;
    private String issuerInstitutionId;
    private String maskedPan;
    private String hashedPan;
    private Boolean contactlessTransaction; // 0 -- false , 1-- true
    private String cardNumber;
    private CountryModesEnum countryModeEnum;
    private String originalMti;
    private String originalStan;
    private String originalIsoDateAndTime;
    private String originalAcquirerId;
    private String originalForwardingInstIdCode;
    private String primaryHsmId;
    private String cvv1;
    private String cvv2;
    private String emvValue;
    private String iCvv;
    private String cavv;
    private String cvv1ServiceCode;
    private String cvv2ServiceCode;
    private String iCvvServiceCode;
    private Integer pinRetryCount;
    private String limitConfigType;
}
