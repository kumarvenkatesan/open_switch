package money.open.cards.saf.Utils;

import money.open.cards.saf.ProgramContextHolder;
import money.open.cards.saf.redis.model.ProgramMasterRedis;
import money.open.cards.saf.redis.repository.ProgramMasterRedisDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProgramNameFinder {

    @Autowired
    ProgramMasterRedisDao programMasterRedisDao;

    public String getProgramName(String issuerBin) {

        ProgramMasterRedis programKey =  programMasterRedisDao.findByIssuerBinIssuerBin(issuerBin);
        return programKey.getProgramKey();
    }
    
    public void setProgramKey(String issuerBin) {
    	String programKey=  getProgramName(issuerBin);
        ProgramContextHolder.setProgram(programKey);
    }
}
