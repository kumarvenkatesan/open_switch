package money.open.cards.saf.Utils;

import lombok.Getter;

public class SAFException extends Exception {

    private static final long serialVersionUID = 1;
    @Getter
    private ResponseCodes responseCode;
    @Getter
    private String switchResponseCode;

    public SAFException(ResponseCodes responseCodes){
        super(responseCodes.getMessage());
        this.responseCode = responseCodes;
    }

    public SAFException(Throwable t){
        super(t);
    }
    
    public SAFException(ResponseCodes responseCode,String switchResponseCode) {
    	 super(responseCode.getMessage());
         this.responseCode = responseCode;
         this.switchResponseCode = switchResponseCode;
    }
}
