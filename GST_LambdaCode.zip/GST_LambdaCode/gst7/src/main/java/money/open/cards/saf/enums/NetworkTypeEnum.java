package money.open.cards.saf.enums;

public enum NetworkTypeEnum {
    I,N
}
