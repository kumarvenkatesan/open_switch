package money.open.cards.saf.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import money.open.cards.saf.model.SAFTransactionHistory;

@Repository
public interface SAFTransactionHistoryRespository extends JpaRepository<SAFTransactionHistory,Long >{
}
