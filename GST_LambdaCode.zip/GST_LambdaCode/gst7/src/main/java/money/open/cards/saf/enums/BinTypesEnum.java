package money.open.cards.saf.enums;

public enum BinTypesEnum {
    PREPAID,CREDIT,DEBIT;
}
