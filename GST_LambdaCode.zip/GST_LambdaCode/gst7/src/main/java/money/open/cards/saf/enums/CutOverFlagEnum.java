package money.open.cards.saf.enums;

public enum CutOverFlagEnum {
    Y,N
}
