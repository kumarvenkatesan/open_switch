package money.open.cards.saf.Utils;

import java.time.format.DateTimeFormatter;

public class CommonUtils {

  public static final DateTimeFormatter  DATE_YYYY_MM_DD = DateTimeFormatter.ISO_DATE;
  public static final DateTimeFormatter DATE_MMYYYY = DateTimeFormatter.ofPattern("MMyyyy");

}
