package money.open.cards.saf.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import money.open.cards.saf.dto.TransactionRequestDto;
import open.money.external.adapters.dto.EaTransactionRequestDto;

@Mapper(componentModel = "spring")
public interface EaTransactionRequestDtoMapper {
	
	@Mapping(target = "iCvv", source="ICvv")
	@Mapping(target = "iCvvServiceCode", source = "ICvvServiceCode")
	EaTransactionRequestDto toEaTransactionRequestDto(TransactionRequestDto transactionRequestDto);
	
	@Mapping(target = "iCvv", source="ICvv")
	@Mapping(target = "iCvvServiceCode", source = "ICvvServiceCode")
	TransactionRequestDto toTransactionRequestDto(EaTransactionRequestDto eaTransactionRequestDto);
	
}
