package money.open.cards.saf.Utils;

import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.WritingConverter;
import org.springframework.stereotype.Component;

@Component
@WritingConverter
public class ByteArrToCharacterConverter implements Converter<byte[],Character> {

    @Override
    public Character convert(byte[] source) {
        return new String(source).charAt(0);
    }
}
