package money.open.cards.saf.enums;

public enum CvvDateFormatsEnum {
    YYMM,MMYY;
}
