package money.open.cards.saf.Utils;

import lombok.Getter;

public class ConnectionException extends Exception {

	private static final long serialVersionUID = 1;
	@Getter
	private ResponseCodes responseCode;

	public ConnectionException(ResponseCodes responseCodes){
	        super(responseCodes.getMessage());
	        this.responseCode = responseCodes;
	    }

	public ConnectionException(Throwable t){
	        super(t);
	    }
}
