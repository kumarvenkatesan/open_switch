package money.open.cards.saf.Utils;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import java.time.LocalDateTime;

@NoArgsConstructor
@MappedSuperclass
@SuperBuilder(toBuilder = true)
@Getter
@Setter
@EntityListeners(value = PersistenceListener.class)
public abstract class AbstractEntity {

    @Column(nullable = false)
    private String createdBy;
    @Column(nullable = false)
    private LocalDateTime createdAt;
    @Column(nullable = false)
    private String modifiedBy;
    @Column(nullable = false)
    private LocalDateTime modifiedAt;

}
