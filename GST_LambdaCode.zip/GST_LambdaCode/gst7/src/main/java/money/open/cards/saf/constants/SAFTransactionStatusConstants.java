package money.open.cards.saf.constants;

public class SAFTransactionStatusConstants {

    public static String SUCCESS = "SUCCESS";
    public static String FAILURE = "FAILURE";
    public static String SKIPPED = "SKIPPED";
}
