package money.open.cards.saf;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import money.open.cards.saf.redis.model.ProgramMasterRedis;
import money.open.cards.saf.redis.repository.ProgramMasterRedisDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.*;
import org.springframework.core.annotation.Order;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@Configuration
@Slf4j
@EnableAsync
@EnableRedisRepositories(basePackages = "money.open.cards.saf.redis.model")
@EnableJpaRepositories(basePackages = "money.open.cards.saf.repository")
@EntityScan("money.open.cards.saf")
@ComponentScan({"money.open.cards.saf","open.money.external.adapters"})
public class DataSourceConfig {
    
    @Value("10")
    private int hikariPoolSize;

    @Autowired
    private ProgramMasterRedisDao programMasterRedisDao;

    @Getter
    private Map<Object,Object> availableDataSource = new HashMap<>();

    @Value("card_transaction")
    private String schemaName;

    public Map<Object,Object> loadAvailableDataSources(){
      Iterable<ProgramMasterRedis> programMasterRedisIterable = programMasterRedisDao.findAll();
      Iterator<ProgramMasterRedis> programMasterRedisIterator = programMasterRedisIterable.iterator();
      if(!programMasterRedisIterator.hasNext())
      {
          log.info("No datasource available to connect from Redis");
          throw new RuntimeException("No datasource available to connect from Redis");
      }

      while(programMasterRedisIterator.hasNext()){
      ProgramMasterRedis programMasterRedis  =  programMasterRedisIterator.next();
      log.info("Loading DataSource :: {} ",programMasterRedis.getProgramKey());
          HikariConfig config = new HikariConfig();
          config.setJdbcUrl(programMasterRedis.getDbUrl());
          config.setUsername(programMasterRedis.getUsername());
          config.setPassword(programMasterRedis.getPassword());
          config.setSchema(schemaName);
          config.setMaximumPoolSize(hikariPoolSize);
          HikariDataSource dataSource = new HikariDataSource(config);
          availableDataSource.put(programMasterRedis.getProgramKey(),dataSource);
      }
          return availableDataSource;
    }

    @Bean
    @Order(-2)
    @Primary
    @Profile("!test")
    public DataSource dataSource() {
        ProgramRoutingDataSource programRoutingDataSource = new ProgramRoutingDataSource();
        programRoutingDataSource.setTargetDataSources(this.loadAvailableDataSources());
        return programRoutingDataSource;
    }
    @Bean
    public ObjectMapper objectMapper(){
        ObjectMapper mapper = Jackson2ObjectMapperBuilder.json().build();
        mapper.registerModule(new JavaTimeModule());
        return mapper;
    }
    
    @Bean
    public ThreadPoolTaskExecutor asyncTaskExecutor() {
    	ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
    	executor.setMaxPoolSize(20);
    	executor.setCorePoolSize(10);
    	executor.setQueueCapacity(20);
    	executor.setTaskDecorator(new AsyncTaskDecorator());
		return executor;
    } 
}
