package money.open.cards.saf.Utils;

import lombok.Getter;

public class RequestNotPermittedException  extends Exception {
	
private static final long serialVersionUID = 1;
	
	@Getter
	private ResponseCodes responseCodes;

	public RequestNotPermittedException(ResponseCodes responseCodes) {
		super();
		this.responseCodes = responseCodes;
	}

	public RequestNotPermittedException(Throwable cause) {
		super(cause);
	}
}
