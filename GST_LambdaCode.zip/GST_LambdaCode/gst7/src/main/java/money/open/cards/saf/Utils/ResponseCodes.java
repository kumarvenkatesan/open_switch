package money.open.cards.saf.Utils;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
public enum ResponseCodes {

    INVALID_PROGRAM_ID("SAF01","Invalid Program id"),
	INVALID_TRANSACTION_KEY("SAF02","Invalid Transaction Key"),
	INVALID_ISSUER_SELECT_ID("SAF03","Invalid Issuer Bin and Channel Type"),
	INVALID_NETWORK_ID("SAF04","Invalid Network ID"),
	INVALID_NETWORK_MASTER_DATA("SAF05","Invalid network master Data"),
	FAILED_TRANSACTION("SAF06","Failed transaction"),
	TRANSACTION_ALREADY_IN_QUEUE("SAF07","Transaction already in queue"),
	INVALID_ISSUER_BIN("SAF08","Invalid Issuer Bin"),
	SAF_TRANSACTION_RECORD_NOT_FOUND("SAF09","SAF Transaction Record not found"),
	INVALID_TRANSACTION_RESPONSE("SAF10","Transaction response is empty"),
	INVALID_RESPONSE_CODE("SAF11","Invalid response code"),
	INVALID_REASON_CODE("SAF12","Invalid reason code"),
	ORIGINAL_TRANSACTION_RECORD_NOT_FOUND("SAF13","Original Transaction Record not found"),
	INVALID_ENDPOINT("SAF14","Invalid Endpoint"),
	INVALID_CHANNEL_TYPE("SAF15","Invalid Channel Type"),
	INVALID_ACQUIRER_ID("SAF16","Invalid Acquirer Id "),
	INVALID_MTI("SAF17","Invalid MTI"),
	INVALID_CARD_PRODUCT("SAF18","Invalid Card Product"),
	INVALID_TPCODE("SAF19","Invalid TP Code"),
	EMPTY_DATA("SAF20","Empty Data"),
	INVALID_TRANSACTION_AMOUNT("SAF21","Invalid Transaction Amount"),
	INVALID_TRANSACTION_REQUEST("SAF22","Transaction Request is empty"),
	EMPTY_NETWORK_MASTER_REDIS_DATA("SAF23","Empty Network master redis data"),
	INVALID_TRANSACTION("SAF24","Couldn't process the Invalid Transaction"),
	FEIGN_RETRYABLE_EXCEPTION("SAF25","Retryable Exception"),
	CALL_NOT_PERMITTED_EXCEPTION("SAF26","Call Not Permitted Exception"),
	REQUEST_NOT_PERMITTED_EXCEPTION("SAF27","Request not permitted exception"),
	CONNECT_EXCEPTION("SAF28","Connect Timeout Exception");

    @Getter
    String code;

    @Getter
    String message;

}
