package money.open.cards.saf.repository;

import money.open.cards.saf.model.SAFTransaction;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SAFTransactionRepository extends JpaRepository<SAFTransaction,Long > {

	SAFTransaction findByTransactionKey(String transactionKey);
	void deleteByTransactionKey(String transactionKey);
}
