package money.open.cards.saf.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import money.open.cards.saf.Utils.SAFException;
import money.open.cards.saf.dto.TransactionRequestDto;
import money.open.cards.saf.redis.model.NetworkMasterRedis;
import java.util.Optional;

public interface ExternalAdapterService {

    TransactionRequestDto callExternalAdapter(TransactionRequestDto transactionRequestDto, Optional<NetworkMasterRedis> networkMasterRedis) throws JsonProcessingException, SAFException;
}
