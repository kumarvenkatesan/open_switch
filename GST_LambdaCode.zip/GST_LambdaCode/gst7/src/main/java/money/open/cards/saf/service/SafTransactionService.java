package money.open.cards.saf.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import money.open.cards.saf.Utils.SAFException;
import money.open.cards.saf.dto.TransactionRequestDto;

public interface SafTransactionService {
	
	public TransactionRequestDto processTransaction(TransactionRequestDto requestDto) throws SAFException, JsonProcessingException, Exception;
	
	public void updateTransactionStatusData(TransactionRequestDto transactionResponse) throws SAFException;

	public void updateAndDeleteSAFTransactionStatus(String reason, TransactionRequestDto requestDto, String transactionStatus);
	
	public void deleteAndSaveSAFTransactionData(String transactionKey,String transactionStatus) throws Exception;

}
