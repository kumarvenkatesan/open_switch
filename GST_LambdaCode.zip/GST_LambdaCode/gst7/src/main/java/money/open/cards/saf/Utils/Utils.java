package money.open.cards.saf.Utils;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.support.RetrySynchronizationManager;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;
import money.open.cards.saf.dto.TransactionRequestDto;
import money.open.cards.saf.model.SAFTransaction;
import money.open.cards.saf.model.TransactionMaster;
import money.open.cards.saf.repository.SAFTransactionRepository;

@Component
@Slf4j
public class Utils {
	
	@Autowired
	private TransactionMasterFinder transactionMasterFinder;
	
	@Autowired
	private SAFTransactionRepository safTransactionDao;
	
	@Autowired
	private ProgramNameFinder programNameFinder;
	
	public int generateRetryCount() {
		int retryCount = 0;
		retryCount = RetrySynchronizationManager.getContext().getRetryCount() + 1;
		log.info("Method retry count is :" + retryCount);
		return retryCount;
	}
	
	public void throwExceptionIfRequestEmpty(String transactionKey, String issuerBin) throws SAFException {
		Optional.ofNullable(transactionKey).orElseThrow(() -> new SAFException(ResponseCodes.INVALID_TRANSACTION_KEY));
		Optional.ofNullable(issuerBin).orElseThrow(() -> new SAFException(ResponseCodes.INVALID_ISSUER_BIN));
	}
	
	public TransactionMaster findTransactionOrThrowExceptionIfEmpty(String transactionKey) throws SAFException {
		TransactionMaster transactionMaster = transactionMasterFinder.findTransactionKey(transactionKey);
		return Optional.ofNullable(transactionMaster)
				.orElseThrow(() -> new SAFException(ResponseCodes.ORIGINAL_TRANSACTION_RECORD_NOT_FOUND));
	}
	
	public void throwExceptionIfResponseEmpty(TransactionRequestDto transactionResponseDto) throws SAFException {
		Optional.ofNullable(transactionResponseDto)
				.orElseThrow(() -> new SAFException(ResponseCodes.INVALID_TRANSACTION_RESPONSE));
		Optional.ofNullable(transactionResponseDto.getResponseCode())
				.orElseThrow(() -> new SAFException(ResponseCodes.INVALID_RESPONSE_CODE));
		Optional.ofNullable(transactionResponseDto.getReasonCode())
				.orElseThrow(() -> new SAFException(ResponseCodes.INVALID_REASON_CODE));
	}
	
	public SAFTransaction findSafTransactionOrThrowExceptionIfEmpty(String transactionKey) throws SAFException {
		SAFTransaction safTransactionData = safTransactionDao.findByTransactionKey(transactionKey);
		return Optional.ofNullable(safTransactionData)
				.orElseThrow(() -> new SAFException(ResponseCodes.SAF_TRANSACTION_RECORD_NOT_FOUND));
	}
	
	public void setProgamKey(String issuerBin) {
		programNameFinder.setProgramKey(issuerBin);
	}
}
