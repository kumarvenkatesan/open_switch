package money.open.cards.saf.Utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import money.open.cards.saf.dto.TransactionRequestDto;
import money.open.cards.saf.mappers.SAFTransactionHistoryMapper;
import money.open.cards.saf.mappers.TransactionMasterModelMapper;
import money.open.cards.saf.model.SAFTransaction;
import money.open.cards.saf.model.SAFTransactionHistory;
import money.open.cards.saf.model.TransactionMaster;

@Component
@Slf4j
public class ConverterUtils {

	@Autowired
	private ObjectMapper mapper;
	
	@Autowired
	private TransactionMasterModelMapper transactionMasterModelMapper;
	
	@Autowired
	private SAFTransactionHistoryMapper safTransactionHistoryMapper;
	
	public TransactionRequestDto convertPayloadToDto(String payload)
			throws JsonMappingException, JsonProcessingException {
		TransactionRequestDto kafkaTransactionRequest = null;
		log.info("Payload :: {} ",payload);
		kafkaTransactionRequest = mapper.readValue(payload, TransactionRequestDto.class);
		return kafkaTransactionRequest;
	}
	
	public TransactionRequestDto convertTransactionMasterToTransactionDto(TransactionMaster transactionMaster) {
		TransactionRequestDto transactionRequestDto = transactionMasterModelMapper.toTransactionRequestDto(transactionMaster);
		log.info("Converted Transaction Request Data :: {} ", transactionRequestDto);
		return transactionRequestDto;
	}
	
	public SAFTransactionHistory convertSAFTransactionToHistoryData(SAFTransaction safTransactionData) {
		SAFTransactionHistory safHistoryData = safTransactionHistoryMapper.toSAFTransactionHistory(safTransactionData);
		return safHistoryData;
	}
}

