package money.open.admin.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import money.open.admin.constants.AuthFlags;
import money.open.admin.constants.BinTypes;
import money.open.admin.constants.CardSchemes;
import money.open.admin.constants.Status;
import money.open.admin.models.dto.issuer.IssuerBinDto;
import money.open.admin.models.entities.Institution;
import money.open.admin.models.entities.Issuer;

public class Helper {

    private Helper() {

    }

    public static final String INSTITUTION_NAME = "Yes Bank";
    public static final String INSTITUTION_ID = "YES";
    public static final String PARTNER_ID = "OPEN";
    public static final String LIMIT_MASTER_ENTITY_ID = "OPENLENDING";
    public static final Long LIMIT_MASTER_ID = 1L;
    public static final String VENDOR_MASTER_ID = "MCT";
    public static final String VENDOR_MASTER_SCHEME = "VISA";
    public static final String HSM_MASTER_ID = "PRIMARY";
    public static final String KEYMAPPER_PARTNERKEY = "PARTNERID";
    public static final String KEYMAPPER_PARTNERENTITYID = "partnerEntityId";
    public static final String KEYMAPPER_INSTITUTIONKEY = "INSTITUTIONID";
    public static final String KEYMAPPER_INSTITUTIONID = "institutionId";
    public static final String KEY_RULE_ID = "dynamic";
    public static final String HSM_MODEL = "SAFENET";
    public static final String ISSUER_BIN = "434460";
    public static final String ISSUER_KEY = "ISSUER1";
    public static final String ISS_WORKING_KEY = "1PUNE000,5FCE43D796DCB4E8213DF25A91DA737EE5D6E597E994D1D8,8073EDCB3E8859F5";
    public static final String NETWORK_KEY_ID = "zwitch";
    public static final Long PROGRAM_MASTER_ID = 2L;
    public static final String CARD_DESIGN_ID = "MCT_CARD_DESIGN";
    public static final String CARD_PRODUCT_ID = "OPENLENDING";
    public static final String ADMIN_URL = "/admin";
    public static final String INSTITUTION_URL = ADMIN_URL + "/institution";
    public static final String INSTITUTION_BY_ID_URL = INSTITUTION_URL + "/" + INSTITUTION_ID;
    public static final String PARTNER_URL = ADMIN_URL + "partner";
    public static final String PARTNER_BY_ID_URL = PARTNER_URL + "/" + PARTNER_ID;
    public static final String ISSUER_BIN_URL = ADMIN_URL + "/issuer";


    public static String institution_json_string() {
        return "{\n" +
                "            \"status\": \"DELETED\",\n" +
                "            \"institutionId\": \"YES\",\n" +
                "            \"institutionCode\": \"03\",\n" +
                "            \"institutionName\": \"Yes Bank\",\n" +
                "            \"institutionType\": \"FIN\",\n" +
                "            \"baseCurrencyCode\": \"356\",\n" +
                "            \"alphaCurrencyCode\": \"INR\",\n" +
                "            \"alpha2CountryCode\": \"IN\",\n" +
                "            \"alpha3CountryCode\": \"INR\",\n" +
                "            \"countryCode\": \"356\",\n" +
                "            \"primaryBin\": \"999999\",\n" +
                "            \"externalId\": \"999999\",\n" +
                "            \"externalIdDesc\": \"NA\",\n" +
                "            \"pciVaultId\": \"1\",\n" +
                "            \"maxPinCount\": 3,\n" +
                "            \"primaryHsmId\": \"HSM001\",\n" +
                "            \"fallbackHsmId\": \"HSM002\"\n" +
                "        }";
    }

    public static String partner_json_string() {
        return "{ \"status\": null,\n" +
                "        \"remarks\": null,\n" +
                "        \"partnerEntityId\": \"OPEN\",\n" +
                "        \"description\": \"OPEN FINANCIAL TECHNOLOGIES\",\n" +
                "        \"productCodeLen\": 12,\n" +
                "        \"customerIdGen\": \"P\",\n" +
                "        \"customerIdFormat\": \"NA\",\n" +
                "        \"customerIdLen\": 16\n" +
                "    }";
    }

    public static String issuer_json_string() {
        return "{\n" +
                "        \"status\": \"INACTIVE\",\n" +
                "        \"remarks\": null,\n" +
                "        \"issuerBin\": \"434460\",\n" +
                "        \"institutionId\": \"YES\",\n" +
                "        \"binDesc\": \"VISA CREDIT\",\n" +
                "        \"binType\": \"CREDIT\",\n" +
                "        \"cardScheme\": \"VISA\",\n" +
                "        \"issuerKeyId\": \"434460\",\n" +
                "        \"cmsFlag\": \"Y\",\n" +
                "        \"authFlag\": \"Y\",\n" +
                "        \"tfaFlag\": \"Y\",\n" +
                "        \"cardLen\": 16,\n" +
                "        \"pinLen\": 4,\n" +
                "        \"cvv1ServiceCode\": \"206\",\n" +
                "        \"cvv1Fdate\": \"YYMM\",\n" +
                "        \"cvv2ServiceCode\": \"206\",\n" +
                "        \"cvv2Fdate\": \"MMYY\",\n" +
                "        \"icvvServiceCode\": \"521\",\n" +
                "        \"icvvFdate\": \"YYMM\"\n" +
                "    }";
    }

    public static String limit_master_json_string() {
        return "{\n" +
                "            \"pkey\": 1,\n" +
                "            \"limitConfigId\": \"LIMIT_JUPITER\",\n" +
                "            \"partnerEntityId\": \"JUPITER\",\n" +
                "            \"entityId\": \"OPENLENDING\",\n" +
                "            \"entityType\": \"CRDPROD\",\n" +
                "            \"countryMode\": \"D\",\n" +
                "            \"tpCode\": \"01\",\n" +
                "            \"dailyLimit\": 10000.0000,\n" +
                "            \"dailyCount\": 10,\n" +
                "            \"monthlyLimit\": 10000.0000,\n" +
                "            \"monthlyCount\": 10,\n" +
                "            \"channel\": \"ATM\"\n" +
                "        }";
    }

    public static String hsm_master_json_string() {
        return "{\n" +
                "            \"id\": \"PRIMARY\",\n" +
                "            \"hsmModel\": \"SAFENET\",\n" +
                "            \"hsmType\": \"S\",\n" +
                "            \"hsmIp\": \"localhost\",\n" +
                "            \"hsmPort\": 8504,\n" +
                "            \"hsmTcpHeaderType\": \"H\",\n" +
                "            \"hsmTcpHeaderLen\": 2,\n" +
                "            \"hsmMsgHeaderLen\": 4,\n" +
                "            \"timeout\": 30,\n" +
                "            \"reconnectInterval\": 30,\n" +
                "            \"hsmStatus\": \"1\",\n" +
                "            \"description\": null\n" +
                "        }";
    }

    public static String vendor_master_json_string() {
        return "{\n" +
                "            \"vendorId\": \"MCT\",\n" +
                "            \"vendorName\": \"MCT\",\n" +
                "            \"scheme\": \"VISA\",\n" +
                "            \"endPointType\": \"SFTP\",\n" +
                "            \"endPoint\": \"http://test-endpoint\",\n" +
                "            \"fileType\": \"TXT\",\n" +
                "            \"fileNameFormat\": \"#BATCH_ID|$US|#BATCH_NO|$US|#CARD_DESIGN_ID\",\n" +
                "            \"minCount\": 1,\n" +
                "            \"maxCount\": 10,\n" +
                "            \"uploadFrequency\": null,\n" +
                "            \"contactMobile1\": null,\n" +
                "            \"contactMobile2\": null,\n" +
                "            \"contactMobile3\": null,\n" +
                "            \"contactEmail1\": null,\n" +
                "            \"contactEmail2\": null,\n" +
                "            \"contactEmail3\": null\n" +
                "        }";
    }

    public static String issuer_key_json_string() {
        return "{\n" +
                "            \"issuerKeyId\": \"ISSUER1\",\n" +
                "            \"pinVerMethod\": \"I\",\n" +
                "            \"keyStore\": \"I\",\n" +
                "            \"keyLen\": 32,\n" +
                "            \"pinKey\": \"1\",\n" +
                "            \"pinKeyKcv\": \"1\",\n" +
                "            \"cvvKey\": \"1\",\n" +
                "            \"cvvKeyKcv\": \"1\",\n" +
                "            \"chipAcKey\": \"1\",\n" +
                "            \"chipAcKeyKcv\": \"1\",\n" +
                "            \"decTable\": \"012345678912345\",\n" +
                "            \"pinPadChar\": \"1\",\n" +
                "            \"panPadChar\": \"1\",\n" +
                "            \"pinLen\": 4,\n" +
                "            \"panLen\": 16,\n" +
                "            \"panValLen\": 12,\n" +
                "            \"panValOffset\": 1,\n" +
                "            \"pinblockFormat\": \"1\",\n" +
                "            \"pvki\": \"1\",\n" +
                "            \"cdol1\": \"1\"\n" +
                "        }";
    }

    public static String network_key_json_string() {
        return  "        {\n" +
                "            \"networkKeyId\": \"zwitch\",\n" +
                "            \"keyStore\": \"I\",\n" +
                "            \"keyLen\": 32,\n" +
                "            \"zonalMasterKey\": \"1\",\n" +
                "            \"zonalMasterKeyKcv\": \"1\",\n" +
                "            \"acqWorkingKey\": \"1\",\n" +
                "            \"acqWorkingKeyKcv\": \"1\",\n" +
                "            \"issWorkingKey\": \"1PUNE000,5FCE43D796DCB4E8213DF25A91DA737EE5D6E597E994D1D8,8073EDCB3E8859F5\",\n" +
                "            \"issWorkingKeyKcv\": \"1\",\n" +
                "            \"description\": null\n" +
                "        }";
    }

    public static String program_master_json_string() {
        return "{\n" +
                "            \"programMasterId\": 2,\n" +
                "            \"institutionId\": \"YES\",\n" +
                "            \"issuerBin\": \"434460\",\n" +
                "            \"partnerEntityId\": \"OPEN\",\n" +
                "            \"description\": \"VISA CREDIT\",\n" +
                "            \"dbUrl\": \"something\",\n" +
                "            \"programKey\": \"db schema\",\n" +
                "            \"username\": \"username\",\n" +
                "            \"password\": \"encrypted pwd\"\n" +
                "        }";
    }

    public static String card_product_json_string() {
        return "{\n" +
                "            \"status\": null,\n" +
                "            \"remarks\": null,\n" +
                "            \"cardProductId\": \"OPENLENDING\",\n" +
                "            \"programMasterId\": 2,\n" +
                "            \"productName\": \"OPEN LENDING\",\n" +
                "            \"cardType\": \"P\",\n" +
                "            \"cardVariant\": \"MG\",\n" +
                "            \"cardTypeId\": \"02\",\n" +
                "            \"cardGenType\": \"P\",\n" +
                "            \"cardGenFormat\": \"#ISSUERBIN|#CRDTYPEID|#SEQNO\",\n" +
                "            \"expiryPeriod\": 90,\n" +
                "            \"cardMaintenanceReq\": \"Y\",\n" +
                "            \"pinGenReq\": \"Y\",\n" +
                "            \"pinPrintMethod\": \"I\",\n" +
                "            \"countryMode\": \"D\",\n" +
                "            \"kycMode\": \"F\",\n" +
                "            \"defaultChannel\": \"YYY\",\n" +
                "            \"transactionGroupId\": \"1\",\n" +
                "            \"limitFlag\": \"Y\",\n" +
                "            \"currencyMode\": \"S\",\n" +
                "            \"persoVendorId\": \"1\",\n" +
                "            \"persoFileId\": \"1\",\n" +
                "            \"proxyCardLen\": 13,\n" +
                "            \"proxyCardFormat\": \"#PARTNERID|#SEQNO\",\n" +
                "            \"cardOrderLen\": 9,\n" +
                "            \"cardOrderFormat\": \"#INSTITUTIONID|#SEQNO\",\n" +
                "            \"pinForgot\": \"N\",\n" +
                "            \"reissueCard\": \"N\",\n" +
                "            \"reissuePeriod\": \"N\",\n" +
                "            \"defaultCardSeq\": \"1\",\n" +
                "            \"defaultEmbossName\": \"TEST\",\n" +
                "            \"cardProductCode\": \"NA\",\n" +
                "            \"issuerKeyId\": \"NA\",\n" +
                "            \"diEnabled\": \"N\",\n" +
                "            \"vendorId\": \"MCT\",\n" +
                "            \"cardDesignId\": \"MCT_CARD_DESIGN\",\n" +
                "            \"deliveryAddress\": \"OPEN_HO\"\n" +
                "        }";
    }

    public static Issuer issuer() throws JsonProcessingException {
        return Issuer.builder()
                .status(Status.INACTIVE)
                .issuerBin("434460")
                .issuerKeyId("434460")
                .binDesc("VISA CREDIT")
                .binType(BinTypes.CREDIT)
                .cardScheme(CardSchemes.VISA)
                .cardLen(16)
                .pinLen(4)
                .remarks("remarks")
                .authFlag(AuthFlags.Y)
                .icvvServiceCode("521")
                .institutionId(institution())
                .cvv1ServiceCode("206")
                .cvv2ServiceCode("206")
                .build();
    }

    public static IssuerBinDto issuerBinDto() throws JsonProcessingException {
        return IssuerBinDto.builder()
                .status(Status.INACTIVE)
                .issuerBin("434460")
                .issuerKeyId("434460")
                .binDesc("VISA CREDIT")
                .binType("CREDIT")
                .cardScheme("VISA")
                .cardLen(16)
                .pinLen(4)
                .remarks("remarks")
                .authFlag("Y")
                .icvvServiceCode("521")
                .institutionId("YES")
                .cvv1ServiceCode("206")
                .cvv2ServiceCode("206")
                .build();
    }

    public static Institution institution() throws JsonProcessingException {
        return new ObjectMapper().readValue(institution_json_string(), Institution.class);
    }
}
