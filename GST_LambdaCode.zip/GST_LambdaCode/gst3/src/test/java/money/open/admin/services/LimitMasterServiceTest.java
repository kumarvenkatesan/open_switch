package money.open.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import money.open.admin.dao.impl.LimitMasterDao;
import money.open.admin.models.dto.LimitMasterDto;
import money.open.admin.models.entities.LimitMaster;
import money.open.admin.exceptions.AdminException;
import money.open.admin.mappers.LimitMasterModelMapper;
import money.open.admin.services.impl.LimitMasterServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.List;
import java.util.Optional;

import static money.open.admin.helper.Helper.LIMIT_MASTER_ENTITY_ID;
import static money.open.admin.helper.Helper.LIMIT_MASTER_ID;
import static money.open.admin.helper.Helper.limit_master_json_string;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class LimitMasterServiceTest {

    @InjectMocks
    private LimitMasterServiceImpl limitMasterService;

    @Mock
    private LimitMasterDao limitMasterDao;

    @Mock
    private LimitMasterModelMapper mapper;

    private LimitMasterDto limitMasterDto;
    private LimitMaster limitMaster;

    @BeforeEach
    void setup() throws JsonProcessingException {
        MockitoAnnotations.openMocks(this);
        ObjectMapper objectMapper = new ObjectMapper();
        limitMasterDto = objectMapper.readValue(limit_master_json_string(), LimitMasterDto.class);
        limitMaster = objectMapper.readValue(limit_master_json_string(), LimitMaster.class);
    }

    @Test
    void findAllLimitMasterTest() {
        List<LimitMaster> limitMasters = List.of(limitMaster);
        when(limitMasterDao.findAll()).thenReturn(limitMasters);
        when(mapper.toLimitMasterDtoList(limitMasters)).thenReturn(List.of(limitMasterDto));
        List<LimitMasterDto> limitMasterDtos = limitMasterService.fetchAll();
        assertNotNull(limitMasterDtos);
        assertEquals(LIMIT_MASTER_ENTITY_ID, limitMasterDtos.get(0).getEntityId());
    }

    @Test
    void findLimitMasterByIdTest() throws AdminException {
        when(limitMasterDao.findById(LIMIT_MASTER_ID)).thenReturn(Optional.of(limitMaster));
        when(mapper.toLimitMasterDto(limitMaster)).thenReturn(limitMasterDto);
        LimitMasterDto limitMasterDto1 = limitMasterService.fetchById(LIMIT_MASTER_ID);
        assertNotNull(limitMasterDto1);
        assertEquals(LIMIT_MASTER_ENTITY_ID, limitMasterDto1.getEntityId());
    }

    @Test
    void createLimitMasterTest() throws AdminException {
        when(mapper.toLimitMasterEntity(limitMasterDto)).thenReturn(limitMaster);
        when(limitMasterDao.save(limitMaster)).thenReturn(limitMaster);
        when(mapper.toLimitMasterDto(limitMaster)).thenReturn(limitMasterDto);
        LimitMasterDto limitMasterDto1 = limitMasterService.create(limitMasterDto);
        assertNotNull(limitMasterDto1);
        assertEquals(LIMIT_MASTER_ENTITY_ID, limitMasterDto1.getEntityId());
    }

    @Test
    void deleteLimitMasterTest() throws AdminException {
        doNothing().when(limitMasterDao).deleteById(LIMIT_MASTER_ID);
        doNothing().when(limitMasterDao).updateRedis(limitMaster);
        when(limitMasterDao.findById(LIMIT_MASTER_ID)).thenReturn(Optional.of(limitMaster));
        limitMasterService.performSoftDelete(LIMIT_MASTER_ID);
        verify(limitMasterDao, times(1)).deleteById(LIMIT_MASTER_ID);
    }

    @Test
    void updateLimitMasterTest() throws AdminException {
        when(limitMasterDao.findById(LIMIT_MASTER_ID)).thenReturn(Optional.of(limitMaster));
        when(mapper.toLimitMasterEntity(limitMasterDto)).thenReturn(limitMaster);
        when(limitMasterDao.update(limitMaster)).thenReturn(limitMaster);
        when(mapper.toLimitMasterDto(limitMaster)).thenReturn(limitMasterDto);
        LimitMasterDto limitMasterDto1 = limitMasterService.update(LIMIT_MASTER_ID, limitMasterDto);
        assertNotNull(limitMasterDto1);
        assertEquals(LIMIT_MASTER_ENTITY_ID, limitMasterDto1.getEntityId());
    }
}
