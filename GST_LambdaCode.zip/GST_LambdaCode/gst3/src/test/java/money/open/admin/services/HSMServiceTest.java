package money.open.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import money.open.admin.dao.impl.HsmMasterDao;
import money.open.admin.models.dto.HsmMasterDto;
import money.open.admin.models.entities.HsmMaster;
import money.open.admin.exceptions.AdminException;
import money.open.admin.mappers.HsmMasterModelMapper;
import money.open.admin.services.impl.HsmMasterServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.List;
import java.util.Optional;

import static money.open.admin.helper.Helper.HSM_MASTER_ID;
import static money.open.admin.helper.Helper.HSM_MODEL;
import static money.open.admin.helper.Helper.hsm_master_json_string;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class HSMServiceTest {

    @InjectMocks
    private HsmMasterServiceImpl hsmMasterService;
    @Mock
    private HsmMasterDao hsmMasterDao;
    @Mock
    private HsmMasterModelMapper mapper;

    private HsmMasterDto hsmMasterDto;
    private HsmMaster hsmMaster;

    @BeforeEach
    void setup() throws JsonProcessingException {
        MockitoAnnotations.openMocks(this);
        ObjectMapper objectMapper = new ObjectMapper();
        hsmMasterDto = objectMapper.readValue(hsm_master_json_string(), HsmMasterDto.class);
        hsmMaster = objectMapper.readValue(hsm_master_json_string(), HsmMaster.class);
    }

    @Test
    void findAllHSMTest() {
        List<HsmMaster> hsmMasters = List.of(hsmMaster);
        when(hsmMasterDao.findAll()).thenReturn(hsmMasters);
        when(mapper.toHsmMasterDtoList(hsmMasters)).thenReturn(List.of(hsmMasterDto));
        List<HsmMasterDto> hsmMasterDtos = hsmMasterService.fetchAll();
        assertNotNull(hsmMasterDtos);
        assertEquals(HSM_MODEL, hsmMasterDtos.get(0).getHsmModel());
    }

    @Test
    void findHSMByIdTest() throws AdminException {
        when(hsmMasterDao.findById(HSM_MASTER_ID)).thenReturn(Optional.of(hsmMaster));
        when(mapper.toHsmMasterDto(hsmMaster)).thenReturn(hsmMasterDto);
        HsmMasterDto hsmMasterDto1 = hsmMasterService.fetchById(HSM_MASTER_ID);
        assertNotNull(hsmMasterDto1);
        assertEquals(HSM_MODEL, hsmMasterDto1.getHsmModel());
    }

    @Test
    void createHSMTest() throws AdminException {
        when(mapper.toHsmMasterEntity(hsmMasterDto)).thenReturn(hsmMaster);
        when(hsmMasterDao.save(hsmMaster)).thenReturn(hsmMaster);
        when(mapper.toHsmMasterDto(hsmMaster)).thenReturn(hsmMasterDto);
        HsmMasterDto hsmMasterDto1 = hsmMasterService.create(hsmMasterDto);
        assertNotNull(hsmMasterDto1);
        assertEquals(HSM_MODEL, hsmMasterDto1.getHsmModel());
    }

    @Test
    void deleteHSMTest() throws AdminException {
        doNothing().when(hsmMasterDao).deleteById(HSM_MASTER_ID);
        doNothing().when(hsmMasterDao).updateRedis(hsmMaster);
        when(hsmMasterDao.findById(HSM_MASTER_ID)).thenReturn(Optional.of(hsmMaster));
        hsmMasterService.performSoftDelete(HSM_MASTER_ID);
        verify(hsmMasterDao, times(1)).deleteById(HSM_MASTER_ID);
    }

    @Test
    void updateHSMTest() throws AdminException {
        when(hsmMasterDao.findById(HSM_MASTER_ID)).thenReturn(Optional.of(hsmMaster));
        when(mapper.toHsmMasterEntity(hsmMasterDto)).thenReturn(hsmMaster);
        when(hsmMasterDao.update(hsmMaster)).thenReturn(hsmMaster);
        when(mapper.toHsmMasterDto(hsmMaster)).thenReturn(hsmMasterDto);
        HsmMasterDto hsmMasterDto1 = hsmMasterService.update(HSM_MASTER_ID, hsmMasterDto);
        assertNotNull(hsmMasterDto1);
        assertEquals(HSM_MODEL, hsmMasterDto1.getHsmModel());
    }

}
