//package money.open.admin.controllers;
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import money.open.admin.config.AdminServiceTestConfiguration;
//import money.open.admin.models.dto.InstitutionDto;
//import money.open.admin.models.entities.Institution;
//import money.open.admin.services.InstitutionService;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.MockitoAnnotations;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.http.MediaType;
//import org.springframework.test.context.TestExecutionListeners;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
//
//import java.util.List;
//
//import static money.open.admin.helper.Helper.institution_json_string;
//import static money.open.admin.helper.Helper.INSTITUTION_BY_ID_URL;
//import static money.open.admin.helper.Helper.INSTITUTION_ID;
//import static money.open.admin.helper.Helper.INSTITUTION_URL;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//
//@ExtendWith(SpringExtension.class)
//@SpringBootTest(classes = AdminServiceTestConfiguration.class)
//@AutoConfigureMockMvc
//@TestExecutionListeners( { DependencyInjectionTestExecutionListener.class })
//class InstitutionControllerTests {
//
//    @Autowired
//    private MockMvc mockMvc;
//
//    @Autowired
//    private ObjectMapper objectMapper;
//
//    @Mock
//    private InstitutionService institutionService;
//
//    private InstitutionDto institutionDto;
//    private Institution institution;
//
//    @BeforeEach
//    public void init() throws JsonProcessingException {
//        MockitoAnnotations.openMocks(this);
//        institutionDto = objectMapper.readValue(institution_json_string(), InstitutionDto.class);
//        institution = objectMapper.readValue(institution_json_string(), Institution.class);
//    }
//
//    @Test
//    void getAllInstitutionsTest() throws Exception {
//        Mockito.when(institutionService.fetchAll()).thenReturn(List.of(institutionDto));
//        mockMvc.perform(MockMvcRequestBuilders.get(INSTITUTION_URL + "s").contentType(MediaType.APPLICATION_JSON))
//                .andExpect(status().isOk());
//    }
//
//    @Test
//    void getInstitutionByIdTest() throws Exception {
//        Mockito.when(institutionService.fetchById(INSTITUTION_ID)).thenReturn(institutionDto);
//        mockMvc.perform(MockMvcRequestBuilders.get(INSTITUTION_BY_ID_URL).contentType(MediaType.APPLICATION_JSON))
//                .andExpect(status().isOk());
//    }
//
//    @Test
//    void createInstitutionTest() throws Exception {
//        Mockito.when(institutionService.create(institutionDto)).thenReturn(institutionDto);
//        mockMvc.perform(MockMvcRequestBuilders
//                        .post(INSTITUTION_URL)
//                        .content(objectMapper.writeValueAsString(institutionDto))
//                        .contentType(MediaType.APPLICATION_JSON))
//                        .andExpect(status().isOk());
//    }
//}