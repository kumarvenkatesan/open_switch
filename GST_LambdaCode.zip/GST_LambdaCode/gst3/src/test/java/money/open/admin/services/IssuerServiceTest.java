package money.open.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import money.open.admin.dao.impl.InstitutionDao;
import money.open.admin.dao.impl.IssuerDao;
import money.open.admin.models.dto.issuer.IssuerBinDto;
import money.open.admin.models.entities.Institution;
import money.open.admin.models.entities.Issuer;
import money.open.admin.exceptions.AdminException;
import money.open.admin.helper.Helper;
import money.open.admin.mappers.IssuerModelMapper;
import money.open.admin.services.impl.IssuerServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.List;
import java.util.Optional;

import static money.open.admin.helper.Helper.INSTITUTION_ID;
import static money.open.admin.helper.Helper.ISSUER_BIN;
import static money.open.admin.helper.Helper.institution;
import static money.open.admin.helper.Helper.issuer;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class IssuerServiceTest {

    @InjectMocks
    private IssuerServiceImpl issuerService;

    @Mock
    private IssuerDao issuerDao;

    @Mock
    private InstitutionDao institutionDao;

    @Mock
    private IssuerModelMapper mapper;

    private IssuerBinDto issuerBinDto;
    private Issuer issuer;
    private Institution institution;

    @BeforeEach
    void setup() throws JsonProcessingException {
        MockitoAnnotations.openMocks(this);
        issuer = issuer();
        issuerBinDto = Helper.issuerBinDto();
        institution = institution();
    }

    @Test
    void findAllIssuerBinTest() {
        List<Issuer> issuerBins = List.of(issuer);
        when(issuerDao.findAll()).thenReturn(issuerBins);
        when(mapper.toIssuerBinDtoList(issuerBins)).thenReturn(List.of(issuerBinDto));
        List<IssuerBinDto> issuerBinDtos = issuerService.issuers();
        assertNotNull(issuerBinDtos);
        assertEquals(ISSUER_BIN, issuerBinDtos.get(0).getIssuerBin());
    }

    @Test
    void findIssuerByBinTest() throws AdminException, JsonProcessingException {
        when(issuerDao.findById(ISSUER_BIN)).thenReturn(Optional.of(issuer));
        when(mapper.toIssuerBinDto(issuer)).thenReturn(issuerBinDto);
        IssuerBinDto issuerBinDto1 = issuerService.getIssuerByBin(ISSUER_BIN);
        assertNotNull(issuerBinDto1);
        assertEquals(ISSUER_BIN, issuerBinDto1.getIssuerBin());
    }

    @Test
    void createIssuerTest() throws JsonProcessingException, AdminException {
        when(institutionDao.findById(INSTITUTION_ID)).thenReturn(Optional.of(institution));
        when(mapper.toIssuerBinEntity(issuerBinDto, institution)).thenReturn(issuer);
        when(issuerDao.save(issuer)).thenReturn(issuer);
        when(mapper.toIssuerBinDto(issuer)).thenReturn(issuerBinDto);
        IssuerBinDto issuerBinDto1 = issuerService.createIssuer(issuerBinDto);
        assertNotNull(issuerBinDto1);
        assertEquals(ISSUER_BIN, issuerBinDto1.getIssuerBin());
    }

    @Test
    void deleteIssuerTest() throws AdminException {
            doNothing().when(issuerDao).deleteById(ISSUER_BIN);
            doNothing().when(issuerDao).updateRedis(issuer);
            when(issuerDao.findById(ISSUER_BIN)).thenReturn(Optional.of(issuer));
            issuerService.performSoftDelete(ISSUER_BIN);
            verify(issuerDao, times(1)).deleteById(ISSUER_BIN);
    }

    @Test
    void updateIssuerTest() throws AdminException {
        when(issuerDao.findById(ISSUER_BIN)).thenReturn(Optional.of(issuer));
        when(mapper.toIssuerBinEntity(issuerBinDto, institution)).thenReturn(issuer);
        when(issuerDao.update(issuer)).thenReturn(issuer);
        when(mapper.toIssuerBinDto(issuer)).thenReturn(issuerBinDto);
        when(institutionDao.findById(INSTITUTION_ID)).thenReturn(Optional.of(institution));
        IssuerBinDto issuerBinDto1 = issuerService.updateIssuer(ISSUER_BIN, issuerBinDto);
        assertNotNull(issuerBinDto1);
        assertEquals(ISSUER_BIN, issuerBinDto1.getIssuerBin());
    }
}
