package money.open.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import money.open.admin.dao.impl.InstitutionDao;
import money.open.admin.dao.impl.IssuerDao;
import money.open.admin.dao.impl.PartnerDao;
import money.open.admin.dao.impl.ProgramMasterDao;
import money.open.admin.models.dto.ProgramMasterDto;
import money.open.admin.models.entities.Institution;
import money.open.admin.models.entities.Issuer;
import money.open.admin.models.entities.Partner;
import money.open.admin.models.entities.ProgramMaster;
import money.open.admin.exceptions.AdminException;
import money.open.admin.mappers.ProgramMasterModelMapper;
import money.open.admin.services.impl.ProgramMasterServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.List;
import java.util.Optional;

import static money.open.admin.helper.Helper.INSTITUTION_ID;
import static money.open.admin.helper.Helper.ISSUER_BIN;
import static money.open.admin.helper.Helper.PARTNER_ID;
import static money.open.admin.helper.Helper.PROGRAM_MASTER_ID;
import static money.open.admin.helper.Helper.institution;
import static money.open.admin.helper.Helper.issuer;
import static money.open.admin.helper.Helper.partner_json_string;
import static money.open.admin.helper.Helper.program_master_json_string;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ProgramMasterServiceTest {

    @InjectMocks
    private ProgramMasterServiceImpl programMasterService;

    @Mock
    private ProgramMasterModelMapper mapper;

    @Mock
    private ProgramMasterDao programMasterDao;

    @Mock
    private InstitutionDao institutionDao;

    @Mock
    private IssuerDao issuerDao;

    @Mock
    private PartnerDao partnerDao;

    private ProgramMasterDto programMasterDto;
    private ProgramMaster programMaster;
    private Partner partner;
    private Institution institution;
    private Issuer issuer;

    @BeforeEach
    void setup() throws JsonProcessingException {
        MockitoAnnotations.openMocks(this);
        ObjectMapper objectMapper = new ObjectMapper();
        partner = objectMapper.readValue(partner_json_string(), Partner.class);
        institution = institution();
        issuer = issuer();
        programMasterDto = objectMapper.readValue(program_master_json_string(), ProgramMasterDto.class);
        programMaster = ProgramMaster.builder()
                .programMasterId(programMasterDto.getProgramMasterId())
                .dbUrl(programMasterDto.getDbUrl())
                .programKey(programMasterDto.getProgramKey())
                .institutionId(institution())
                .issuerBin(issuer())
                .partnerEntityId(partner)
                .build();
    }

    @Test
    void findAllProgramMasterTest() {
        List<ProgramMaster> programMasters = List.of(programMaster);
        when(programMasterDao.findAll()).thenReturn(programMasters);
        when(mapper.toProgramMasterDtoList(programMasters)).thenReturn(List.of(programMasterDto));
        List<ProgramMasterDto> programMasterDtos = programMasterService.fetchAll();
        assertNotNull(programMasterDtos);
        assertEquals(INSTITUTION_ID, programMasterDtos.get(0).getInstitutionId());
    }

    @Test
    void findProgramMasterByIDTest() throws AdminException {
        when(programMasterDao.findById(PROGRAM_MASTER_ID)).thenReturn(Optional.ofNullable(programMaster));
        when(mapper.toProgramMasterDto(programMaster)).thenReturn(programMasterDto);
        ProgramMasterDto programMasterDto1 = programMasterService.fetchById(PROGRAM_MASTER_ID);
        assertNotNull(programMasterDto1);
        assertEquals(INSTITUTION_ID, programMasterDto1.getInstitutionId());
    }

    @Test
    void createProgramMasterTest() throws AdminException {
        when(institutionDao.findById(INSTITUTION_ID)).thenReturn(Optional.of(institution));
        when(partnerDao.findById(PARTNER_ID)).thenReturn(Optional.of(partner));
        when(issuerDao.findById(ISSUER_BIN)).thenReturn(Optional.of(issuer));

        when(mapper.toProgramMasterEntity(programMasterDto, institution, issuer, partner)).thenReturn(programMaster);
        when(mapper.toProgramMasterDto(programMaster)).thenReturn(programMasterDto);
        when(programMasterDao.save(programMaster)).thenReturn(programMaster);
        ProgramMasterDto programMasterDto1 = programMasterService.create(programMasterDto);
        assertNotNull(programMasterDto1);
        assertEquals(INSTITUTION_ID, programMasterDto1.getInstitutionId());
    }

    @Test
    void deleteProgramMasterTest() throws AdminException {
        doNothing().when(programMasterDao).deleteById(PROGRAM_MASTER_ID);
        doNothing().when(programMasterDao).updateRedis(programMaster);
        when(programMasterDao.findById(PROGRAM_MASTER_ID)).thenReturn(Optional.of(programMaster));
        programMasterService.performSoftDelete(PROGRAM_MASTER_ID);
        verify(programMasterDao, times(1)).deleteById(PROGRAM_MASTER_ID);
    }

    @Test
    void updateProgramMasterTest() throws AdminException {
        when(institutionDao.findById(INSTITUTION_ID)).thenReturn(Optional.of(institution));
        when(partnerDao.findById(PARTNER_ID)).thenReturn(Optional.of(partner));
        when(issuerDao.findById(ISSUER_BIN)).thenReturn(Optional.of(issuer));

        when(mapper.toProgramMasterEntity(programMasterDto, institution, issuer, partner)).thenReturn(programMaster);
        when(mapper.toProgramMasterDto(programMaster)).thenReturn(programMasterDto);
        when(programMasterDao.findById(PROGRAM_MASTER_ID)).thenReturn(Optional.ofNullable(programMaster));
        when(programMasterDao.update(programMaster)).thenReturn(programMaster);
        ProgramMasterDto programMasterDto1 = programMasterService.update(PROGRAM_MASTER_ID,programMasterDto);
        assertNotNull(programMasterDto1);
        assertEquals(INSTITUTION_ID, programMasterDto1.getInstitutionId());
    }


}
