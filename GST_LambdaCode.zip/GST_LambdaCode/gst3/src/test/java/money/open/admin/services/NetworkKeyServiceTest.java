package money.open.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import money.open.admin.dao.impl.NetworkKeyDao;
import money.open.admin.exceptions.AdminException;
import money.open.admin.mappers.NetworkKeyModelMapper;
import money.open.admin.models.dto.network.NetworkKeyDto;
import money.open.admin.models.entities.network.NetworkKey;
import money.open.admin.services.impl.NetworkKeyServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.List;
import java.util.Optional;

import static money.open.admin.helper.Helper.ISS_WORKING_KEY;
import static money.open.admin.helper.Helper.NETWORK_KEY_ID;
import static money.open.admin.helper.Helper.network_key_json_string;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class NetworkKeyServiceTest {

    @InjectMocks
    private NetworkKeyServiceImpl networkKeyService;

    @Mock
    private NetworkKeyDao networkKeyDao;
    @Mock
    private NetworkKeyModelMapper mapper;

    private NetworkKeyDto networkKeyDto;
    private NetworkKey networkKey;

    @BeforeEach
    void setup() throws JsonProcessingException {
        MockitoAnnotations.openMocks(this);
        ObjectMapper objectMapper = new ObjectMapper();
        networkKey = objectMapper.readValue(network_key_json_string(), NetworkKey.class);
        networkKeyDto = objectMapper.readValue(network_key_json_string(), NetworkKeyDto.class);
    }

    @Test
    void findAllNetworkKeyTest() {
        List<NetworkKey> networkKeys = List.of(networkKey);
        when(networkKeyDao.findAll()).thenReturn(networkKeys);
        when(mapper.toNetworkKeyDtoList(networkKeys)).thenReturn(List.of(networkKeyDto));
        List<NetworkKeyDto> networkKeyDtos = networkKeyService.fetchAll();
        assertNotNull(networkKeyDtos);
        assertEquals(ISS_WORKING_KEY, networkKeyDtos.get(0).getIssWorkingKey());
    }

    @Test
    void findNetworkByIdTest() throws AdminException {
        when(networkKeyDao.findById(NETWORK_KEY_ID)).thenReturn(Optional.of(networkKey));
        when(mapper.toNetworkKeyDto(networkKey)).thenReturn(networkKeyDto);
        NetworkKeyDto networkKeyDto1 = networkKeyService.fetchById(NETWORK_KEY_ID);
        assertNotNull(networkKeyDto1);
        assertEquals(ISS_WORKING_KEY, networkKeyDto1.getIssWorkingKey());
    }

    @Test
    void createNetworkKeyTest() throws AdminException {
        when(mapper.toNetworkKeyEntity(networkKeyDto)).thenReturn(networkKey);
        when(networkKeyDao.save(networkKey)).thenReturn(networkKey);
        when(mapper.toNetworkKeyDto(networkKey)).thenReturn(networkKeyDto);
        NetworkKeyDto networkKeyDto1 = networkKeyService.create(networkKeyDto);
        assertNotNull(networkKeyDto1);
        assertEquals(ISS_WORKING_KEY, networkKeyDto1.getIssWorkingKey());
    }

    @Test
    void deleteNetworkKeyTest() throws AdminException {
        doNothing().when(networkKeyDao).deleteById(NETWORK_KEY_ID);
        doNothing().when(networkKeyDao).updateRedis(networkKey);
        when(networkKeyDao.findById(NETWORK_KEY_ID)).thenReturn(Optional.of(networkKey));
        networkKeyService.performSoftDelete(NETWORK_KEY_ID);
        verify(networkKeyDao, times(1)).deleteById(NETWORK_KEY_ID);
    }

    @Test
    void updateNetworkKeyTest() throws AdminException {
        when(mapper.toNetworkKeyEntity(networkKeyDto)).thenReturn(networkKey);
        when(networkKeyDao.update(networkKey)).thenReturn(networkKey);
        when(mapper.toNetworkKeyDto(networkKey)).thenReturn(networkKeyDto);
        when(networkKeyDao.findById(NETWORK_KEY_ID)).thenReturn(Optional.of(networkKey));
        NetworkKeyDto networkKeyDto1 = networkKeyService.update(NETWORK_KEY_ID, networkKeyDto);
        assertNotNull(networkKeyDto1);
        assertEquals(ISS_WORKING_KEY, networkKeyDto1.getIssWorkingKey());
    }
}
