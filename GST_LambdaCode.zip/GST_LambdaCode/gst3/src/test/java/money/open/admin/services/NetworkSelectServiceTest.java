package money.open.admin.services;

public class NetworkSelectServiceTest {
    //TODO: Add tests
}
