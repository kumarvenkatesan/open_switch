package money.open.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import money.open.admin.dao.impl.CardDesignDao;
import money.open.admin.dao.impl.CardProductDao;
import money.open.admin.dao.impl.ProgramMasterDao;
import money.open.admin.dao.impl.VendorMasterDao;
import money.open.admin.models.dto.CardProductDto;
import money.open.admin.models.entities.CardDesign;
import money.open.admin.models.entities.CardProduct;
import money.open.admin.models.entities.Partner;
import money.open.admin.models.entities.ProgramMaster;
import money.open.admin.models.entities.VendorMaster;
import money.open.admin.exceptions.AdminException;
import money.open.admin.mappers.CardProductModelMapper;
import money.open.admin.services.impl.CardProductServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.List;
import java.util.Optional;

import static money.open.admin.helper.Helper.CARD_DESIGN_ID;
import static money.open.admin.helper.Helper.CARD_PRODUCT_ID;
import static money.open.admin.helper.Helper.PROGRAM_MASTER_ID;
import static money.open.admin.helper.Helper.VENDOR_MASTER_ID;
import static money.open.admin.helper.Helper.card_product_json_string;
import static money.open.admin.helper.Helper.institution;
import static money.open.admin.helper.Helper.issuer;
import static money.open.admin.helper.Helper.partner_json_string;
import static money.open.admin.helper.Helper.vendor_master_json_string;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class CardProductServiceTest {

    @InjectMocks
    private CardProductServiceImpl cardProductService;

    @Mock
    private CardProductDao cardProductDao;

    @Mock
    private VendorMasterDao vendorMasterDao;

    @Mock
    private ProgramMasterDao programMasterDao;

    @Mock
    private CardDesignDao cardDesignDao;

    @Mock
    private CardProductModelMapper mapper;

    private CardProduct cardProduct;
    private CardProductDto cardProductDto;
    private VendorMaster vendorMaster;
    private ProgramMaster programMaster;
    private CardDesign cardDesign;

    @BeforeEach
    void setup() throws JsonProcessingException {
        MockitoAnnotations.openMocks(this);
        ObjectMapper objectMapper = new ObjectMapper();
        Partner partner = objectMapper.readValue(partner_json_string(), Partner.class);
        cardProductDto = objectMapper.readValue(card_product_json_string(), CardProductDto.class);
        vendorMaster = objectMapper.readValue(vendor_master_json_string(), VendorMaster.class);

        programMaster = ProgramMaster.builder()
                .programMasterId(PROGRAM_MASTER_ID)
                .institutionId(institution())
                .issuerBin(issuer())
                .partnerEntityId(partner)
                .build();
        cardDesign = CardDesign.builder()
                .cardDesignId(CARD_DESIGN_ID)
                .issuerBin(issuer())
                .partnerEntityId(partner)
                .vendorId(vendorMaster)
                .build();
        cardProduct = CardProduct.builder()
                .cardDesignId(cardDesign)
                .cardProductId(cardProductDto.getCardProductId())
                .vendorId(vendorMaster)
                .programMasterId(programMaster)
                .cardProductCode(cardProductDto.getCardProductCode())
                .build();
    }

    @Test
    void findAllCardProductTest() {
        List<CardProduct> cardProducts = List.of(cardProduct);
        when(cardProductDao.findAll()).thenReturn(cardProducts);
        when(mapper.toCardProductDtoList(cardProducts)).thenReturn(List.of(cardProductDto));
        List<CardProductDto> cardProductDtos = cardProductService.fetchAll();
        assertNotNull(cardProductDtos);
        assertEquals(VENDOR_MASTER_ID, cardProductDtos.get(0).getVendorId());
    }

    @Test
    void findCardProductByIDTest() throws AdminException {
        when(cardProductDao.findById(CARD_PRODUCT_ID)).thenReturn(Optional.ofNullable(cardProduct));
        when(mapper.toCardProductDto(cardProduct)).thenReturn(cardProductDto);
        CardProductDto cardProductDto1 = cardProductService.fetchById(CARD_PRODUCT_ID);
        assertNotNull(cardProductDto1);
        assertEquals(VENDOR_MASTER_ID, cardProductDto1.getVendorId());
    }

    @Test
    void createCardProductTest() throws AdminException {
        when(vendorMasterDao.findById(VENDOR_MASTER_ID)).thenReturn(Optional.ofNullable(vendorMaster));
        when(programMasterDao.findById(PROGRAM_MASTER_ID)).thenReturn(Optional.ofNullable(programMaster));
        when(cardDesignDao.findById(CARD_DESIGN_ID)).thenReturn(Optional.ofNullable(cardDesign));

        when(cardProductDao.save(cardProduct)).thenReturn(cardProduct);
        when(mapper.toCardProductEntity(cardProductDto, programMaster, vendorMaster, cardDesign)).thenReturn(cardProduct);
        when(mapper.toCardProductDto(cardProduct)).thenReturn(cardProductDto);

        CardProductDto cardProductDto1 = cardProductService.create(cardProductDto);
        assertNotNull(cardProductDto1);
        assertEquals(VENDOR_MASTER_ID, cardProductDto1.getVendorId());
    }

    @Test
    void deleteCardProductTest() throws AdminException {
        doNothing().when(cardProductDao).deleteById(CARD_PRODUCT_ID);
        doNothing().when(cardProductDao).updateRedis(cardProduct);
        when(cardProductDao.findById(CARD_PRODUCT_ID)).thenReturn(Optional.of(cardProduct));
        cardProductService.performSoftDelete(CARD_PRODUCT_ID);
        verify(cardProductDao, times(1)).deleteById(CARD_PRODUCT_ID);
    }

    @Test
    void updateCardProductTest() throws AdminException {
        when(vendorMasterDao.findById(VENDOR_MASTER_ID)).thenReturn(Optional.ofNullable(vendorMaster));
        when(programMasterDao.findById(PROGRAM_MASTER_ID)).thenReturn(Optional.ofNullable(programMaster));
        when(cardDesignDao.findById(CARD_DESIGN_ID)).thenReturn(Optional.ofNullable(cardDesign));

        when(cardProductDao.findById(CARD_PRODUCT_ID)).thenReturn(Optional.ofNullable(cardProduct));
        when(cardProductDao.update(cardProduct)).thenReturn(cardProduct);
        when(mapper.toCardProductEntity(cardProductDto, programMaster, vendorMaster, cardDesign)).thenReturn(cardProduct);
        when(mapper.toCardProductDto(cardProduct)).thenReturn(cardProductDto);

        CardProductDto cardProductDto1 = cardProductService.update(CARD_PRODUCT_ID, cardProductDto);
        assertNotNull(cardProductDto1);
        assertEquals(VENDOR_MASTER_ID, cardProductDto1.getVendorId());
    }
}
