package money.open.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import money.open.admin.dao.impl.VendorMasterDao;
import money.open.admin.models.dto.VendorMasterDto;
import money.open.admin.models.entities.VendorMaster;
import money.open.admin.exceptions.AdminException;
import money.open.admin.mappers.VendorMasterModelMapper;
import money.open.admin.services.impl.VendorMasterServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.List;
import java.util.Optional;

import static money.open.admin.helper.Helper.VENDOR_MASTER_ID;
import static money.open.admin.helper.Helper.VENDOR_MASTER_SCHEME;
import static money.open.admin.helper.Helper.vendor_master_json_string;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class VendorMasterServiceTest {

    @InjectMocks
    private VendorMasterServiceImpl vendorMasterService;

    @Mock
    private VendorMasterDao vendorMasterDao;

    @Mock
    private VendorMasterModelMapper mapper;

    private VendorMasterDto vendorMasterDto;
    private VendorMaster vendorMaster;

    @BeforeEach
    void setup() throws JsonProcessingException {
        MockitoAnnotations.openMocks(this);
        ObjectMapper objectMapper = new ObjectMapper();
        vendorMasterDto = objectMapper.readValue(vendor_master_json_string(), VendorMasterDto.class);
        vendorMaster = objectMapper.readValue(vendor_master_json_string(), VendorMaster.class);
    }

    @Test
    void findAllVendorMasterTest() throws AdminException {
        List<VendorMaster> vendorMasters = List.of(vendorMaster);
        when(vendorMasterDao.findAll()).thenReturn(vendorMasters);
        when(mapper.toVendorMasterDtoList(vendorMasters)).thenReturn(List.of(vendorMasterDto));
        List<VendorMasterDto> vendorMasterDtos = vendorMasterService.fetchAll();
        assertNotNull(vendorMasters);
        assertEquals(VENDOR_MASTER_SCHEME, vendorMasterDtos.get(0).getScheme());
    }

    @Test
    void findVendorMasterByIdTest() throws AdminException {
        when(vendorMasterDao.findById(VENDOR_MASTER_ID)).thenReturn(Optional.of(vendorMaster));
        when(mapper.toVendorMasterDto(vendorMaster)).thenReturn(vendorMasterDto);
        VendorMasterDto vendorMasterDto1 = vendorMasterService.fetchById(VENDOR_MASTER_ID);
        assertNotNull(vendorMasterDto1);
        assertEquals(VENDOR_MASTER_SCHEME, vendorMasterDto1.getScheme());
    }

    @Test
    void createVendorMasterTest() throws AdminException {
        when(mapper.toVendorMasterEntity(vendorMasterDto)).thenReturn(vendorMaster);
        when(vendorMasterDao.save(vendorMaster)).thenReturn(vendorMaster);
        when(mapper.toVendorMasterDto(vendorMaster)).thenReturn(vendorMasterDto);
        VendorMasterDto vendorMasterDto1 = vendorMasterService.create(vendorMasterDto);
        assertNotNull(vendorMasterDto1);
        assertEquals(VENDOR_MASTER_SCHEME, vendorMasterDto1.getScheme());
    }

    @Test
    void deleteVendorMasterTest() throws AdminException {
        doNothing().when(vendorMasterDao).deleteById(VENDOR_MASTER_ID);
        doNothing().when(vendorMasterDao).updateRedis(vendorMaster);
        when(vendorMasterDao.findById(VENDOR_MASTER_ID)).thenReturn(Optional.of(vendorMaster));
        vendorMasterService.performSoftDelete(VENDOR_MASTER_ID);
        verify(vendorMasterDao, times(1)).deleteById(VENDOR_MASTER_ID);
    }

    @Test
    void updateVendorMasterTest() throws AdminException {
        when(vendorMasterDao.findById(VENDOR_MASTER_ID)).thenReturn(Optional.of(vendorMaster));
        when(mapper.toVendorMasterEntity(vendorMasterDto)).thenReturn(vendorMaster);
        when(vendorMasterDao.update(vendorMaster)).thenReturn(vendorMaster);
        when(mapper.toVendorMasterDto(vendorMaster)).thenReturn(vendorMasterDto);
        VendorMasterDto vendorMasterDto1 = vendorMasterService.update(VENDOR_MASTER_ID, vendorMasterDto);
        assertNotNull(vendorMasterDto1);
        assertEquals(VENDOR_MASTER_SCHEME, vendorMasterDto1.getScheme());
    }
}
