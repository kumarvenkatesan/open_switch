//package money.open.admin;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest(classes = SwitchAdminApplication.class)
//public class SwitchAdminApplicationTest {
//
//    @Test
//    void contextLoads() {}
//}
