package money.open.admin.config;

import org.springframework.boot.test.context.TestConfiguration;

@TestConfiguration
public class AdminServiceTestConfiguration {
}
