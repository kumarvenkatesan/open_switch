package money.open.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import money.open.admin.dao.impl.KeyMapperDao;
import money.open.admin.models.dto.KeyMapperDto;
import money.open.admin.models.entities.KeyMapper;
import money.open.admin.exceptions.AdminException;
import money.open.admin.mappers.KeyMapperModelMapper;
import money.open.admin.services.impl.KeyMapperServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static money.open.admin.helper.Helper.KEYMAPPER_INSTITUTIONID;
import static money.open.admin.helper.Helper.KEYMAPPER_INSTITUTIONKEY;
import static money.open.admin.helper.Helper.KEYMAPPER_PARTNERENTITYID;
import static money.open.admin.helper.Helper.KEYMAPPER_PARTNERKEY;
import static money.open.admin.helper.Helper.KEY_RULE_ID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class KeyMapperServiceTest {
    @InjectMocks
    private KeyMapperServiceImpl keyMapperService;
    @Mock
    private KeyMapperDao keyMapperDao;
    @Mock
    private KeyMapperModelMapper mapper;

    private KeyMapperDto keyMapperDto;
    private KeyMapper keyMapper;

    @BeforeEach
    void setup() throws JsonProcessingException {
        MockitoAnnotations.openMocks(this);
        Map<String, String> keys = new HashMap<>();
        keys.put(KEYMAPPER_PARTNERKEY, KEYMAPPER_PARTNERENTITYID);
        keys.put(KEYMAPPER_INSTITUTIONKEY, KEYMAPPER_INSTITUTIONID);
        keyMapper = KeyMapper.builder()
                .keys(keys)
                .keyRuleId(KEY_RULE_ID)
                .build();
        keyMapperDto = KeyMapperDto.builder()
                .keyRuleId(keyMapper.getKeyRuleId())
                .keys(keyMapper.getKeys())
                .build();
    }

    @Test
    void findAllKeyMappersTest() {
        List<KeyMapper> keyMappers = List.of(keyMapper);
        when(keyMapperDao.findAll()).thenReturn(keyMappers);
        when(mapper.toKeyMapperDtoList(keyMappers)).thenReturn(List.of(keyMapperDto));
        List<KeyMapperDto> keyMapperDtos = keyMapperService.fetchAll();
        String actualValue = keyMapperDtos.get(0).getKeys().get(KEYMAPPER_PARTNERKEY);
        assertNotNull(keyMapperDtos);
        assertEquals(KEYMAPPER_PARTNERENTITYID, actualValue);
    }

    @Test
    void findInstitutionByIdTest() throws AdminException {
        when(keyMapperDao.findById(KEY_RULE_ID)).thenReturn(Optional.of(keyMapper));
        when(mapper.toKeyMapperDto(keyMapper)).thenReturn(keyMapperDto);
        KeyMapperDto keyMapperDto1 = keyMapperService.fetchById(KEY_RULE_ID);
        String expectedValue = keyMapperDto1.getKeys().get(KEYMAPPER_INSTITUTIONKEY);
        assertNotNull(keyMapperDto1);
        assertEquals(KEYMAPPER_INSTITUTIONID, expectedValue);
    }

    @Test
    void createKeyMapperTest() throws AdminException {
        when(mapper.toKeyMapperEntity(keyMapperDto)).thenReturn(keyMapper);
        when(keyMapperDao.save(keyMapper)).thenReturn(keyMapper);
        when(mapper.toKeyMapperDto(keyMapper)).thenReturn(keyMapperDto);
        KeyMapperDto keyMapperDto1 = keyMapperService.create(keyMapperDto);
        String expectedValue = keyMapperDto1.getKeys().get(KEYMAPPER_INSTITUTIONKEY);;
        assertNotNull(keyMapperDto1);
        assertEquals(KEYMAPPER_INSTITUTIONID, expectedValue);
    }

    @Test
    void deleteInstitutionTest() throws AdminException {
        doNothing().when(keyMapperDao).deleteById(KEY_RULE_ID);
        doNothing().when(keyMapperDao).updateRedis(keyMapper);
        when(keyMapperDao.findById(KEY_RULE_ID)).thenReturn(Optional.of(keyMapper));
        keyMapperService.performSoftDelete(KEY_RULE_ID);
        verify(keyMapperDao, times(1)).deleteById(KEY_RULE_ID);
    }

    @Test
    void updateKeyMapperTest() throws AdminException {
        when(keyMapperDao.findById(KEY_RULE_ID)).thenReturn(Optional.of(keyMapper));
        when(mapper.toKeyMapperEntity(keyMapperDto)).thenReturn(keyMapper);
        when(keyMapperDao.update(keyMapper)).thenReturn(keyMapper);
        when(mapper.toKeyMapperDto(keyMapper)).thenReturn(keyMapperDto);
        KeyMapperDto keyMapperDto1 = keyMapperService.update(KEY_RULE_ID, keyMapperDto);
        String expectedValue = keyMapperDto1.getKeys().get(KEYMAPPER_INSTITUTIONKEY);;
        assertNotNull(keyMapperDto1);
        assertEquals(KEYMAPPER_INSTITUTIONID, expectedValue);
    }
}
