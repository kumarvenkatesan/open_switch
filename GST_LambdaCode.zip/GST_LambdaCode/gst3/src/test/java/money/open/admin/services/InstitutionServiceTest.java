package money.open.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import money.open.admin.dao.impl.InstitutionDao;
import money.open.admin.models.dto.InstitutionDto;
import money.open.admin.models.entities.Institution;
import money.open.admin.exceptions.AdminException;
import money.open.admin.mappers.InstitutionModelMapper;
import money.open.admin.services.impl.InstitutionServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.List;
import java.util.Optional;

import static money.open.admin.helper.Helper.INSTITUTION_ID;
import static money.open.admin.helper.Helper.INSTITUTION_NAME;
import static money.open.admin.helper.Helper.institution_json_string;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class InstitutionServiceTest {

    @Mock
    private InstitutionDao institutionDao;
    @InjectMocks
    private InstitutionServiceImpl institutionService;
    @Mock
    private InstitutionModelMapper mapper;

    private InstitutionDto institutionDto;
    private Institution institution;

    @BeforeEach
    void setup() throws JsonProcessingException {
        MockitoAnnotations.openMocks(this);
        ObjectMapper objectMapper = new ObjectMapper();
        institutionDto = objectMapper.readValue(institution_json_string(), InstitutionDto.class);
        institution = objectMapper.readValue(institution_json_string(), Institution.class);
    }

    @Test
    void findAllInstitutionsTest() {
        List<Institution> institutions = List.of(institution);
        when(institutionDao.findAll()).thenReturn(institutions);
        when(mapper.toInstitutionDtoList(List.of(institution))).thenReturn(List.of(institutionDto));
        List<InstitutionDto> institutionDto1 = institutionService.fetchAll();
        assertNotNull(institutionDto1);
        assertEquals(INSTITUTION_NAME, institutionDto1.get(0).getInstitutionName());
    }

    @Test
    void findInstitutionByIdTest() {
        when(institutionDao.findById("YES")).thenReturn(Optional.of(institution));
        when(mapper.toInstitutionDto(institution)).thenReturn(institutionDto);
        InstitutionDto institutionDto1 = institutionService.fetchById(INSTITUTION_ID);
        assertNotNull(institutionDto1);
        assertEquals(INSTITUTION_NAME, institutionDto1.getInstitutionName());
    }

    @Test
    void createInstitutionTest() {
        when(mapper.toInstitutionEntity(institutionDto)).thenReturn(institution);
        when(institutionDao.save(institution)).thenReturn(institution);
        when(mapper.toInstitutionDto(institution)).thenReturn(institutionDto);
        InstitutionDto institutionDto1 = institutionService.create(institutionDto);
        assertNotNull(institutionDto1);
        assertEquals(INSTITUTION_NAME, institutionDto1.getInstitutionName());
    }

    @Test
    void deleteInstitutionTest() throws AdminException {
        doNothing().when(institutionDao).deleteById(INSTITUTION_ID);
        doNothing().when(institutionDao).updateRedis(institution);
        when(institutionDao.findById(INSTITUTION_ID)).thenReturn(Optional.of(institution));
        institutionService.performSoftDelete(INSTITUTION_ID);
        verify(institutionDao, times(1)).deleteById(INSTITUTION_ID);
    }

    @Test
    void updateInstitutionTest() throws AdminException {
        when(institutionDao.findById(INSTITUTION_ID)).thenReturn(Optional.of(institution));
        when(mapper.toInstitutionEntity(institutionDto)).thenReturn(institution);
        when(institutionDao.update(institution)).thenReturn(institution);
        when(mapper.toInstitutionDto(institution)).thenReturn(institutionDto);
        InstitutionDto institutionDto1 = institutionService.update(INSTITUTION_ID, institutionDto);
        assertNotNull(institutionDto1);
        assertEquals(INSTITUTION_NAME, institutionDto1.getInstitutionName());
    }

}
