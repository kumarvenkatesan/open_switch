package money.open.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import money.open.admin.dao.impl.PartnerDao;
import money.open.admin.models.dto.PartnerDto;
import money.open.admin.models.entities.Partner;
import money.open.admin.exceptions.AdminException;
import money.open.admin.mappers.PartnerModelMapper;
import money.open.admin.services.impl.PartnerServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.List;
import java.util.Optional;

import static money.open.admin.helper.Helper.PARTNER_ID;
import static money.open.admin.helper.Helper.partner_json_string;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class PartnerServiceTest {

    @InjectMocks
    private PartnerServiceImpl partnerService;

    @Mock
    private PartnerDao partnerDao;

    @Mock
    private PartnerModelMapper mapper;

    private PartnerDto partnerDto;
    private Partner partner;

    @BeforeEach
    void setup() throws JsonProcessingException {
        MockitoAnnotations.openMocks(this);
        ObjectMapper objectMapper = new ObjectMapper();
        partnerDto = objectMapper.readValue(partner_json_string(), PartnerDto.class);
        partner = objectMapper.readValue(partner_json_string(), Partner.class);
    }

    @Test
    void findAllPartnersTest() {
        List<Partner> partners = List.of(partner);
        when(partnerDao.findAll()).thenReturn(partners);
        when(mapper.toPartnersDtoList(partners)).thenReturn(List.of(partnerDto));
        List<PartnerDto> partnerDtos = partnerService.getPartners();
        assertNotNull(partnerDtos);
        assertEquals(PARTNER_ID, partnerDtos.get(0).getPartnerEntityId());
    }

    @Test
    void findPartnerByIdTest() throws AdminException {
        when(partnerDao.findById(PARTNER_ID)).thenReturn(Optional.of(partner));
        when(mapper.toPartnerDto(partner)).thenReturn(partnerDto);
        PartnerDto partnerDto1 = partnerService.getPartnerById(PARTNER_ID);
        assertNotNull(partnerDto1);
        assertEquals(PARTNER_ID, partnerDto1.getPartnerEntityId());
    }

    @Test
    void createInstitutionTest() {
        when(mapper.toPartnerEntity(partnerDto)).thenReturn(partner);
        when(partnerDao.save(partner)).thenReturn(partner);
        when(mapper.toPartnerDto(partner)).thenReturn(partnerDto);
        PartnerDto partnerDto1 = partnerService.createPartner(partnerDto);
        assertNotNull(partnerDto1);
        assertEquals(PARTNER_ID, partnerDto1.getPartnerEntityId());
    }

    @Test
    void deletePartnerTest() throws AdminException {
        doNothing().when(partnerDao).deleteById(PARTNER_ID);
        doNothing().when(partnerDao).updateRedis(partner);
        when(partnerDao.findById(PARTNER_ID)).thenReturn(Optional.of(partner));
        partnerService.performSoftDelete(PARTNER_ID);
        verify(partnerDao, times(1)).deleteById(PARTNER_ID);
    }

    @Test
    void updatePartnerTest() throws AdminException {
        when(partnerDao.findById(PARTNER_ID)).thenReturn(Optional.of(partner));
        when(mapper.toPartnerEntity(partnerDto)).thenReturn(partner);
        when(partnerDao.update(partner)).thenReturn(partner);
        when(mapper.toPartnerDto(partner)).thenReturn(partnerDto);
        PartnerDto partnerDto1 = partnerService.updatePartner(PARTNER_ID, partnerDto);
        assertNotNull(partnerDto1);
        assertEquals(PARTNER_ID, partnerDto1.getPartnerEntityId());
    }
}
