package money.open.admin.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import money.open.admin.dao.impl.IssuerKeyDao;
import money.open.admin.models.dto.issuer.IssuerKeyDto;
import money.open.admin.models.entities.IssuerKey;
import money.open.admin.exceptions.AdminException;
import money.open.admin.mappers.IssuerModelMapper;
import money.open.admin.services.impl.IssuerKeyServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.List;
import java.util.Optional;

import static money.open.admin.helper.Helper.ISSUER_KEY;
import static money.open.admin.helper.Helper.issuer_key_json_string;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class IssuerKeyServiceTest {

    @InjectMocks
    private IssuerKeyServiceImpl issuerKeyService;

    @Mock
    private IssuerKeyDao issuerKeyDao;
    @Mock
    private IssuerModelMapper mapper;

    private IssuerKeyDto issuerKeyDto;
    private IssuerKey issuerKey;

    @BeforeEach
    void setup() throws JsonProcessingException {
        MockitoAnnotations.openMocks(this);
        ObjectMapper objectMapper = new ObjectMapper();
        issuerKeyDto = objectMapper.readValue(issuer_key_json_string(), IssuerKeyDto.class);
        issuerKey = objectMapper.readValue(issuer_key_json_string(), IssuerKey.class);
    }

    @Test
    void findAllIssuerKeyTest() {
        List<IssuerKey> issuerKeys = List.of(issuerKey);
        when(issuerKeyDao.findAll()).thenReturn(issuerKeys);
        when(mapper.toIssuerKeyDtoList(issuerKeys)).thenReturn(List.of(issuerKeyDto));
        List<IssuerKeyDto> issuerKeyDtos = issuerKeyService.fetchAll();
        assertNotNull(issuerKeyDtos);
        assertTrue(issuerKeyDtos.size() > 0);
    }

    @Test
    void findIssuerKeyByIDTest() throws AdminException {
        when(issuerKeyDao.findById(ISSUER_KEY)).thenReturn(Optional.of(issuerKey));
        when(mapper.toIssuerKeyDto(issuerKey)).thenReturn(issuerKeyDto);
        IssuerKeyDto issuerKeyDto1 = issuerKeyService.fetchById(ISSUER_KEY);
        assertNotNull(issuerKeyDto1);
        assertEquals(ISSUER_KEY, issuerKeyDto1.getIssuerKeyId());
    }

    @Test
    void createIssuerKeyTest() throws JsonProcessingException, AdminException {
        when(mapper.toIssuerKeyEntity(issuerKeyDto)).thenReturn(issuerKey);
        when(issuerKeyDao.save(issuerKey)).thenReturn(issuerKey);
        when(mapper.toIssuerKeyDto(issuerKey)).thenReturn(issuerKeyDto);
        IssuerKeyDto issuerKeyDto1 = issuerKeyService.create(issuerKeyDto);
        assertNotNull(issuerKeyDto1);
        assertEquals(ISSUER_KEY, issuerKeyDto1.getIssuerKeyId());
    }

    @Test
    void deleteIssuerKeyTest() throws AdminException {
        doNothing().when(issuerKeyDao).deleteById(ISSUER_KEY);
        doNothing().when(issuerKeyDao).updateRedis(issuerKey);
        when(issuerKeyDao.findById(ISSUER_KEY)).thenReturn(Optional.of(issuerKey));
        issuerKeyService.performSoftDelete(ISSUER_KEY);
        verify(issuerKeyDao, times(1)).deleteById(ISSUER_KEY);
    }

    @Test
    void updateIssuerKeyTest() throws AdminException {
        when(issuerKeyDao.findById(ISSUER_KEY)).thenReturn(Optional.of(issuerKey));
        when(mapper.toIssuerKeyEntity(issuerKeyDto)).thenReturn(issuerKey);
        when(issuerKeyDao.update(issuerKey)).thenReturn(issuerKey);
        when(mapper.toIssuerKeyDto(issuerKey)).thenReturn(issuerKeyDto);
        IssuerKeyDto issuerKeyDto1 = issuerKeyService.update(ISSUER_KEY, issuerKeyDto);
        assertNotNull(issuerKeyDto1);
        assertEquals(ISSUER_KEY, issuerKeyDto1.getIssuerKeyId());
    }
}
