ALTER TABLE issuer_key ALTER COLUMN pin_key TYPE varchar(74) USING pin_key::varchar;
ALTER TABLE issuer_key ALTER COLUMN cvv_key TYPE varchar(74) USING cvv_key::varchar;
ALTER TABLE issuer_key ALTER COLUMN chip_ac_key TYPE varchar(74) USING chip_ac_key::varchar;

ALTER TABLE network_key ALTER COLUMN zonal_master_key TYPE varchar(74) USING zonal_master_key::varchar;
ALTER TABLE network_key ALTER COLUMN acq_working_key TYPE varchar(74) USING acq_working_key::varchar;
ALTER TABLE network_key ALTER COLUMN iss_working_key TYPE varchar(74) USING iss_working_key::varchar;