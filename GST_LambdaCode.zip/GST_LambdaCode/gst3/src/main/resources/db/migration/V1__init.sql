-- card_design_id_seq definition

-- DROP SEQUENCE card_design_id_seq;

CREATE SEQUENCE card_design_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;


-- card_issuance.card_master_issuance_seq definition

-- DROP SEQUENCE card_issuance.card_master_issuance_seq;

CREATE SEQUENCE card_master_issuance_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;


-- card_issuance.card_master_seq definition

-- DROP SEQUENCE card_issuance.card_master_seq;

CREATE SEQUENCE card_master_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;


-- limit_master_seq definition

-- DROP SEQUENCE limit_master_seq;

CREATE SEQUENCE limit_master_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;


-- seq_customer_master definition

-- DROP SEQUENCE seq_customer_master;

CREATE SEQUENCE customer_master_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;


-- seq_program_master definition

-- DROP SEQUENCE seq_program_master;

CREATE SEQUENCE seq_program_master
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;


-- transaction_group_seq definition

-- DROP SEQUENCE transaction_group_seq;

CREATE SEQUENCE transaction_group_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;



-- institution definition

-- Drop table

-- DROP TABLE institution;

CREATE TABLE institution (
	institution_id varchar(12) NOT NULL,
	institution_code varchar(12) NOT NULL,
	institution_name varchar(45) NOT NULL,
	institution_type varchar(3) NOT NULL,
	base_currency_code varchar(3) NOT NULL,
	alpha_currency_code varchar(3) NOT NULL,
	alpha_2_country_code varchar(2) NOT NULL,
	alpha_3_country_code varchar(3) NOT NULL,
	country_code varchar(3) NOT NULL,
	primary_bin varchar(12) NOT NULL,
	external_id varchar(12) NOT NULL,
	external_id_desc varchar(45) NOT NULL,
	pci_vault_id varchar(12) NOT NULL,
	max_pin_count int4 NOT NULL,
	primary_hsm_id varchar(11) NOT NULL,
	fallback_hsm_id varchar(11) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	status int4 NULL,
	remarks varchar(50) NULL,
	CONSTRAINT institution_pkey PRIMARY KEY (institution_id)
);

-- issuer_bin definition

-- Drop table

-- DROP TABLE issuer_bin;

CREATE TABLE issuer_bin (
	issuer_bin varchar(12) NOT NULL,
	institution_id varchar(12) NOT NULL,
	bin_desc varchar(45) NULL DEFAULT NULL::character varying,
	bin_type varchar(12) NOT NULL,
	status varchar(1) NOT NULL,
	card_scheme varchar(12) NOT NULL,
	issuer_key_id varchar(20) NOT NULL,
	cms_flag varchar(1) NOT NULL,
	auth_flag varchar(1) NOT NULL,
	tfa_flag varchar(1) NOT NULL,
	card_len int4 NOT NULL,
	pin_len int4 NOT NULL,
	cvv1_service_code varchar(3) NOT NULL,
	cvv1_fdate varchar(4) NOT NULL,
	cvv2_service_code varchar(3) NOT NULL,
	cvv2_fdate varchar(4) NOT NULL,
	icvv_service_code varchar(3) NOT NULL,
	icvv_fdate varchar(4) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	remarks varchar(50) NULL,
	CONSTRAINT auth_flag_chk CHECK (((auth_flag)::bpchar = ANY (ARRAY['Y'::bpchar, 'P'::bpchar]))),
	CONSTRAINT bin_type_chk CHECK (((bin_type)::text = ANY (ARRAY[('PREPAID'::character varying)::text, ('CREDIT'::character varying)::text, ('DEBIT'::character varying)::text]))),
	CONSTRAINT card_len_chk CHECK ((card_len = ANY (ARRAY[16, 19]))),
	CONSTRAINT card_scheme_chk CHECK (((card_scheme)::text = ANY (ARRAY[('VISA'::character varying)::text, ('MASTERCARD'::character varying)::text, ('RUPAY'::character varying)::text, ('CUP'::character varying)::text]))),
	CONSTRAINT cms_flag_chk CHECK (((cms_flag)::bpchar = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
	CONSTRAINT cvv1_fdate_chk CHECK (((cvv1_fdate)::bpchar = ANY (ARRAY['YYMM'::bpchar, 'MMYY'::bpchar]))),
	CONSTRAINT cvv2_fdate_chk CHECK (((cvv2_fdate)::text = ANY (ARRAY[('YYMM'::character varying)::text, ('MMYY'::character varying)::text]))),
	CONSTRAINT icvv_fdate_chk CHECK (((icvv_fdate)::text = ANY (ARRAY[('YYMM'::character varying)::text, ('MMYY'::character varying)::text]))),
	CONSTRAINT issuer_bin_pkey PRIMARY KEY (issuer_bin),
	CONSTRAINT pin_len_chk CHECK (((pin_len >= 4) AND (pin_len <= 12))),
	CONSTRAINT status_chk CHECK (((status)::bpchar = ANY (ARRAY['0'::bpchar, '1'::bpchar, '2'::bpchar]))),
	CONSTRAINT tfa_flag_chk CHECK (((tfa_flag)::bpchar = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))
);

-- "admin".issuer_bin foreign keys

ALTER TABLE issuer_bin ADD CONSTRAINT fk_issuer_bin FOREIGN KEY (institution_id) REFERENCES institution(institution_id);

-- partner definition

-- Drop table

-- DROP TABLE partner;

CREATE TABLE partner_entity (
	partner_entity_id varchar(16) NOT NULL,
	description varchar(45) NOT NULL,
	product_code_len int4 NOT NULL,
	customer_id_gen varchar(1) NOT NULL,
	customer_id_format varchar(128) NOT NULL,
	customer_id_len int4 NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	remarks varchar(50) NULL,
	status int4 NULL,
	CONSTRAINT customer_id_gen_chk CHECK (((customer_id_gen)::bpchar = ANY (ARRAY['P'::bpchar, 'S'::bpchar]))),
	CONSTRAINT partner_entity_pkey PRIMARY KEY (partner_entity_id)
);

-- program_master definition

-- Drop table

-- DROP TABLE program_master;

CREATE TABLE program_master (
	program_master_id int8 NOT NULL DEFAULT nextval('admin.seq_program_master'::regclass),
	partner_entity_id varchar(16) NOT NULL,
	institution_id varchar(12) NOT NULL,
	issuer_bin varchar(12) NOT NULL,
	description varchar(128) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	status int4 NULL,
	remarks varchar(50) NULL,
	db_url varchar(128) NOT NULL,
	program_key varchar(32) NOT NULL,
	user_name varchar(32) NOT NULL,
	"password" varchar(64) NOT NULL,
	CONSTRAINT partner_map_issuer_bin_key UNIQUE (issuer_bin),
	CONSTRAINT partner_map_pkey PRIMARY KEY (program_master_id)
);


-- program_master foreign keys

ALTER TABLE program_master ADD CONSTRAINT fk_institution_id FOREIGN KEY (institution_id) REFERENCES institution(institution_id);
ALTER TABLE program_master ADD CONSTRAINT fk_issuer_bin FOREIGN KEY (issuer_bin) REFERENCES issuer_bin(issuer_bin);
ALTER TABLE program_master ADD CONSTRAINT fk_partner_entity_id FOREIGN KEY (partner_entity_id) REFERENCES partner_entity(partner_entity_id);

-- vendor_master definition

-- Drop table

-- DROP TABLE vendor_master;

CREATE TABLE vendor_master (
	vendor_id varchar(32) NOT NULL,
	vendor_name varchar(32) NOT NULL,
	scheme varchar(10) NOT NULL,
	end_point_type varchar(10) NOT NULL,
	end_point varchar(100) NOT NULL,
	file_type varchar(10) NOT NULL,
	file_name_format varchar(100) NOT NULL,
	min_count int8 NOT NULL,
	max_count int8 NOT NULL,
	upload_frequency varchar(20) NULL,
	contact_mobile1 varchar(13) NULL,
	contact_mobile2 varchar(13) NULL,
	contact_mobile3 varchar(13) NULL,
	contact_email1 varchar(50) NULL,
	contact_email2 varchar(50) NULL,
	contact_email3 varchar(50) NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	status int4 NULL,
	remarks varchar(50) NULL,
	CONSTRAINT vendor_master_pk PRIMARY KEY (vendor_id)
);

-- limit_master definition

-- Drop table

-- DROP TABLE limit_master;

CREATE TABLE limit_master (
	limit_config_id varchar(15) NOT NULL,
	partner_entity_id varchar(12) NOT NULL,
	entity_id varchar(32) NOT NULL,
	entity_type varchar(16) NOT NULL,
	country_mode varchar(1) NOT NULL,
	tp_code varchar(6) NOT NULL,
	daily_limit numeric(26, 4) NOT NULL,
	daily_count int8 NOT NULL,
	monthly_limit numeric(26, 4) NOT NULL,
	monthly_count int8 NOT NULL,
	channel varchar(32) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	pkey int8 NOT NULL DEFAULT nextval('limit_master_seq'::regclass),
	CONSTRAINT limit_master_pk PRIMARY KEY (pkey)
);

-- card_design definition

-- Drop table

-- DROP TABLE card_design;

CREATE TABLE card_design (
	vendor_id varchar(32) NOT NULL,
	scheme varchar(12) NOT NULL,
	file_id varchar(100) NOT NULL,
	description varchar(100) NULL,
	issuer_bin varchar(12) NOT NULL,
	partner_entity_id varchar(16) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	card_design_id varchar(32) NOT NULL,
	status int4 NULL,
	remarks varchar(50) NULL,
	CONSTRAINT card_design_pk PRIMARY KEY (card_design_id)
);


-- card_design foreign keys

ALTER TABLE card_design ADD CONSTRAINT card_design_fk FOREIGN KEY (vendor_id) REFERENCES vendor_master(vendor_id);
ALTER TABLE card_design ADD CONSTRAINT card_design_fk_1 FOREIGN KEY (issuer_bin) REFERENCES issuer_bin(issuer_bin);
ALTER TABLE card_design ADD CONSTRAINT card_design_fk_2 FOREIGN KEY (partner_entity_id) REFERENCES partner_entity(partner_entity_id);


-- card_product definition

-- Drop table

-- DROP TABLE card_product;

CREATE TABLE card_product (
	card_product_id varchar(16) NOT NULL,
	program_master_id int8 NOT NULL,
	product_name varchar(45) NOT NULL,
	card_type varchar(1) NOT NULL,
	card_variant varchar(4) NOT NULL,
	card_type_id varchar(2) NOT NULL,
	card_gen_type varchar(1) NOT NULL,
	card_gen_format varchar(128) NOT NULL,
	expiry_period int8 NOT NULL,
	card_maintenance_req varchar(1) NOT NULL,
	pin_gen_req varchar(1) NOT NULL,
	pin_print_method varchar(1) NOT NULL,
	country_mode varchar(1) NOT NULL,
	kyc_mode varchar(1) NOT NULL,
	default_channel varchar(3) NOT NULL,
	transaction_group_id varchar(15) NOT NULL,
	currency_mode varchar(1) NOT NULL,
	limit_flag varchar(1) NOT NULL,
	perso_vendor_id varchar(12) NOT NULL,
	perso_file_id varchar(45) NOT NULL,
	proxy_card_len int4 NOT NULL,
	proxy_card_format varchar(128) NOT NULL,
	card_order_len int4 NOT NULL,
	card_order_format varchar(128) NOT NULL,
	pin_forgot varchar(1) NOT NULL,
	reissue_card varchar(1) NOT NULL,
	reissue_period varchar(1) NOT NULL,
	default_card_seq varchar(2) NOT NULL,
	default_emboss_name varchar(35) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	card_product_code varchar(4) NOT NULL,
	issuer_key_id varchar(20) NOT NULL DEFAULT 'NA'::character varying,
	di_enabled varchar(1) NULL,
	vendor_id varchar(32) NULL,
	delivery_address varchar(32) NULL,
	card_design_id varchar(32) NULL,
	status int4 NULL,
	remarks varchar(50) NULL,
	CONSTRAINT card_flag_chk CHECK (((card_type)::bpchar = ANY (ARRAY['P'::bpchar, 'V'::bpchar]))),
	CONSTRAINT card_gen_type_chk CHECK (((card_gen_type)::bpchar = ANY (ARRAY['I'::bpchar, 'P'::bpchar]))),
	CONSTRAINT card_maintenance_req_chk CHECK (((card_maintenance_req)::bpchar = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
	CONSTRAINT card_product_pkey PRIMARY KEY (card_product_id),
	CONSTRAINT card_type_chk CHECK (((card_variant)::text = ANY (ARRAY[('MG'::character varying)::text, ('OC'::character varying)::text, ('DI'::character varying)::text]))),
	CONSTRAINT country_mode_chk CHECK (((country_mode)::bpchar = ANY (ARRAY['D'::bpchar, 'I'::bpchar]))),
	CONSTRAINT currency_mode_chk CHECK (((currency_mode)::bpchar = ANY (ARRAY['S'::bpchar, 'H'::bpchar]))),
	CONSTRAINT default_channel_chk CHECK (((default_channel)::text = ANY (ARRAY[('YYY'::character varying)::text, ('YYN'::character varying)::text, ('YNN'::character varying)::text, ('NYY'::character varying)::text, ('NYN'::character varying)::text, ('NNY'::character varying)::text]))),
	CONSTRAINT di_enabled_chk CHECK (((di_enabled)::bpchar = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
	CONSTRAINT kyc_mode_chk CHECK (((kyc_mode)::bpchar = ANY (ARRAY['F'::bpchar, 'P'::bpchar, 'N'::bpchar]))),
	CONSTRAINT limit_flag_chk CHECK (((limit_flag)::bpchar = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
	CONSTRAINT pin_forgot_chk CHECK (((pin_forgot)::bpchar = ANY (ARRAY['O'::bpchar, 'N'::bpchar]))),
	CONSTRAINT pin_print_method_chk CHECK (((pin_print_method)::bpchar = ANY (ARRAY['I'::bpchar, 'O'::bpchar]))),
	CONSTRAINT reissue_card_chk CHECK (((reissue_card)::bpchar = ANY (ARRAY['O'::bpchar, 'N'::bpchar]))),
	CONSTRAINT reissue_period_chk CHECK (((reissue_period)::bpchar = ANY (ARRAY['O'::bpchar, 'N'::bpchar])))
);


-- "admin".card_product foreign keys

ALTER TABLE card_product ADD CONSTRAINT card_product_card_design_fk FOREIGN KEY (card_design_id) REFERENCES card_design(card_design_id);
ALTER TABLE card_product ADD CONSTRAINT card_product_fk FOREIGN KEY (vendor_id) REFERENCES vendor_master(vendor_id);
ALTER TABLE card_product ADD CONSTRAINT card_product_fkey FOREIGN KEY (program_master_id) REFERENCES program_master(program_master_id);

-- key_mapper definition

-- Drop table

-- DROP TABLE key_mapper;

CREATE TABLE key_mapper (
	key_rule_id varchar(255) NOT NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	keys text NULL,
	CONSTRAINT key_mapper_pkey PRIMARY KEY (key_rule_id)
);

-- hsm_master definition
-- Drop table
-- DROP TABLE hsm_master;

CREATE TABLE hsm_master (
	hsm_id varchar(11) NOT NULL,
	hsm_model varchar(45) NOT NULL,
	hsm_type varchar(1) NOT NULL,
	hsm_ip varchar(15) NOT NULL,
	hsm_port int4 NOT NULL,
	hsm_tcp_header_type varchar(1) NOT NULL,
	hsm_tcp_header_len int4 NOT NULL,
	hsm_msg_header_len int4 NOT NULL,
	timeout int4 NOT NULL,
	reconnect_interval int4 NOT NULL,
	hsm_status varchar(1) NOT NULL,
	description varchar(45) NULL DEFAULT NULL::character varying,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT hsm_master_pkey PRIMARY KEY (hsm_id),
	CONSTRAINT hsm_tcp_header_type_chk CHECK (((hsm_tcp_header_type)::bpchar = ANY (ARRAY['A'::bpchar, 'H'::bpchar]))),
	CONSTRAINT hsm_type_chk CHECK (((hsm_type)::bpchar = ANY (ARRAY['S'::bpchar, 'T'::bpchar, 'F'::bpchar])))
);

-- open_cards.issuer_key definition
-- Drop table
-- DROP TABLE issuer_key;

CREATE TABLE issuer_key (
	issuer_key_id varchar(20) NOT NULL,
	pin_ver_method varchar(1) NOT NULL,
	key_store varchar(1) NOT NULL,
	key_len int4 NOT NULL,
	pin_key varchar(64) NOT NULL,
	pin_key_kcv varchar(12) NOT NULL,
	cvv_key varchar(64) NOT NULL,
	cvv_key_kcv varchar(12) NOT NULL,
	chip_ac_key varchar(64) NOT NULL,
	chip_ac_key_kcv varchar(12) NOT NULL,
	dec_table varchar(16) NOT NULL,
	pin_pad_char varchar(1) NOT NULL,
	pan_pad_char varchar(1) NOT NULL,
	pin_len int4 NOT NULL,
	pan_len int4 NOT NULL,
	pan_val_len int4 NOT NULL,
	pan_val_offset int4 NOT NULL,
	pinblock_format varchar(2) NOT NULL,
	pvki varchar(1) NOT NULL,
	cdol1 varchar(250) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT issuer_key_pkey PRIMARY KEY (issuer_key_id),
	CONSTRAINT key_len_chk CHECK ((key_len = ANY (ARRAY[2, 32, 48, 64]))),
	CONSTRAINT key_store_chk CHECK (((key_store)::bpchar = ANY (ARRAY['K'::bpchar, 'I'::bpchar]))),
	CONSTRAINT pin_len_chk CHECK (((pin_len >= 4) AND (pin_len <= 12))),
	CONSTRAINT pin_ver_method_chk CHECK (((pin_ver_method)::bpchar = ANY (ARRAY['V'::bpchar, 'I'::bpchar])))
);

-- network_key definition
-- Drop table
-- DROP TABLE network_key;
CREATE TABLE network_key (
	network_key_id varchar(20) NOT NULL,
	key_store varchar(1) NOT NULL,
	key_len int4 NOT NULL,
	zonal_master_key varchar(64) NOT NULL,
	zonal_master_key_kcv varchar(12) NOT NULL,
	acq_working_key varchar(64) NOT NULL,
	acq_working_key_kcv varchar(12) NOT NULL,
	iss_working_key varchar(128) NOT NULL,
	iss_working_key_kcv varchar(12) NOT NULL,
	description varchar(45) NULL DEFAULT NULL::character varying,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT key_len_chk CHECK ((key_len = ANY (ARRAY[2, 32, 48, 64]))),
	CONSTRAINT key_store_chk CHECK (((key_store)::bpchar = ANY (ARRAY['K'::bpchar, 'I'::bpchar]))),
	CONSTRAINT network_key_pkey PRIMARY KEY (network_key_id)
);

