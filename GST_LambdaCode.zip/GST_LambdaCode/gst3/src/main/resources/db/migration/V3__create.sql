-- issuer_select definition

-- Drop table

-- DROP TABLE issuer_select;

CREATE TABLE issuer_select (
  issuer_select_id varchar(255) NOT NULL,
  channel_type varchar(255) NULL,
  description varchar(255) NULL,
  from_offset varchar(255) NULL,
  imf_data varchar(255) NULL,
  imf_value varchar(255) NULL,
  issuer_bin varchar(255) NULL,
  to_offset varchar(255) NULL,
  created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
  created_at timestamp NOT NULL DEFAULT now(),
modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
modified_at timestamp NOT NULL DEFAULT now(),
CONSTRAINT issuer_select_pkey PRIMARY KEY (issuer_select_id)
);

-- network_master definition

-- Drop table

-- DROP TABLE network_master;

CREATE TABLE network_master (
  network_id varchar(12) NOT NULL,
  business_date date NOT NULL,
  cut_over_flag varchar(1) NOT NULL,
  echo_flag varchar(1) NOT NULL,
  echo_interval int4 NOT NULL,
  end_point varchar(128) NOT NULL,
  end_point_type varchar(45) NOT NULL,
  key_exchg_flag varchar(1) NOT NULL,
  network_key_id varchar(12) NOT NULL,
  network_name varchar(45) NOT NULL,
  network_type varchar(1) NOT NULL,
  signon_flag varchar(1) NOT NULL,
  timeout_action varchar(1) NOT NULL,
  timeout_period int4 NOT NULL,
  created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
  created_at timestamp NOT NULL DEFAULT now(),
modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
modified_at timestamp NOT NULL DEFAULT now(),
CONSTRAINT network_master_pkey PRIMARY KEY (network_id)
);

-- network_select definition

-- Drop table

-- DROP TABLE network_select;

CREATE TABLE network_select (
  network_id varchar(12) NOT NULL,
  acquirer_id varchar(12) NOT NULL,
  card_product varchar(12) NOT NULL,
  channel_type varchar(12) NOT NULL,
  description varchar(255) NULL,
  from_offset varchar(16) NULL,
  imf_data varchar(128) NULL,
  imf_search_flag varchar(255) NULL,
  imf_value varchar(128) NULL,
  issuer_id varchar(12) NOT NULL,
  mti varchar(4) NOT NULL,
  to_offset varchar(45) NULL,
  tp_code varchar(6) NOT NULL,
  created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
  created_at timestamp NOT NULL DEFAULT now(),
modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
modified_at timestamp NOT NULL DEFAULT now(),
CONSTRAINT network_select_pkey PRIMARY KEY (network_id)
);

-- transaction_group definition

-- Drop table

-- DROP TABLE transaction_group;

CREATE TABLE transaction_group (
  transaction_group_id int8 NOT NULL DEFAULT nextval('transaction_group_seq'::regclass),
transaction_group varchar(16) NOT NULL,
transaction_code varchar(30) NOT NULL,
status bpchar(1) NOT NULL,
description varchar(100) NOT NULL,
created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
created_at timestamp NOT NULL DEFAULT now(),
modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
modified_at timestamp NOT NULL DEFAULT now(),
CONSTRAINT group_code_status_uq UNIQUE (transaction_group, transaction_code, status),
CONSTRAINT status_chk CHECK ((status = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
CONSTRAINT transaction_group_pkey PRIMARY KEY (transaction_group_id)
);


-- transaction_key definition

-- Drop table

-- DROP TABLE transaction_key;

CREATE TABLE transaction_key (
  transaction_key_id varchar(16) NOT NULL,
  acquirer_id varchar(12) NOT NULL,
  channel_type varchar(12) NOT NULL,
  description varchar(255) NULL,
  imf_data varchar(128) NOT NULL,
  mti varchar(4) NOT NULL,
  tp_code varchar(6) NOT NULL,
  created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
  created_at timestamp NOT NULL DEFAULT now(),
modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
modified_at timestamp NOT NULL DEFAULT now(),
CONSTRAINT transaction_key_pkey PRIMARY KEY (transaction_key_id)
);

