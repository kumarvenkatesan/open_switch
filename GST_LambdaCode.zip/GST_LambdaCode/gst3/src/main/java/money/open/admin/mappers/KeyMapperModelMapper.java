package money.open.admin.mappers;

import money.open.admin.models.dto.KeyMapperDto;
import money.open.admin.models.entities.KeyMapper;
import org.mapstruct.Mapper;
import org.mapstruct.MappingInheritanceStrategy;

import java.util.List;

/**
 * Object to object mapper using map struct model mapper library.
 *
 * @see money.open.admin.models.dto.KeyMapperDto
 * @see money.open.admin.models.entities.KeyMapper
 * @author govil.kumar
 */
@Mapper(componentModel = "spring", mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_ALL_FROM_CONFIG)
public interface KeyMapperModelMapper {

    /**
     * Map entities to data transfer objects.
     *
     * @param keyMappers - list of key mapper entities
     * @return list of key mapper data transfer objects
     */
    List<KeyMapperDto> toKeyMapperDtoList(List<KeyMapper> keyMappers);

    /**
     * Map entity instance to data transfer object.
     *
     * @param entity - key mapper entity object.
     * @return key mapper data transfer object.
     */
    KeyMapperDto toKeyMapperDto(KeyMapper entity);

    /**
     * Map data transfer object to key mapper entity.
     *
     * @param keyMapperDto - data transfer object
     * @return key mapper entity.
     */
    KeyMapper toKeyMapperEntity(KeyMapperDto keyMapperDto);
}
