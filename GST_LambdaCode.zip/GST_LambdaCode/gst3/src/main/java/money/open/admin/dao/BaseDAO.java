package money.open.admin.dao;

import org.springframework.stereotype.Indexed;

import java.util.List;
import java.util.Optional;

/**
 * Base Dao interface which can be used in implementation classes to interact with the repository class to perform
 * database operations.
 *
 * @param <T>
 * @param <ID>
 * @author govil.kumar
 */
@Indexed
public interface BaseDAO<T, ID> {

    /**
     * Returns all instances of type.
     *
     * @return all instances.
     */
    List<T> findAll();

    /**
     * Retrieves an entity by its id.
     *
     * @param id - for which record need to be found, must not be null
     * @return the entity with the given id or Optional#empty() if none found.
     */
    Optional<T> findById(ID id);

    /**
     * Saves a given entity. Use the returned instance for further operations as the save operation might have changed
     * the entity instance completely.
     *
     * @param entity – must not be null.
     * @return the saved entity;
     */
    T save(T entity);

    /**
     * Deletes a given entity
     * @param id - must not be null, id against which record need to be deleted.
     */
    void deleteById(ID id);

    /**
     * Update a given entity. Use the returned instance for further operations as the save operation might have changed
     * the entity instance completely.
     *
     * @param entity – must not be null.
     * @return the updated entity;
     */
    T update(T entity);
}
