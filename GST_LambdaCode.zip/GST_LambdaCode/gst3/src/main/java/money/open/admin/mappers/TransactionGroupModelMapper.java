package money.open.admin.mappers;

import money.open.admin.models.dto.TransactionGroupDto;
import money.open.admin.models.entities.TransactionGroup;
import org.mapstruct.Mapper;
import org.mapstruct.MappingInheritanceStrategy;

import java.util.List;

/**
 * Object to object mapper using map struct model mapper library.
 *
 * @see money.open.admin.models.dto.TransactionGroupDto
 * @see money.open.admin.models.entities.TransactionGroup
 * @author govil.kumar
 */
@Mapper(componentModel = "spring", mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_ALL_FROM_CONFIG)
public interface TransactionGroupModelMapper {

    /**
     * Map entities to data transfer objects.
     *
     * @param transactionGroups - list of transaction group
     * @return list of transaction group data transfer objects
     */
    List<TransactionGroupDto> toTransactionGroupDtoList(List<TransactionGroup> transactionGroups);

    /**
     * Map entity instance to data transfer object.
     *
     * @param transactionGroup - transaction group entity object.
     * @return transaction group data transfer object.
     */
    TransactionGroupDto toTransactionGroupDto(TransactionGroup transactionGroup);

    /**
     * Map data transfer object to transaction group entity.
     *
     * @param transactionGroupDto - data transfer object
     * @return transaction group entity.
     */
    TransactionGroup toTransactionGroupEntity(TransactionGroupDto transactionGroupDto);
}
