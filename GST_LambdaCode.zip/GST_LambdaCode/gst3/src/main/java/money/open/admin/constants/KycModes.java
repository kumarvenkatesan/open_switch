package money.open.admin.constants;

public enum KycModes {
	F,P,N
}
