package money.open.admin.mappers;

import money.open.admin.models.dto.CardDesignDto;
import money.open.admin.models.entities.CardDesign;
import money.open.admin.models.entities.Issuer;
import money.open.admin.models.entities.Partner;
import money.open.admin.models.entities.VendorMaster;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * Object to object mapper using map struct model mapper library.
 *
 * @see money.open.admin.models.dto.CardDesignDto
 * @see money.open.admin.models.entities.CardDesign
 * @author govil.kumar
 */
@Mapper(componentModel = "spring", uses = {VendorMasterModelMapper.class, IssuerModelMapper.class, PartnerModelMapper.class} )
public interface CardDesignModelMapper {

    /**
     * Map entities to data transfer objects.
     *
     * @param cardDesigns - card design entities
     * @return data transfer objects
     */
    List<CardDesignDto> toCardDesignDtoList(List<CardDesign> cardDesigns);

    /**
     * Map entity to data transfer object.
     *
     * @param cardDesign - card design entity.
     * @return card design data transfer object
     */
    @Mapping(target = "vendorId", source = "cardDesign.vendorId.vendorId")
    @Mapping(target = "issuerBin", source = "cardDesign.issuerBin.issuerBin")
    @Mapping(target = "partnerEntityId", source = "cardDesign.partnerEntityId.partnerEntityId")
    CardDesignDto toCardDesignDto(CardDesign cardDesign);

    /**
     * Map partner entity to data transfer object.
     *
     * @param cardDesignDto - data transfer object
     * @param vendorMaster - vendor master entity
     * @param issuerBin - issuer bin entity
     * @param partner - partner entity
     * @return data transfer object
     */
    @Mapping(target = "vendorId", source = "vendorMaster")
    @Mapping(target = "issuerBin", source = "issuerBin")
    @Mapping(target = "partnerEntityId", source = "partner")
    @Mapping(target = "createdBy", source = "cardDesignDto.createdBy")
    @Mapping(target = "createdAt", source = "cardDesignDto.createdAt")
    @Mapping(target = "modifiedBy", source = "cardDesignDto.modifiedBy")
    @Mapping(target = "modifiedAt", source = "cardDesignDto.modifiedAt")
    @Mapping(target = "remarks", source = "cardDesignDto.remarks")
    @Mapping(target = "status", source = "cardDesignDto.status", defaultValue = "ACTIVE")
    @Mapping(target = "description", source = "cardDesignDto.description")
    @Mapping(target = "scheme", source = "cardDesignDto.scheme")
    CardDesign toCardDesignEntity(CardDesignDto cardDesignDto, VendorMaster vendorMaster,
                                        Issuer issuerBin, Partner partner);
}
