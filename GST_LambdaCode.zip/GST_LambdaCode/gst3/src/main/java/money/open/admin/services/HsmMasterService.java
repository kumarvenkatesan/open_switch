package money.open.admin.services;

import money.open.admin.models.dto.HsmMasterDto;

public interface HsmMasterService extends BaseService<HsmMasterDto, String> {
}
