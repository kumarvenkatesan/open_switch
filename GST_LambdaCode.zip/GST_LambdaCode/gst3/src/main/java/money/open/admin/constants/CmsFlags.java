package money.open.admin.constants;

public enum CmsFlags {
	Y,N
}
