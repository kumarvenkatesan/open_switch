package money.open.admin.mappers;

import money.open.admin.models.dto.ProgramMasterDto;
import money.open.admin.models.entities.Institution;
import money.open.admin.models.entities.Issuer;
import money.open.admin.models.entities.Partner;
import money.open.admin.models.entities.ProgramMaster;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * Object to object mapper using map struct model mapper library.
 *
 * @see money.open.admin.models.dto.ProgramMasterDto
 * @see money.open.admin.models.entities.ProgramMaster
 * @author govil.kumar
 */
@Mapper(componentModel = "spring", uses = {InstitutionModelMapper.class, IssuerModelMapper.class, PartnerModelMapper.class})
public interface ProgramMasterModelMapper {

    /**
     * Map entities to data transfer objects.
     *
     * @param programMasters - program master entities
     * @return data transfer objects
     */
    List<ProgramMasterDto> toProgramMasterDtoList(List<ProgramMaster> programMasters);

    /**
     * Map entity to data transfer object.
     *
     * @param programMaster - program master entity.
     * @return program master data transfer object
     */
    @Mapping(target = "issuerBin", source = "programMaster.issuerBin.issuerBin")
    @Mapping(target = "partnerEntityId", source = "programMaster.partnerEntityId.partnerEntityId")
    @Mapping(target = "institutionId", source = "programMaster.institutionId.institutionId")
    ProgramMasterDto toProgramMasterDto(ProgramMaster programMaster);

    /**
     * Map partner entity to data transfer object.
     *
     * @param programMasterDto - data transfer object
     * @param institution - institution entity
     * @param issuerBin - issuer bin entity
     * @param partner - partner entity
     * @return data transfer object
     */
    @Mapping(target = "institutionId", source = "institution")
    @Mapping(target = "issuerBin", source = "issuerBin")
    @Mapping(target = "partnerEntityId", source = "partner")
    @Mapping(target = "createdBy", source = "programMasterDto.createdBy")
    @Mapping(target = "createdAt", source = "programMasterDto.createdAt")
    @Mapping(target = "modifiedBy", source = "programMasterDto.modifiedBy")
    @Mapping(target = "modifiedAt", source = "programMasterDto.modifiedAt")
    @Mapping(target = "remarks", source = "programMasterDto.remarks")
    @Mapping(target = "status", source = "programMasterDto.status", defaultValue = "ACTIVE")
    @Mapping(target = "description", source = "programMasterDto.description")
    ProgramMaster toProgramMasterEntity(ProgramMasterDto programMasterDto, Institution institution,
                                        Issuer issuerBin, Partner partner);
}
