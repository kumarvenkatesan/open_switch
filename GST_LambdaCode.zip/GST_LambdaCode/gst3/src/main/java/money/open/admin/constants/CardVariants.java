package money.open.admin.constants;

public enum CardVariants {
	MG,OC,DI
}
