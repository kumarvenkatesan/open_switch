package money.open.admin.mappers;

import money.open.admin.models.dto.InstitutionDto;
import money.open.admin.models.entities.Institution;
import org.mapstruct.Mapper;
import org.mapstruct.MappingInheritanceStrategy;

import java.util.List;

/**
 * Object to object mapper using map struct model mapper library.
 *
 * @see InstitutionDto
 * @see Institution
 * @author govil.kumar
 */
@Mapper(componentModel = "spring", mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_ALL_FROM_CONFIG)
public interface InstitutionModelMapper {

    /**
     * Map entities to data transfer objects.
     *
     * @param institutions - list of institution entities
     * @return list of institution data transfer objects
     */
    List<InstitutionDto> toInstitutionDtoList(List<Institution> institutions);

    /**
     * Map entity instance to data transfer object.
     *
     * @param entity - institution entity object.
     * @return institution data transfer object.
     */
    InstitutionDto toInstitutionDto(Institution entity);

    /**
     * Map data transfer object to institution entity.
     *
     * @param institutionDto - data transfer object
     * @return institution entity.
     */
    Institution toInstitutionEntity(InstitutionDto institutionDto);
}
