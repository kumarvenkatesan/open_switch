package money.open.admin.repositories;

import money.open.admin.models.entities.ProgramMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProgramMasterRepository extends JpaRepository<ProgramMaster, Long> {
}
