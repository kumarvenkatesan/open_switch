package money.open.admin.services;

import money.open.admin.exceptions.AdminException;
import org.springframework.stereotype.Indexed;

import java.util.List;

/**
 * Class serves as a base interface for all the other service interface.
 *
 * @param <T> - Object on which business logic need to be written.
 * @param <ID> - Object identifier.
 * @author govil.kumar
 */
@Indexed
public interface BaseService<T, ID> {

    /**
     * Return all instances of type.
     *
     * @return list of instances.
     */
    List<T> fetchAll();

    /**
     * Get instance object by id.
     *
     * @param id - must not be null, identifier
     * @return instance response by the identifier
     */
    T fetchById(ID id) throws AdminException;

    /**
     * Create a new instance.
     *
     * @param request object, must not null
     * @return institution response upon successful persist.
     */
    T create(T request) throws AdminException;

    /**
     * Perform soft delete update status to 'DELETED'.
     *
     * @param id - must not be null, instance identifier
     */
    void performSoftDelete(ID id) throws AdminException;

    /**
     * Update an existing instance.
     *
     * @param id - institution identifier, must not be null.
     * @param request - instance which need to be updated.
     * @return response object upon successful update.
     * @throws AdminException - throws custom exception with error code and description
     */
    T update(ID id, T request) throws AdminException;

}
