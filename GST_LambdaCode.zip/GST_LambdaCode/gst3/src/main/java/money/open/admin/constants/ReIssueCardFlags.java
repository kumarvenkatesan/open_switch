package money.open.admin.constants;

public enum ReIssueCardFlags {
	O,N
}
