package money.open.admin.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springdoc.core.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration class for Swagger documentation.
 */
@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI springShopOpenAPI() {
        return new OpenAPI()
                .info(apiInfo());
    }
    private Info apiInfo() {
        return new Info()
                .title("OpenSwitch-Admin")
                .description("APIs to perform operations on static content.")
                .version("v.0.0.1")
                .license(license())
                .termsOfService("Terms of Service");
    }

    private License license() {
        return new License().name("Bank Open License").url("");
    }

    @Bean
    public GroupedOpenApi publicApi() {
        return GroupedOpenApi.builder()
                .group("Public Group")
                .pathsToMatch("/admin/**")
                .build();
    }
}
