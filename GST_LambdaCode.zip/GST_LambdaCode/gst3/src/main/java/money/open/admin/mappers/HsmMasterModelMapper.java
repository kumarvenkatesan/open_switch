package money.open.admin.mappers;

import money.open.admin.models.dto.HsmMasterDto;
import money.open.admin.models.entities.HsmMaster;
import org.mapstruct.Mapper;
import org.mapstruct.MappingInheritanceStrategy;

import java.util.List;

@Mapper(componentModel = "spring", mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_ALL_FROM_CONFIG)
public interface HsmMasterModelMapper {

    List<HsmMasterDto> toHsmMasterDtoList(List<HsmMaster> hsmMasters);

    HsmMasterDto toHsmMasterDto(HsmMaster hsmMaster);

    HsmMaster toHsmMasterEntity(HsmMasterDto hsmMasterDto);

}
