package money.open.admin.services;

import money.open.admin.models.dto.CardProductDto;

public interface CardProductService extends BaseService<CardProductDto, String>{
}
