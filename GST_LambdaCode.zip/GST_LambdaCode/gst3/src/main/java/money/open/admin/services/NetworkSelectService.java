package money.open.admin.services;

import money.open.admin.models.dto.network.NetworkSelectDto;

public interface NetworkSelectService extends BaseService<NetworkSelectDto, String> {
}
