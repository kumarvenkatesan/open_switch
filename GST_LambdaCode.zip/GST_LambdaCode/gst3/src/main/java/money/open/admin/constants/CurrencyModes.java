package money.open.admin.constants;

public enum CurrencyModes {
	S,H
}
