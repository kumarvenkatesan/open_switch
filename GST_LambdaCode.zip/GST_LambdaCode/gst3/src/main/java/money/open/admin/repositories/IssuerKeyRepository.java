package money.open.admin.repositories;

import money.open.admin.models.entities.IssuerKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IssuerKeyRepository extends JpaRepository<IssuerKey, String> {
}