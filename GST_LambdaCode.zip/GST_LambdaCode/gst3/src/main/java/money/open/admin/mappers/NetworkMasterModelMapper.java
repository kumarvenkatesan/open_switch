package money.open.admin.mappers;

import money.open.admin.models.dto.network.NetworkMasterDto;
import money.open.admin.models.entities.network.NetworkMaster;
import org.mapstruct.Mapper;
import org.mapstruct.MappingInheritanceStrategy;

import java.util.List;

/**
 * Object to object mapper using map struct model mapper library.
 *
 * @see money.open.admin.models.entities.network.NetworkMaster
 * @see money.open.admin.models.dto.network.NetworkMasterDto
 * @author govil.kumar
 */
@Mapper(componentModel = "spring", mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_ALL_FROM_CONFIG)
public interface NetworkMasterModelMapper {

    /**
     * Map entities to data transfer objects.
     *
     * @param networkMasters - list of network master entities
     * @return list of network master data transfer objects
     */
    List<NetworkMasterDto> toNetworkMasterDtoList(List<NetworkMaster> networkMasters);

    /**
     * Map entity instance to data transfer object.
     *
     * @param entity - network master entity object.
     * @return network master data transfer object.
     */
    NetworkMasterDto toNetworkMasterDto(NetworkMaster entity);

    /**
     * Map data transfer object to network master entity.
     *
     * @param networkMasterDto - data transfer object
     * @return network master entity.
     */
    NetworkMaster toNetworkMasterEntity(NetworkMasterDto networkMasterDto);
}
