package money.open.admin.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import money.open.admin.exceptions.AdminException;
import money.open.admin.models.dto.AdminResponse;
import money.open.admin.models.dto.LimitMasterDto;
import money.open.admin.services.LimitMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/admin")
@Tag(name = "Limit Master", description = "REST endpoints to perform CRUD operations on limit master")
public class LimitMasterController {

    @Autowired
    private LimitMasterService limitMasterService;

    @Operation(summary = "Fetch all limit master.", responses =
    @ApiResponse(responseCode = "200", description = "List of limit master.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    @GetMapping("/limitmasters")
    public AdminResponse getLimitMasters() {
        var limitMasterDtos = limitMasterService.fetchAll();
        return new AdminResponse(limitMasterDtos);
    }

    @GetMapping("/limitmaster/{id}")
    @Operation(summary = "Fetch limit master by id.", responses =
    @ApiResponse(responseCode = "200", description = "Get a single limit master.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse limitmasterById(@NotNull @PathVariable("id") Long id) throws AdminException {
        var limitMasterDto = limitMasterService.fetchById(id);
        return new AdminResponse(limitMasterDto);
    }

    @PostMapping("/limitmaster")
    @Operation(summary = "Create a limit master.", responses =
    @ApiResponse(responseCode = "200", description = "Created limit master.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse addLimitMaster(@Valid @RequestBody LimitMasterDto limitMasterDto) throws AdminException {
        LimitMasterDto response = limitMasterService.create(limitMasterDto);
        return new AdminResponse(response);
    }

    @PutMapping("/limitmaster/{id}")
    @Operation(summary = "Update a limit master.", responses =
    @ApiResponse(responseCode = "200", description = "Updated limit master", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse updateInstitution(@NotNull @PathVariable("id") Long id,
                                           @Valid @RequestBody LimitMasterDto limitMasterDto) throws AdminException {
        LimitMasterDto response = limitMasterService.update(id, limitMasterDto);
        return new AdminResponse(response);
    }

    @DeleteMapping("/limitmaster/{id}")
    @Operation(summary = "Delete a limit master. Soft Delete.")
    public void delete(@NotNull @PathVariable("id") Long id) throws AdminException {
        limitMasterService.performSoftDelete(id);
    }
}
