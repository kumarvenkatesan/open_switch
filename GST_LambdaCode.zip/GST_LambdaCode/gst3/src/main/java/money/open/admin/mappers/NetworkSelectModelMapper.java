package money.open.admin.mappers;

import money.open.admin.models.dto.network.NetworkSelectDto;
import money.open.admin.models.entities.network.NetworkSelect;
import org.mapstruct.Mapper;
import org.mapstruct.MappingInheritanceStrategy;

import java.util.List;

/**
 * Object to object mapper using map struct model mapper library.
 *
 * @see money.open.admin.models.dto.network.NetworkSelectDto
 * @see money.open.admin.models.entities.network.NetworkSelect
 * @author govil.kumar
 */
@Mapper(componentModel = "spring", mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_ALL_FROM_CONFIG)
public interface NetworkSelectModelMapper {

    List<NetworkSelectDto> toNetworkSelectDtoList(List<NetworkSelect> networkSelects);

    NetworkSelectDto toNetworkSelectDto(NetworkSelect networkSelect);

    NetworkSelect toNetworkSelectEntity(NetworkSelectDto networkSelectDto);
}
