package money.open.admin.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import money.open.admin.exceptions.AdminException;
import money.open.admin.models.dto.AdminResponse;
import money.open.admin.models.dto.TransactionGroupDto;
import money.open.admin.services.TransactionGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/admin/transaction")
@Tag(name = "Transaction Group", description = "REST APIs to perform CRUD operations on transaction group.")
public class TransactionGroupController {

    @Autowired
    private TransactionGroupService transactionGroupService;

    @Operation(summary = "Fetch all transaction groups.", responses =
    @ApiResponse(responseCode = "200", description = "List of transaction groups.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    @GetMapping("/groups")
    public AdminResponse getTransactionGroups() {
        var transactionGroups = transactionGroupService.fetchAll();
        return new AdminResponse(transactionGroups);
    }

    @GetMapping("/groups/{id}")
    @Operation(summary = "Fetch transaction groups by id.", responses =
    @ApiResponse(responseCode = "200", description = "Get a transaction group.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse transactionGroupById(@NotNull @PathVariable("id") String id) throws AdminException {
        var transactionGroupDto = transactionGroupService.fetchById(id);
        return new AdminResponse(transactionGroupDto);
    }
    @PostMapping("/group")
    @Operation(summary = "Create a transaction group.", responses =
    @ApiResponse(responseCode = "200", description = "Created transaction group.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse addTransactionGroup(@Valid @RequestBody TransactionGroupDto request) throws AdminException {
        var transactionGroupDto = transactionGroupService.create(request);
        return new AdminResponse(transactionGroupDto);
    }

    @PutMapping("/group/{id}")
    @Operation(summary = "Update a transaction group.", responses =
    @ApiResponse(responseCode = "200", description = "Updated transaction group", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse updateTransactionGroup(@NotNull @PathVariable("id") String id,@Valid @RequestBody TransactionGroupDto transactionGroupDto) throws AdminException {
        var response = transactionGroupService.update(id, transactionGroupDto);
        return new AdminResponse(response);
    }

    @DeleteMapping("/group/{id}")
    @Operation(summary = "Delete a transaction group. Soft Delete.")
    public void delete(@NotNull @PathVariable("id") String id) throws AdminException {
        transactionGroupService.performSoftDelete(id);
    }
}
