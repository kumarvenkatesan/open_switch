package money.open.admin.mappers;

import money.open.admin.models.dto.PartnerDto;
import money.open.admin.models.entities.Partner;
import org.mapstruct.Mapper;
import org.mapstruct.MappingInheritanceStrategy;

import java.util.List;
/**
 * Object to object mapper using map struct model mapper library.
 *
 * @see money.open.admin.models.dto.PartnerDto
 * @see money.open.admin.models.entities.Partner
 * @author govil.kumar
 */
@Mapper(componentModel = "spring", mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_ALL_FROM_CONFIG)
public interface PartnerModelMapper {

    /**
     * Map entities to data transfer objects.
     *
     * @param partners - partner entities
     * @return data transfer objects
     */
    List<PartnerDto> toPartnersDtoList(List<Partner> partners);

    /**
     * Map entities to data transfer object.
     *
     * @param partner - partner entity
     * @return data transfer object
     */
    PartnerDto toPartnerDto(Partner partner);

    /**
     * Map data transfer object to partner entity.
     *
     * @param partnerDto - data transfer object
     * @return partner entity
     */
    Partner toPartnerEntity(PartnerDto partnerDto);
}
