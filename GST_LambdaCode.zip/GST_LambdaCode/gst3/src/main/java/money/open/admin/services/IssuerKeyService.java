package money.open.admin.services;

import money.open.admin.models.dto.issuer.IssuerKeyDto;

public interface IssuerKeyService extends BaseService<IssuerKeyDto, String> {
}
