package money.open.admin.mappers;

import money.open.admin.models.dto.issuer.IssuerSelectDto;
import money.open.admin.models.entities.IssuerSelect;
import org.mapstruct.Mapper;
import org.mapstruct.MappingInheritanceStrategy;

import java.util.List;

/**
 * Object to object mapper using map struct model mapper library.
 *
 * @see money.open.admin.models.dto.issuer.IssuerSelectDto
 * @see money.open.admin.models.entities.IssuerSelect
 * @author govil.kumar
 */
@Mapper(componentModel = "spring", mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_ALL_FROM_CONFIG)
public interface IssuerSelectModelMapper {

    /**
     * Map entities to data transfer objects.
     *
     * @param issuerSelects - list of issuer select entities
     * @return list of issuer select data transfer objects
     */
    List<IssuerSelectDto> toIssuerSelectDtoList(List<IssuerSelect> issuerSelects);

    /**
     * Map entity instance to data transfer object.
     *
     * @param issuerSelect - issuer select entity object.
     * @return issuer select data transfer object.
     */
    IssuerSelectDto toIssuerSelectDto(IssuerSelect issuerSelect);

    /**
     * Map data transfer object to issuer select entity.
     *
     * @param issuerSelectDto - data transfer object
     * @return issuer select entity.
     */
    IssuerSelect toIssuerSelectEntity(IssuerSelectDto issuerSelectDto);
}
