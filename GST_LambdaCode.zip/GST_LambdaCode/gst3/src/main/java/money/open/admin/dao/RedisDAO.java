package money.open.admin.dao;

public interface RedisDAO<T> {

    void updateRedis(T entity);
}
