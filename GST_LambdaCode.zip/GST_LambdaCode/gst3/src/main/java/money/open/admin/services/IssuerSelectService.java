package money.open.admin.services;

import money.open.admin.models.dto.issuer.IssuerSelectDto;

public interface IssuerSelectService extends BaseService<IssuerSelectDto, String> {
}
