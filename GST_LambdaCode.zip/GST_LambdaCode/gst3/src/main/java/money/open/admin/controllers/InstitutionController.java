package money.open.admin.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import money.open.admin.exceptions.AdminException;
import money.open.admin.models.dto.AdminResponse;
import money.open.admin.models.dto.InstitutionDto;
import money.open.admin.services.InstitutionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/admin")
@Tag(name = "Institution", description = "REST endpoints to perform CRUD operations on institution")
public class InstitutionController {
    @Autowired
    private InstitutionService institutionService;

    @Operation(summary = "Fetch all institutions.", responses =
    @ApiResponse(responseCode = "200", description = "List of institutions.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    @GetMapping("/institutions")
    public AdminResponse getInstitutions() {
        var institutions = institutionService.fetchAll();
        return new AdminResponse(institutions);
    }
    @GetMapping("/institution/{id}")
    @Operation(summary = "Fetch institution by id.", responses =
    @ApiResponse(responseCode = "200", description = "Get a single institution.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse institutionById(@NotNull @PathVariable("id") String id) throws AdminException {
        var institution = institutionService.fetchById(id);
        return new AdminResponse(institution);
    }
    @PostMapping("/institution")
    @Operation(summary = "Create an institution.", responses =
    @ApiResponse(responseCode = "200", description = "Created institution.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse addInstitution(@Valid @RequestBody InstitutionDto request) throws AdminException {
        InstitutionDto response = institutionService.create(request);
        return new AdminResponse(response);
    }

    @PutMapping("/institution/{id}")
    @Operation(summary = "Update an institution.", responses =
    @ApiResponse(responseCode = "200", description = "Updated Institution", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse updateInstitution(@NotNull @PathVariable("id") String id,@Valid @RequestBody InstitutionDto institutionDto) throws AdminException {
        InstitutionDto response = institutionService.update(id, institutionDto);
        return new AdminResponse(response);
    }

    @DeleteMapping("/institution/{id}")
    @Operation(summary = "Delete an institution. Soft Delete.")
    public void delete(@NotNull @PathVariable("id") String id) throws AdminException {
        institutionService.performSoftDelete(id);
    }

}
