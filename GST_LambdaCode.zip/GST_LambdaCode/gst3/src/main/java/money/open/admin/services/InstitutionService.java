package money.open.admin.services;

import money.open.admin.models.dto.InstitutionDto;
import money.open.admin.models.entities.Institution;

/**
 * Service interface to handle business logic for institution entity.
 * @see Institution
 * @author govil.kumar
 */
public interface InstitutionService extends BaseService<InstitutionDto, String>{ }

