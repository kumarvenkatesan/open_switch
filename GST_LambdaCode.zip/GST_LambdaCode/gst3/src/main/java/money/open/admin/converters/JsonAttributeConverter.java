package money.open.admin.converters;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.util.Collections;
import java.util.Map;

@Converter
@Slf4j
public class JsonAttributeConverter implements AttributeConverter<Map<String, String>,String> {
	
	@Autowired
	private ObjectMapper objectMapper;

	@Override
	public String convertToDatabaseColumn(Map<String, String> attribute) {
		if(!attribute.isEmpty()) {
			try {
				return objectMapper.writeValueAsString(attribute);
			} catch (Exception e) {
				log.error("Exception converting to database column",e);
			}
		}
		return null;
	}

	@Override
	public Map<String, String> convertToEntityAttribute(String dbData) {
		if(StringUtils.isNotEmpty(dbData)) {
			try {
				return objectMapper.readValue(dbData, new TypeReference<>() {
				});
			} catch (Exception e) {
				log.error("Exception reading from database column",e);
			}
		}
		return Collections.emptyMap();
	}

}
