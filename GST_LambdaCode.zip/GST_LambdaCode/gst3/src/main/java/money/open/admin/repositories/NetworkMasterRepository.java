package money.open.admin.repositories;

import money.open.admin.models.entities.network.NetworkMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NetworkMasterRepository extends JpaRepository<NetworkMaster, String> {
}
