package money.open.admin.services;

import money.open.admin.models.dto.network.NetworkKeyDto;

public interface NetworkKeyService extends BaseService<NetworkKeyDto, String> {
}
