package money.open.admin.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import money.open.admin.exceptions.AdminException;
import money.open.admin.models.dto.AdminResponse;
import money.open.admin.models.dto.VendorMasterDto;
import money.open.admin.services.VendorMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/admin")
@Tag(name = "Vendor Master", description = "REST endpoints to perform CRUD operations on vendor master")
public class VendorMasterController {

    @Autowired
    private VendorMasterService vendorMasterService;

    @GetMapping("/vendormasters")
    @Operation(summary = "Fetch all vendor masters", responses =
    @ApiResponse(responseCode = "200", description = "List of vendor masters", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse getVendorMasters() {
        var vendorMasterDtos = vendorMasterService.fetchAll();
        return new AdminResponse(vendorMasterDtos);
    }

    @GetMapping("/vendormaster/{id}")
    @Operation(summary = "Get vendor master by id.", responses =
    @ApiResponse(responseCode = "200", description = "Vendor Master", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse getVendorByVendorId(@PathVariable("id") @NotNull String id) throws AdminException {
        var vendorMaster = vendorMasterService.fetchById(id);
        return new AdminResponse(vendorMaster);
    }

    @PostMapping("/vendormaster")
    @Operation(summary = "Create a vendor master", responses =
    @ApiResponse(responseCode = "200", description = "Created vendor master.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse addVendorMaster(@Valid @RequestBody VendorMasterDto request) throws AdminException {
        VendorMasterDto response = vendorMasterService.create(request);
        return new AdminResponse(response);
    }

    @DeleteMapping("/vendormaster/{id}")
    @Operation(summary = "Delete a vendor master. Soft Delete")
    public void delete(@PathVariable("id") @NotNull String id) throws AdminException {
        vendorMasterService.performSoftDelete(id);
    }

    @PutMapping("/vendormaster/{id}")
    @Operation(summary = "Update a vendor master.", responses =
    @ApiResponse(responseCode = "200", description = "Updated vendor master.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse updateVendorMaster(@PathVariable("id") @NotNull String id,
                                            @Valid @RequestBody VendorMasterDto vendorMasterDto) throws AdminException {
        VendorMasterDto response = vendorMasterService.update(id, vendorMasterDto);
        return new AdminResponse(response);
    }
}
