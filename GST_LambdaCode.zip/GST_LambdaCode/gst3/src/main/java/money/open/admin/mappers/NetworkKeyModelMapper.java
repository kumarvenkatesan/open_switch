package money.open.admin.mappers;

import money.open.admin.models.dto.network.NetworkKeyDto;
import money.open.admin.models.entities.network.NetworkKey;
import org.mapstruct.Mapper;
import org.mapstruct.MappingInheritanceStrategy;

import java.util.List;

@Mapper(componentModel = "spring", mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_ALL_FROM_CONFIG)
public interface NetworkKeyModelMapper {

    List<NetworkKeyDto> toNetworkKeyDtoList(List<NetworkKey> networkKeys);

    NetworkKeyDto toNetworkKeyDto(NetworkKey networkKey);

    NetworkKey toNetworkKeyEntity(NetworkKeyDto networkKeyDto);
}
