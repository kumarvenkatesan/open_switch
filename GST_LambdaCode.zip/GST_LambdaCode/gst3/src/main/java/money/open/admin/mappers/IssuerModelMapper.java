package money.open.admin.mappers;

import money.open.admin.models.dto.issuer.IssuerBinDto;
import money.open.admin.models.dto.issuer.IssuerKeyDto;
import money.open.admin.models.entities.Institution;
import money.open.admin.models.entities.Issuer;
import money.open.admin.models.entities.IssuerKey;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * Object to object mapper using map struct model mapper library.
 *
 * @see IssuerBinDto
 * @see  Issuer
 * @author govil.kumar
 */
@Mapper(componentModel = "spring", uses = InstitutionModelMapper.class)
public interface IssuerModelMapper {

    /**
     * Map entities to data transfer objects.
     *
     * @param issuers - list of issuer entities
     * @return list of issuers data transfer objects
     */
    List<IssuerBinDto> toIssuerBinDtoList(List<Issuer> issuers);

    /**
     * Map entity instance to data transfer object.
     *
     * @param issuerBin - issuer bin entity object.
     * @return issuer bin data transfer object.
     */
    @Mapping(target = "institutionId", source = "issuerBin.institutionId.institutionId")
    IssuerBinDto toIssuerBinDto(Issuer issuerBin);

    /**
     * Map data transfer object to issuer bin entity.
     *
     * @param issuerBinDto - data transfer object
     * @param institution - institution entity
     * @return issuer bin entity
     */
    @Mapping(target = "institutionId", source = "institution")
    @Mapping(target = "createdBy", source = "issuerBinDto.createdBy")
    @Mapping(target = "createdAt", source = "issuerBinDto.createdAt")
    @Mapping(target = "modifiedBy", source = "issuerBinDto.modifiedBy")
    @Mapping(target = "modifiedAt", source = "issuerBinDto.modifiedAt")
    @Mapping(target = "remarks", source = "issuerBinDto.remarks")
    @Mapping(target = "status", source = "issuerBinDto.status", defaultValue = "ACTIVE")
    Issuer toIssuerBinEntity(IssuerBinDto issuerBinDto, Institution institution);

    List<IssuerKeyDto> toIssuerKeyDtoList(List<IssuerKey> issuerKeys);

    IssuerKeyDto toIssuerKeyDto(IssuerKey issuerKey);

    IssuerKey toIssuerKeyEntity(IssuerKeyDto issuerKeyDto);

}
