package money.open.admin.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import money.open.admin.exceptions.AdminException;
import money.open.admin.models.dto.AdminResponse;
import money.open.admin.models.dto.TransactionKeyDto;
import money.open.admin.services.TransactionKeyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/admin/transaction")
@Tag(name = "Transaction Key", description = "REST APIs to perform CRUD operations on transaction key.")
public class TransactionKeyController {

    @Autowired
    private TransactionKeyService transactionKeyService;

    @Operation(summary = "Fetch all transaction keys.", responses =
    @ApiResponse(responseCode = "200", description = "List of transaction keys.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    @GetMapping("/keys")
    public AdminResponse getInstitutions() {
        var transactionKeys = transactionKeyService.fetchAll();
        return new AdminResponse(transactionKeys);
    }

    @GetMapping("/key/{id}")
    @Operation(summary = "Fetch transaction key by id.", responses =
    @ApiResponse(responseCode = "200", description = "Get a single transaction.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse transactionById(@NotNull @PathVariable("id") String id) throws AdminException {
        var transactionKey = transactionKeyService.fetchById(id);
        return new AdminResponse(transactionKey);
    }

    @PostMapping("/key")
    @Operation(summary = "Create a transaction key.", responses =
    @ApiResponse(responseCode = "200", description = "Created transaction key.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse addTransactionKey(@Valid @RequestBody TransactionKeyDto request) throws AdminException {
        TransactionKeyDto response = transactionKeyService.create(request);
        return new AdminResponse(response);
    }

    @PutMapping("/key/{id}")
    @Operation(summary = "Update a transaction key.", responses =
    @ApiResponse(responseCode = "200", description = "Updated transaction key", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse updateTransactionKey(@NotNull @PathVariable("id") String id,
                                              @Valid @RequestBody TransactionKeyDto transactionKeyDto) throws AdminException {
        TransactionKeyDto response = transactionKeyService.update(id, transactionKeyDto);
        return new AdminResponse(response);
    }

    @DeleteMapping("/key/{id}")
    @Operation(summary = "Delete a transaction key. Soft Delete.")
    public void delete(@NotNull @PathVariable("id") String id) throws AdminException {
        transactionKeyService.performSoftDelete(id);
    }
}
