package money.open.admin.services;

import money.open.admin.models.dto.CardDesignDto;

public interface CardDesignService extends BaseService<CardDesignDto, String> {
}
