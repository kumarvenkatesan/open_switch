package money.open.admin.constants;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum ResponseCode {
    SUCCESS("A00","Success"),
    FIELD_ERROR("A01","Field errors"),
    SYSTEM_ERROR("A02","System Error"),
    INVALID_CARD_PRODUCT("A03","Invalid Card Product"),
    INVALID_ID("A04","ID does not exist."),
    INVALID_CARD_DESIGN("A05","Invalid Card design"),
    INVALID_PROGRAM_MASTER("A06","Invalid Program master"),
    BIN_NOT_FOUND("A07", "No issuer found with the provided BIN"),
    INSTITUTION_NOT_FOUND("A08", "No institution found with the provided identifier."),
    PARTNER_NOT_FOUND("A09", "No partner present with the provided id."),
    NOT_FOUND("A10", "Data Not Found."),
    PROGRAM_MASTER_NOT_FOUND("A11", "No program master present with the provided id."),
    VENDOR_NOT_FOUND("A12", "Invalid vendor id. No vendor master present with the provided id."),
    HSM_MASTER_NOT_FOUND("A13", "Invalid hsm master id. No Hsm master present with the provided id."),
    INVALID_VENDOR_ID("A14","Invalid Vendor id. No vendor present with the provided id." ),
    NETWORK_KEY_NOT_FOUND("A15", "Invalid Network Key Id. No network key found with the provided id."),
    ISSUER_KEY_NOT_FOUND("A16", "Invalid issuer Key Id. No issuer key found with the provided id."),
    LIMIT_MASTER_NOT_FOUND("A17", "Invalid limit master id. No limit master found with provided id."),
    KEY_MAPPER_NOT_FOUND("A18", "Key mapper not found."),
    INVALID_TRANSACTION_KEY("A19", "Invalid transaction key"),
    INVALID_TRANSACTION_GROUP("A20", "Invalid transaction group id."),
    NETWORK_SELECT_NOT_PRESENT("A21", "Invalid network select id. No network select present for the provided id."),
    NETWORK_MASTER_NOT_FOUND("A22", "Invalid network master id. No network master present for the provided identifier"),
    INTERNAL_SERVER_ERROR("A500", "Internal Server Error");

    @Getter
    private final String code;
    @Getter
    private final String message;
}
