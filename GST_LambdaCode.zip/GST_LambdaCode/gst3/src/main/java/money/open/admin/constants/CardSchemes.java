package money.open.admin.constants;

public enum CardSchemes {
	VISA,MASTER,RUPAY,CUP
}
