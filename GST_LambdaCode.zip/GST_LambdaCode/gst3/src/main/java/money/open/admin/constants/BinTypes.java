package money.open.admin.constants;

public enum BinTypes {
	PREPAID,CREDIT,DEBIT
}
