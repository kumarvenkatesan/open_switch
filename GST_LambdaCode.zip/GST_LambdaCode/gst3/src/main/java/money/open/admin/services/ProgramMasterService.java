package money.open.admin.services;

import money.open.admin.models.dto.ProgramMasterDto;

public interface ProgramMasterService extends BaseService<ProgramMasterDto, Long> {
}
