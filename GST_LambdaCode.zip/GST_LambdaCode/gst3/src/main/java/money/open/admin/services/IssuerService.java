package money.open.admin.services;

import money.open.admin.exceptions.AdminException;
import money.open.admin.models.dto.issuer.IssuerBinDto;
import money.open.admin.models.entities.Issuer;

import java.util.List;

/**
 * Service interface to handle business logic for issuer bin.
 * @see Issuer
 * @author govil.kumar
 */
public interface IssuerService {

    /**
     * Return all instances of Issuer bin DTO.
     *
     * @return list of instances of issuer type.
     */
    List<IssuerBinDto> issuers();

    /**
     *
     * Get issuer response by issuer bin number.
     *
     * @param bin - must not be null, issuer identifier
     * @return issuer response by bin number
     * @throws AdminException - throws custom exception with error code and description
     */
    IssuerBinDto getIssuerByBin(String bin) throws AdminException;

    /**
     * Add a new issuer instance.
     *
     * @return issuer bin response object upon successful persist.
     * @throws AdminException - throws custom exception with error code and description
     */
    IssuerBinDto createIssuer(IssuerBinDto request) throws AdminException;

    /**
     * Perform soft delete update status to 'DELETED'.
     *
     * @param bin - must not be null, BIN number
     * @throws AdminException - throws custom exception with error code and description
     */
    void performSoftDelete(String bin) throws AdminException;

    /**
     * Update a new issuer instance.
     *
     * @param id - identifier against which resource will be updated.
     * @return issuer bin response object upon successful update.
     */
    IssuerBinDto updateIssuer(String id, IssuerBinDto issuerBinDto) throws AdminException;
}
