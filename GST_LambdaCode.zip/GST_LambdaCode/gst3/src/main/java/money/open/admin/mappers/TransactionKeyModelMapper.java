package money.open.admin.mappers;

import money.open.admin.models.dto.TransactionKeyDto;
import money.open.admin.models.entities.TransactionKey;
import org.mapstruct.Mapper;
import org.mapstruct.MappingInheritanceStrategy;

import java.util.List;

/**
 * Object to object mapper using map struct model mapper library.
 *
 * @see money.open.admin.models.dto.TransactionKeyDto
 * @see money.open.admin.models.entities.TransactionKey
 * @author govil.kumar
 */
@Mapper(componentModel = "spring", mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_ALL_FROM_CONFIG)
public interface TransactionKeyModelMapper {

    /**
     * Map entities to data transfer objects.
     *
     * @param transactionKeys - list of transaction keys
     * @return list of transaction key data transfer objects
     */
    List<TransactionKeyDto> toTransactionKeyDtoList(List<TransactionKey> transactionKeys);

    /**
     * Map entity instance to data transfer object.
     *
     * @param transactionKey - transaction key entity object.
     * @return transaction key data transfer object.
     */
    TransactionKeyDto toTransactionKeyDto(TransactionKey transactionKey);

    /**
     * Map data transfer object to transaction key entity.
     *
     * @param transactionKeyDto - data transfer object
     * @return transaction key entity.
     */
    TransactionKey toTransactionKeyEntity(TransactionKeyDto transactionKeyDto);
}
