package money.open.admin.services;

import money.open.admin.models.dto.KeyMapperDto;

public interface KeyMapperService extends BaseService<KeyMapperDto, String> {
}
