package money.open.admin.repositories;

import money.open.admin.models.entities.HsmMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HsmMasterRepository extends JpaRepository<HsmMaster, String> {
}
