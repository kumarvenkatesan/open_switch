package money.open.admin.services;

import money.open.admin.models.dto.network.NetworkMasterDto;

public interface NetworkMasterService extends BaseService<NetworkMasterDto, String> {
}
