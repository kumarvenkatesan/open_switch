package money.open.admin.services;

import money.open.admin.models.dto.VendorMasterDto;
import money.open.admin.models.entities.VendorMaster;

/**
 * Service interface to handle business logic for vendor master entity.
 *
 * @see VendorMaster
 * @author govil.kumar
 */
public interface VendorMasterService extends BaseService<VendorMasterDto, String> {
}
