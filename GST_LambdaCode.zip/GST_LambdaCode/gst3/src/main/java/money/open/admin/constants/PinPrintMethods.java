package money.open.admin.constants;

public enum PinPrintMethods {
	I,O
}
