package money.open.admin.constants;

public enum ToggleSelect {
	Y,N
}
