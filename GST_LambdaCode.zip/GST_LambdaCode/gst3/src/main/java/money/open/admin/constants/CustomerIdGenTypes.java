package money.open.admin.constants;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CustomerIdGenTypes {
    P("Pass"),S("Sequence");

    final String description;
}
