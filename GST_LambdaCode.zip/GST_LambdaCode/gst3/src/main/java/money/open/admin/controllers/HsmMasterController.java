package money.open.admin.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import money.open.admin.exceptions.AdminException;
import money.open.admin.models.dto.AdminResponse;
import money.open.admin.models.dto.HsmMasterDto;
import money.open.admin.services.HsmMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/admin")
@Tag(name = "HSM Master", description = "REST endpoints to perform CRUD operations on HSM master")
public class HsmMasterController {

    @Autowired
    private HsmMasterService hsmMasterService;

    @GetMapping("/hsmmasters")
    @Operation(summary = "Fetch all HSM masters.", responses =
    @ApiResponse(responseCode = "200", description = "List of HSM masters.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse getHsmMasters() {
        var hsmMasters = hsmMasterService.fetchAll();
        return new AdminResponse(hsmMasters);
    }

    @GetMapping("/hsmmaster/{id}")
    @Operation(summary = "Get HSM master.", responses =
    @ApiResponse(responseCode = "200", description = "HSM Master", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse getHsmMaster(@NotNull @PathVariable("id") String id) throws AdminException {
        var hsmMasterDto = hsmMasterService.fetchById(id);
        return new AdminResponse(hsmMasterDto);
    }

    @PostMapping("/hsmmaster")
    @Operation(summary = "Create a HSM master.", responses =
    @ApiResponse(responseCode = "200", description = "Created HSM master.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse addHsmMaster(@Valid @RequestBody HsmMasterDto hsmMasterDto) throws AdminException {
        HsmMasterDto response = hsmMasterService.create(hsmMasterDto);
        return new AdminResponse(response);
    }

    @DeleteMapping("/hsmmaster/{id}")
    @Operation(summary = "Delete HSM master. Soft Delete.")
    public void delete(@NotNull @PathVariable("id") String id) throws AdminException {
        hsmMasterService.performSoftDelete(id);
    }

    @PutMapping("/hsmmaster/{id}")
    @Operation(summary = "Update HSM master.", responses =
    @ApiResponse(responseCode = "200", description = "Updated HSM master.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse updateHsmMaster(@NotNull @PathVariable("id") String id,@Valid @RequestBody HsmMasterDto hsmMasterDto) throws AdminException {
        HsmMasterDto response = hsmMasterService.update(id, hsmMasterDto);
        return new AdminResponse(response);
    }

}
