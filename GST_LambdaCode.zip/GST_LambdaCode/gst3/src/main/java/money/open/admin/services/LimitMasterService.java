package money.open.admin.services;


import money.open.admin.models.dto.LimitMasterDto;

public interface LimitMasterService extends BaseService<LimitMasterDto, Long>{
}
