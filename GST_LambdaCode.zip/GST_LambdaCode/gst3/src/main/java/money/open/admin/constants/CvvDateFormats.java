package money.open.admin.constants;

public enum CvvDateFormats {
	YYMM,MMYY
}
