package money.open.admin.mappers;

import money.open.admin.models.dto.CardProductDto;
import money.open.admin.models.entities.CardDesign;
import money.open.admin.models.entities.CardProduct;
import money.open.admin.models.entities.ProgramMaster;
import money.open.admin.models.entities.VendorMaster;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * Object to object mapper using map struct model mapper library.
 *
 * @see CardProductDto
 * @see  CardProduct
 * @author govil.kumar
 */
@Mapper(componentModel = "spring", uses = {ProgramMasterModelMapper.class})
public interface CardProductModelMapper {

    /**
     * Map entities to data transfer objects.
     *
     * @param cardProducts - list of card products.
     * @return list of card product data transfer objects
     */
    List<CardProductDto> toCardProductDtoList(List<CardProduct> cardProducts);

    /**
     * Map entity instance to data transfer object.
     *
     * @param cardProduct - card product entity.
     * @return card product data transfer object
     */
    @Mapping(target = "programMasterId", source = "cardProduct.programMasterId.programMasterId")
    @Mapping(target = "vendorId", source = "cardProduct.vendorId.vendorId")
    @Mapping(target = "cardDesignId", source = "cardProduct.cardDesignId.cardDesignId")
    CardProductDto toCardProductDto(CardProduct cardProduct);

    /**
     * Map data transfer object to card product entity.
     *
     * @param cardProductDto - card product data transfer object
     * @param programMaster - program master entity instance
     * @param vendorMaster - vendor master entity instance
     * @param cardDesign - card design entity instance
     * @return card product entity instance.
     */
    @Mapping(target = "programMasterId", source = "programMaster")
    @Mapping(target = "vendorId", source = "vendorMaster")
    @Mapping(target = "cardDesignId", source = "cardDesign")
    @Mapping(target = "createdBy", source = "cardProductDto.createdBy")
    @Mapping(target = "createdAt", source = "cardProductDto.createdAt")
    @Mapping(target = "modifiedBy", source = "cardProductDto.modifiedBy")
    @Mapping(target = "modifiedAt", source = "cardProductDto.modifiedAt")
    @Mapping(target = "remarks", source = "cardProductDto.remarks")
    @Mapping(target = "status", source = "cardProductDto.status", defaultValue = "ACTIVE")
    CardProduct toCardProductEntity(CardProductDto cardProductDto, ProgramMaster programMaster,
                                    VendorMaster vendorMaster, CardDesign cardDesign);

}
