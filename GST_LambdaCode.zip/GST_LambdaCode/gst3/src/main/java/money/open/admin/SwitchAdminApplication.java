package money.open.admin;

import co.elastic.apm.attach.ElasticApmAttacher;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;

@SpringBootApplication
@EnableRedisRepositories(basePackages = {
		"money.open.admin.redis.repositories"})
@EnableJpaRepositories(basePackages = {
		"money.open.admin.repositories"})
public class SwitchAdminApplication {
	public static void main(String[] args) {
        ElasticApmAttacher.attach();
        SpringApplication.run(SwitchAdminApplication.class, args);
	}

}
