package money.open.admin.mappers;

import money.open.admin.models.dto.VendorMasterDto;
import money.open.admin.models.entities.VendorMaster;
import org.mapstruct.Mapper;
import org.mapstruct.MappingInheritanceStrategy;

import java.util.List;

/**
 * Object to object mapper using map struct model mapper library.
 *
 * @author govil.kumar
 * @see money.open.admin.models.entities.VendorMaster
 * @see money.open.admin.models.dto.VendorMasterDto
 */
@Mapper(componentModel = "spring", mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_ALL_FROM_CONFIG)
public interface VendorMasterModelMapper {

    /**
     * Map entities to data transfer objects.
     *
     * @param vendorMasters - vendor master entities
     * @return data transfer objects
     */
    List<VendorMasterDto> toVendorMasterDtoList(List<VendorMaster> vendorMasters);

    /**
     * Map entity to data transfer object.
     *
     * @param vendorMaster - vendor master entity.
     * @return vendor master data transfer object
     */
    VendorMasterDto toVendorMasterDto(VendorMaster vendorMaster);

    /**
     * Map data transfer object to vendor master entity.
     *
     * @param vendorMasterDto - data transfer object
     * @return vendor master entity.
     */
    VendorMaster toVendorMasterEntity(VendorMasterDto vendorMasterDto);
}
