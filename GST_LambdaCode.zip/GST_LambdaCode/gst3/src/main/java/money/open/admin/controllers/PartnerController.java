package money.open.admin.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import money.open.admin.exceptions.AdminException;
import money.open.admin.models.dto.AdminResponse;
import money.open.admin.models.dto.PartnerDto;
import money.open.admin.services.PartnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/admin")
@Tag(name = "Partner", description = "REST endpoints to perform CRUD operations on partner")
public class PartnerController {

    @Autowired
    private PartnerService partnerService;
    @GetMapping("/partners")
    @Operation(summary = "Fetch all partners", responses =
    @ApiResponse(responseCode = "200", description = "List of partners.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse getPartners() {
        var partners = partnerService.getPartners();
        return new AdminResponse(partners);
    }

    @GetMapping("/partner/{id}")
    @Operation(summary = "Get a partner by partner id.", responses =
    @ApiResponse(responseCode = "200", description = "Partner", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse getPartnerById(@NotNull @PathVariable("id") String id) throws AdminException {
        var partner = partnerService.getPartnerById(id);
        return new AdminResponse(partner);
    }

    @PostMapping("/partner")
    @Operation(summary = "Create a partner", responses =
    @ApiResponse(responseCode = "200", description = "Created partner.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse addPartner(@Valid @RequestBody PartnerDto request) {
        PartnerDto response = partnerService.createPartner(request);
        return new AdminResponse(response);
    }

    @DeleteMapping("/partner/{id}")
    @Operation(summary = "Delete a partner. Soft Delete")
    public void delete(@NotNull @PathVariable("id") String id) throws AdminException {
        partnerService.performSoftDelete(id);
    }

    @PutMapping("/partner/{id}")
    @Operation(summary = "Update a partner.", responses =
    @ApiResponse(responseCode = "200", description = "Updated partner.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse updateIssuer(@NotNull @PathVariable("id") String id,@Valid @RequestBody PartnerDto partnerDto) throws AdminException {
        PartnerDto response = partnerService.updatePartner(id, partnerDto);
        return new AdminResponse(response);
    }
}
