package money.open.admin.constants;

public enum CountryModes {
	D,I
}
