package money.open.admin.constants;

public enum PinForgotFlags {
	O,N
}
