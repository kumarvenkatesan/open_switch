package money.open.admin.constants;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

@AllArgsConstructor
public enum Status {
    INACTIVE(0,"INACTIVE"), ACTIVE(1, "ACTIVE"), DELETED(2, "DELETED");

    @Getter
    private final int value;
    @Getter
    private final String message;

    protected static final Map<Integer, Status> statusMap = new HashMap<>();

    static {
        for (Status status : Status.values()) {
            statusMap.put(status.getValue(), status);
        }
    }

}
