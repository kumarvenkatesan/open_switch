package money.open.admin.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.NoArgsConstructor;
import money.open.admin.exceptions.AdminException;
import money.open.admin.models.dto.AdminResponse;
import money.open.admin.models.dto.CardProductDto;
import money.open.admin.services.CardProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/admin/card")
@Tag(name = "Card Product", description = "REST endpoints to perform CRUD operations on card product.")
public class CardProductController {

    @Autowired
    private CardProductService cardProductService;

    @GetMapping("/products")
    @Operation(summary = "Fetch all the card products.", responses =
    @ApiResponse(responseCode = "200", description = "List of card products.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse getCardProducts() {
        var cardProducts = cardProductService.fetchAll();
        return new AdminResponse(cardProducts);
    }

    @Operation(summary = "Get card product by id.", responses =
    @ApiResponse(responseCode = "200", description = "Get single card product.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    @GetMapping("/product/{id}")
    public AdminResponse getCardProductById(@NotNull @PathVariable("id") String id) throws AdminException {
        var cardProductDto = cardProductService.fetchById(id);
        return new AdminResponse(cardProductDto);
    }

    @Operation(summary = "Create a new card product", responses =
    @ApiResponse(responseCode = "200", description = "New created card product.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    @PostMapping("/product")
    public AdminResponse addCardProduct(@Valid @RequestBody CardProductDto request) throws AdminException {
        CardProductDto response = cardProductService.create(request);
        return new AdminResponse(response);
    }

    @Operation(summary = "Delete a card product. This is a soft delete.")
    @DeleteMapping("/product/{id}")
    public void delete(@NotNull @PathVariable("id") String id) throws AdminException {
        cardProductService.performSoftDelete(id);
    }

    @Operation(summary = "Update a card product", responses =
    @ApiResponse(responseCode = "200", description = "Updated card product.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    @PutMapping("/product/{id}")
    public AdminResponse updateCardProduct(@NotNull @PathVariable("id") String id,
                                           @Valid @RequestBody CardProductDto cardProductDto) throws AdminException {
        CardProductDto response = cardProductService.update(id, cardProductDto);
        return new AdminResponse(response);
    }
}
