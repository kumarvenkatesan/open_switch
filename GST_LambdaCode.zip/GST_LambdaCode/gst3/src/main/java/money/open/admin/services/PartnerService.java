package money.open.admin.services;

import money.open.admin.exceptions.AdminException;
import money.open.admin.models.dto.PartnerDto;
import money.open.admin.models.entities.Partner;

import java.util.List;

/**
 * Service interface to handle business logic for issuer bin.
 * @see Partner
 * @author govil.kumar
 */
public interface PartnerService {

    /**
     * Return all partner of partner DTO.
     *
     * @return list of instances of partner type.
     */
    List<PartnerDto> getPartners();

    /**
     *
     * Get partner response by partner
     *
     * @param id - must not be null, partner identifier
     * @return partner response by partner id
     * @throws AdminException - throws custom exception with error code and description
     */
    PartnerDto getPartnerById(String id) throws AdminException;

    /**
     * Add a new partner instance.
     *
     * @param partnerDto request object, must not null
     * @return partner response object upon successful persist.
     */
    PartnerDto createPartner(PartnerDto partnerDto);

    /**
     * Perform soft delete update status to 'DELETED'.
     *
     * @param id - must not be null, partner identifier
     */
    void performSoftDelete(String id) throws AdminException;

    /**
     * Add a new partner instance.
     *
     * @param id - identifier for which resource will be updated.
     * @param partnerDto request object, must not null
     * @return partner response object upon successful update.
     */
    PartnerDto updatePartner(String id, PartnerDto partnerDto) throws AdminException;
}
