package money.open.admin.redis;

import lombok.extern.slf4j.Slf4j;
import money.open.admin.redis.services.runnables.CardDesignRedisRunnable;
import money.open.admin.redis.services.runnables.CardProductRedisRunnable;
import money.open.admin.redis.services.runnables.HsmMasterRedisRunnable;
import money.open.admin.redis.services.runnables.InstitutionRedisRunnable;
import money.open.admin.redis.services.runnables.IssuerBinRedisRunnable;
import money.open.admin.redis.services.runnables.IssuerKeyRedisRunnable;
import money.open.admin.redis.services.runnables.IssuerSelectRunnable;
import money.open.admin.redis.services.runnables.KeyMapperRedisRunnable;
import money.open.admin.redis.services.runnables.LimitMasterRedisRunnable;
import money.open.admin.redis.services.runnables.NetworkKeyRedisRunnable;
import money.open.admin.redis.services.runnables.NetworkMasterRedisRunnable;
import money.open.admin.redis.services.runnables.NetworkSelectRedisRunnable;
import money.open.admin.redis.services.runnables.PartnerRedisRunnable;
import money.open.admin.redis.services.runnables.ProgramMasterRedisRunnable;
import money.open.admin.redis.services.runnables.TransactionGroupRunnable;
import money.open.admin.redis.services.runnables.TransactionKeyRedisRunnable;
import money.open.admin.redis.services.runnables.VendorMasterRedisRunnable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Task runner to execute the redis data upload runners in parallel.
 * @author govil.kumar
 */

@Slf4j
@Component
public class DataUploaderTaskRunner {

    @Autowired
    private InstitutionRedisRunnable institutionRedisRunnable;

    @Autowired
    private PartnerRedisRunnable partnerRedisRunnable;

    @Autowired
    private IssuerKeyRedisRunnable issuerKeyRedisRunnable;

    @Autowired
    private IssuerBinRedisRunnable issuerBinRedisRunnable;

    @Autowired
    private HsmMasterRedisRunnable hsmMasterRedisRunnable;

    @Autowired
    private VendorMasterRedisRunnable vendorMasterRedisRunnable;

    @Autowired
    private KeyMapperRedisRunnable keyMapperRedisRunnable;

    @Autowired
    private CardDesignRedisRunnable cardDesignRedisRunnable;

    @Autowired
    private CardProductRedisRunnable cardProductRedisRunnable;

    @Autowired
    private LimitMasterRedisRunnable limitMasterRedisRunnable;

    @Autowired
    private NetworkKeyRedisRunnable networkKeyRedisRunnable;

    @Autowired
    private ProgramMasterRedisRunnable programMasterRedisRunnable;

    @Autowired
    private TransactionKeyRedisRunnable transactionKeyRedisRunnable;

    @Autowired
    private TransactionGroupRunnable transactionGroupRunnable;

    @Autowired
    private IssuerSelectRunnable issuerSelectRunnable;

    @Autowired
    private NetworkSelectRedisRunnable networkSelectRedisRunnable;

    @Autowired
    private NetworkMasterRedisRunnable networkMasterRedisRunnable;

    @PostConstruct
    public void load() {
        ExecutorService executorService = Executors
                .newFixedThreadPool(Runtime.getRuntime().availableProcessors());
        getRedisDataUploadTasks().forEach(executorService::execute);
    }

    /**
     * Helper method to get the list of dependent runnable tasks.
     *
     * @return list of runnable
     */
    private List<Runnable> getRedisDataUploadTasks() {
        return List.of(institutionRedisRunnable, partnerRedisRunnable, issuerKeyRedisRunnable, issuerBinRedisRunnable,
                hsmMasterRedisRunnable, vendorMasterRedisRunnable, keyMapperRedisRunnable, cardDesignRedisRunnable,
                cardProductRedisRunnable, limitMasterRedisRunnable, networkKeyRedisRunnable, programMasterRedisRunnable,
                transactionKeyRedisRunnable, transactionGroupRunnable, issuerSelectRunnable, networkSelectRedisRunnable,
                networkMasterRedisRunnable);
    }
}