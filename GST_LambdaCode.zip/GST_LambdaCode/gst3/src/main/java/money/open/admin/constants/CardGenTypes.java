package money.open.admin.constants;

public enum CardGenTypes {
	I,P
}
