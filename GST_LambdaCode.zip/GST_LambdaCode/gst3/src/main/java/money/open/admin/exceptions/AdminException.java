package money.open.admin.exceptions;

import lombok.Getter;
import money.open.admin.constants.ResponseCode;

public class AdminException extends Exception {
    @Getter
    private final ResponseCode responseCode;
    public AdminException(ResponseCode responseCodes){
        super(responseCodes.getMessage());
        this.responseCode = responseCodes;
    }
}
