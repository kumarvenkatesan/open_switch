package money.open.admin.exceptions;

public class RecordNotFoundException extends Exception {
    public RecordNotFoundException(String exception) {
        super(exception);
    }
}
