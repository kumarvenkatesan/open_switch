package money.open.admin.services;

import money.open.admin.models.dto.TransactionGroupDto;

public interface TransactionGroupService extends BaseService<TransactionGroupDto, String> {
}
