package money.open.admin.redis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import redis.clients.jedis.Jedis;

/**
 * Controller with REST endpoint to flush and reload the data to redis.
 * @author govil.kumar
 */
@RestController
@RequestMapping("/admin/redis")
public class RedisReloadController {

    @Autowired
    private Jedis jedis;

    @Autowired
    private DataUploaderTaskRunner dataUploaderTaskRunner;

    @PostMapping("/reload")
    public void reloadRedis() {
        jedis.flushAll();
        dataUploaderTaskRunner.load();
    }
}
