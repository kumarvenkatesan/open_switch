package money.open.admin.repositories;

import money.open.admin.models.entities.network.NetworkSelect;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NetworkSelectRepository extends JpaRepository<NetworkSelect, String> {
}
