package money.open.admin.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import money.open.admin.exceptions.AdminException;
import money.open.admin.models.dto.AdminResponse;
import money.open.admin.models.dto.CardDesignDto;
import money.open.admin.services.CardDesignService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/admin/card")
@Tag(name = "Card Design", description = "REST APIs to perform CRUD operations on card design.")
public class CardDesignController {

    @Autowired
    private CardDesignService cardDesignService;

    @GetMapping("/designs")
    @Operation(summary = "Fetch all card designs.", responses =
    @ApiResponse(responseCode = "200", description = "List of card designs.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    public AdminResponse getCardDesigns() {
        var cardDesignDtos = cardDesignService.fetchAll();
        return new AdminResponse(cardDesignDtos);
    }

    @Operation(summary = "Get card design by id.", responses =
    @ApiResponse(responseCode = "200", description = "Get single card design.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    @GetMapping("/design/{id}")
    public AdminResponse getCardDesignById(@NotNull @PathVariable("id") String id) throws AdminException {
        var cardDesignDto = cardDesignService.fetchById(id);
        return new AdminResponse(cardDesignDto);
    }

    @Operation(summary = "Create a new card design", responses =
    @ApiResponse(responseCode = "200", description = "New created card design.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    @PostMapping("/design")
    public AdminResponse addCardDesign(@Valid @RequestBody CardDesignDto request) throws AdminException {
        var response = cardDesignService.create(request);
        return new AdminResponse(response);
    }

    @Operation(summary = "Delete a card design. This is a soft delete.")
    @DeleteMapping("/design/{id}")
    public void delete(@NotNull @PathVariable("id") String id) throws AdminException {
        cardDesignService.performSoftDelete(id);
    }

    @Operation(summary = "Update a card design", responses =
    @ApiResponse(responseCode = "200", description = "Updated card design.", content = {
            @Content(mediaType = "application/json", schema =
            @Schema(implementation = AdminResponse.class))}))
    @PutMapping("/design/{id}")
    public AdminResponse updateCardDesign(@NotNull @PathVariable("id") String id,
                                           @Valid @RequestBody CardDesignDto cardDesignDto) throws AdminException {
        var response = cardDesignService.update(id, cardDesignDto);
        return new AdminResponse(response);
    }
}
