package money.open.admin.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;

import javax.sql.DataSource;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import static money.open.admin.formatters.DateTimeFormat.DATE_MMYYYY;
import static money.open.admin.formatters.DateTimeFormat.DATE_YYYY_MM_DD;

/**
 * Configuration class to establish database connection.
 */
@Configuration
public class DatabaseConfig {
    private static final int MAX_POOL_SIZE = 10;
    @Value("${spring.datasource.url}")
    private String url;
    @Value("${spring.datasource.name}")
    private String sourceName;
    @Value("${spring.datasource.username}")
    private String username;

    @Value("${spring.datasource.password}")
    private String password;

    @Value("${spring.jpa.properties.hibernate.default-schema}")
    private String schema;

    @Bean
    @Order(-1)
    @Primary
    @Profile("!test")
    public DataSource dataSource() {
        HikariConfig hConfig = new HikariConfig();
        hConfig.setJdbcUrl(url + "/" + sourceName);
        hConfig.setUsername(username);
        hConfig.setPassword(password);
        hConfig.setSchema(schema);
        hConfig.setMaximumPoolSize(MAX_POOL_SIZE);
        return new HikariDataSource(hConfig);
    }

    @Order(0)
    @Profile("!test")
    @Bean(initMethod = "migrate")
    @ConditionalOnProperty(name = "spring.flyway.enabled", havingValue = "true")
    public Flyway flyway() {
        Map<String, String> map = new HashMap<>();
        LocalDate d1 = LocalDate.now();
        LocalDate startDate = d1.withDayOfMonth(1);
        LocalDate endDate = d1.withDayOfMonth(d1.lengthOfMonth());

        map.put("date", d1.format(DATE_MMYYYY));
        map.put("start_date", startDate.format(DATE_YYYY_MM_DD));
        map.put("end_date", endDate.format(DATE_YYYY_MM_DD));
        return Flyway.configure().baselineOnMigrate(true).baselineVersion("0.0").schemas(schema)
                .defaultSchema(schema).dataSource(this.dataSource()).locations("classpath:db/migration")
                .placeholders(map).load();
    }
}
