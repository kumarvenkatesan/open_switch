package money.open.admin.exceptions;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.MismatchedInputException;
import lombok.extern.slf4j.Slf4j;
import money.open.admin.constants.ResponseCode;
import money.open.admin.models.dto.AdminResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.HashMap;
import java.util.Map;


@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
    private static final String VALIDATION_FAILED = "Validation Failed";

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
                                                                  HttpHeaders headers, HttpStatus status,
                                                                  WebRequest request) {
        Map<String, String> details = new HashMap<>();
        for (FieldError error : ex.getBindingResult().getFieldErrors()) {
            details.put(error.getField(), error.getDefaultMessage());
        }

        ErrorResponse error = new ErrorResponse(VALIDATION_FAILED, details);
        AdminResponse adminResponse = new AdminResponse();
        adminResponse.setResponseCode(ResponseCode.FIELD_ERROR.getCode());
        adminResponse.setFieldErrors(error);
        adminResponse.setErrorMessage(ResponseCode.FIELD_ERROR.getMessage());
        return new ResponseEntity(adminResponse, HttpStatus.OK);
    }

    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
                                                                  HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.info("Http not readable :: {}",ex.getMessage());
        Throwable t = ex.getCause();
        if(t instanceof MismatchedInputException) {
            JsonMappingException.Reference ref = ((MismatchedInputException) t).getPath().get(0);
            String errorMsg = "Not a valid format for field :: "+"'"+ref.getFieldName()+"'";
            return getConfigurationResponseEntity(errorMsg);
        }
        return getConfigurationResponseEntity(ex.getMessage());
    }

    @Override
    protected ResponseEntity<Object> handleServletRequestBindingException(ServletRequestBindingException ex,
                                                                          HttpHeaders headers, HttpStatus status, WebRequest request) {
        return getConfigurationResponseEntity(ex.getMessage());
    }

    @Override
    protected ResponseEntity<Object> handleMissingServletRequestParameter(
            MissingServletRequestParameterException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        return getConfigurationResponseEntity(ex.getMessage());
    }

    @ExceptionHandler(AdminException.class)
    public AdminResponse handlerAdminException(AdminException ex){
        log.info("Configuration exception :: {}", ex.getMessage());
        return new AdminResponse(ex.getResponseCode());
    }

    @ExceptionHandler(Exception.class)
    public AdminResponse handleException(Exception ex){
        log.error("Uncaught exception",ex);
        return new AdminResponse(ResponseCode.SYSTEM_ERROR);
    }

    private ResponseEntity<Object> getConfigurationResponseEntity(String message) {
        AdminResponse resp = new AdminResponse();
        resp.setErrorMessage(message);
        resp.setResponseCode(ResponseCode.FIELD_ERROR.getCode());
        return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
    }

//    @ExceptionHandler(RecordNotFoundException.class)
//    public final ResponseEntity<Object> handleUserNotFoundException(RecordNotFoundException ex, WebRequest request) {
//        List<String> details = new ArrayList<>();
//        details.add(ex.getLocalizedMessage());
//        ErrorResponse error = new ErrorResponse("Record Not Found", details);
//        return new ResponseEntity(error, HttpStatus.NOT_FOUND);
//    }
}
