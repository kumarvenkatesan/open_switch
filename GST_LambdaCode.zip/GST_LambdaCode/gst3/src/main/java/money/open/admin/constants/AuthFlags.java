package money.open.admin.constants;

public enum AuthFlags {
	Y,P
}
