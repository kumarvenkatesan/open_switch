package money.open.admin.constants;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum CardTypes {
	P("PHYSICAL"),V("VIRTUAL");
	@Getter
	private final String description;
}
