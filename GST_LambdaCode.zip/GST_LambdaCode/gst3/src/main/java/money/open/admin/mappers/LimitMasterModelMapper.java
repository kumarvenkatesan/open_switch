package money.open.admin.mappers;

import money.open.admin.models.dto.LimitMasterDto;
import money.open.admin.models.entities.LimitMaster;
import org.mapstruct.Mapper;
import org.mapstruct.MappingInheritanceStrategy;

import java.util.List;

/**
 * Object to object mapper using map struct model mapper library.
 *
 * @see LimitMasterDto
 * @see LimitMaster
 * @author govil.kumar
 */

@Mapper(componentModel = "spring", mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_ALL_FROM_CONFIG)
public interface LimitMasterModelMapper {


    /**
     * Map entities to data transfer objects.
     *
     * @param limitMasters - list of limit master entities
     * @return list of limit master data transfer objects
     */
    List<LimitMasterDto> toLimitMasterDtoList(List<LimitMaster> limitMasters);

    /**
     * Map entity instance to data transfer object.
     *
     * @param limitMaster - limit master entity object.
     * @return limit master data transfer object.
     */
    LimitMasterDto toLimitMasterDto(LimitMaster limitMaster);

    /**
     * Map data transfer object to limit master entity.
     *
     * @param limitMasterDto - data transfer object
     * @return limit master entity.
     */
    LimitMaster toLimitMasterEntity(LimitMasterDto limitMasterDto);
}
