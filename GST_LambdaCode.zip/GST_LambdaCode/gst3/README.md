# OpenSwitch-Admin
OpenSwitch-Admin service is responsible to maintain all static configurations required for the card issuance platform and expose the REST end point for the admin/support portal.

## Flow

* Data is fetched and uploaded to REDIS on service boot up.
* POST and PUT endpoints are exposed to UI layer to save and update the data. The moment data is saved to the configuration DB, another request is triggered to upload the updated or new data to the REDIS.
* Other card services will be using admin service's REDIS to fetch the configuration data.


![flow_diagram](https://user-images.githubusercontent.com/105037172/172540959-c9555feb-7dca-40cb-8fd7-4af3ba7a177c.png)
