package money.bankopen.cas.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.convert.RedisCustomConversions;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.scheduling.annotation.EnableAsync;

import lombok.extern.slf4j.Slf4j;
import money.bankopen.cas.config.utils.ByteArrToTimestampConverter;

@SpringBootApplication
@EntityScan("money.bankopen.cas.config.*")
@ComponentScan(basePackages = "money.bankopen.cas.config")
@EnableRedisRepositories(basePackages = "moeny.bankopen.cas.config.redis")
@EnableJpaRepositories(basePackages= "money.bankopen.cas.config.dao")
@EnableAsync
@Slf4j
@Configuration
public class OpencasConfigurationApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpencasConfigurationApplication.class, args);
	}
	
	@Value("${spring.redis.host}")
	private String redisIp;
	
	@Value("${spring.redis.port}")
	private int redisPort;
	
	@Value("${spring.redis.password}")
	private String redisPassword;
	
	@Bean
	JedisConnectionFactory jedisConnectionFactory() {
		log.info("IP : {} PORT : {}", redisIp, redisPort);
		var redisStandaloneConfiguration = new RedisStandaloneConfiguration(redisIp, redisPort);
		if(redisPassword != null) {
			redisStandaloneConfiguration.setPassword(redisPassword);
		}
		JedisConnectionFactory jedisConFactory = null;
		jedisConFactory = new JedisConnectionFactory(redisStandaloneConfiguration);
		return jedisConFactory;
	}

	@Bean
	public RedisTemplate<String, Object> redisTemplate() {
		RedisTemplate<String, Object> template = new RedisTemplate< >();
		template.setConnectionFactory(jedisConnectionFactory());
		template.setKeySerializer(new StringRedisSerializer());
		template.setValueSerializer(new StringRedisSerializer());
		return template;
	}
	
	
	@Bean
	RedisCustomConversions redisCustomConversions(ByteArrToTimestampConverter converter) {
		return new RedisCustomConversions(Arrays.asList(new ByteArrToTimestampConverter()));
	}
	
	
//	@Bean
//    public Docket api() { 
//        return new Docket(DocumentationType.SWAGGER_2).ignoredParameterTypes(AccountMaster.class, CustomerMaster.class)
//          .select()                                  
//          .apis(RequestHandlerSelectors.basePackage("com.open.cas.controller"))          
//          .paths(PathSelectors.any())                          
//          .build()
//          .apiInfo(apiInfo());                                   
//    }
//	
//	public void addResourceHandlers(ResourceHandlerRegistry registry) {
//	    registry.addResourceHandler("swagger-ui.html")
//	      .addResourceLocations("classpath:/META-INF/resources/");
//
//	    registry.addResourceHandler("/webjars/**")
//	      .addResourceLocations("classpath:/META-INF/resources/webjars/");
//	}
//	
//	private ApiInfo apiInfo() {
//	    return new ApiInfo(
//	      "Open-Cas Documentation", 
//	      "", 
//	      "1.0", 
//	      "", 
//	      new Contact("", "", ""), 
//	      "", "", Collections.emptyList());
//	}

}
