package money.bankopen.cas.config;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import money.bankopen.cas.config.service.RedisDataLoaderService;

@Component
public class RedisConfiguration implements InitializingBean{

	@Autowired
	public RedisDataLoaderService redisDataLoader;

	@Override
	public void afterPropertiesSet() throws Exception {
		redisDataLoader.redisDataLoaderService();
		
	}
	
	
}
