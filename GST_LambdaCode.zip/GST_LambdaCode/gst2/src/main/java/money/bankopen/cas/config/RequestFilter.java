package money.bankopen.cas.config;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.time.StopWatch;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class RequestFilter implements Filter{

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		
		final StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		
		res.setHeader("requestId", req.getHeader("requestId")); //Setting the recieved request id in response headers
		
		chain.doFilter(req, res);
		stopWatch.stop();
		
		if(req.getServletPath().contains("healthCheck"))
			return;
		
		log.info("Execution time for endpoint {} is {} ms",req.getServletPath(),stopWatch.getTime(TimeUnit.MILLISECONDS));
	}

}
