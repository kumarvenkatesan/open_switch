package money.bankopen.cas.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpencasConfigurationApplicationTests {

	@Test
	void contextLoads() {
	}

}
