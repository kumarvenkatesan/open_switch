package money.open.cards.transaction.utils;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import money.open.cards.transaction.helper.Helper;
import money.open.cards.transaction.redis.dao.NetworkSelectRedisDao;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class NetworkSelectUtilsTests {

	@InjectMocks
	private NetworkSelectUtils networkSelectUtils;

	@Mock
	private NetworkSelectRedisDao networkSelectRedisDao;

	@BeforeEach
	public void beforeEach() throws Exception {
		Mockito.when(networkSelectRedisDao.findByAcquirerIdAndIssuerId(Helper.ACQUIRER_ID, Helper.ISSUER_ID))
				.thenReturn(Helper.loadAllStarNetworkSelectData());
		Mockito.when(networkSelectRedisDao.findByAcquirerIdAndIssuerId(Helper.ACQUIRER_ID_ONE, Helper.ISSUER_ID_ONE))
				.thenReturn(Helper.loadAllStarNetworkSelectData());

	}

	@Test
	@DisplayName("Network Select Card Product Data Tests")
	void NetoworkSelectCardProductTest() {
		assertNull(Helper.NETWORK_KEY_ID, networkSelectUtils
				.networkSelectRedisData(Helper.loadAcqFailTransactionRequestDto(), Helper.ISSUER_ID_FAIL));
		assertEquals(Helper.NETWORK_KEY_ID,
				networkSelectUtils.networkSelectRedisData(Helper.loadTransactionRequestDto(), Helper.ISSUER_ID));
		assertEquals(Helper.NETWORK_KEY_ID, networkSelectUtils
				.networkSelectRedisData(Helper.loadCardProductDummyTransactionRequestDto(), Helper.ISSUER_ID));
		assertEquals(Helper.NETWORK_KEY_ID, networkSelectUtils
				.networkSelectRedisData(Helper.loadNoCardProductDummyTransactionRequestDto(), Helper.ISSUER_ID));
	}

	@Test
	@DisplayName("Network Select ChannelType Data Tests")
	void NetoworkSelectChannelTypeTest() {

		assertNull(networkSelectUtils.fetchNetworkIdByChannelType(Helper.loadNetworkSelectWithData(), "POS", "0210",
				"01"));
		assertEquals(Helper.NETWORK_KEY_ID, networkSelectUtils
				.fetchNetworkIdByChannelType(Helper.loadNetworkSelectWithData(), "ATM", "0200", "00"));
		assertEquals(Helper.NETWORK_KEY_ID, networkSelectUtils
				.fetchNetworkIdByChannelType(Helper.loadNetworkSelectAllStarData(), "POS", "0210", "01"));

	}

	@Test
	@DisplayName("Network Select Mti Data Tests")
	void NetoworkSelectMtiTest() {

		assertNull(networkSelectUtils.fetchNetworkIdByMti(Helper.loadNetworkSelectWithData(), "0210", "01"));
		assertEquals(Helper.NETWORK_KEY_ID,
				networkSelectUtils.fetchNetworkIdByMti(Helper.loadNetworkSelectWithData(), "0200", "00"));
		assertEquals(Helper.NETWORK_KEY_ID,
				networkSelectUtils.fetchNetworkIdByMti(Helper.loadNetworkSelectAllStarData(), "0210", "01"));

	}

	@Test
	@DisplayName("Network Select Tp Code Data Tests")
	void NetoworkSelectTpCodeTest() {
		assertNull(networkSelectUtils.fetchNetworkIdByTpCode(Helper.loadNetworkSelectSingleDigitWithData(), "01"));
		assertEquals(Helper.NETWORK_KEY_ID,
				networkSelectUtils.fetchNetworkIdByTpCode(Helper.loadNetworkSelectWithData(), "00"));
		assertNull(networkSelectUtils.fetchNetworkIdByTpCode(Helper.loadNetworkSelectWithData(), "01"));
		assertEquals(Helper.NETWORK_KEY_ID,
				networkSelectUtils.fetchNetworkIdByTpCode(Helper.loadNetworkSelectLongDigitWithData(), "010000"));
		assertNull(networkSelectUtils.fetchNetworkIdByTpCode(Helper.loadNetworkSelectLongDigitWithData(), "000000"));
		assertEquals(Helper.NETWORK_KEY_ID,
				networkSelectUtils.fetchNetworkIdByTpCode(Helper.loadNetworkSelectAllStarData(), "00"));

	}

}
