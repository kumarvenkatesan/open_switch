package money.open.cards.transaction.helper;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import money.open.cards.transaction.dto.CardMasterDto;
import money.open.cards.transaction.dto.LimitMasterDto;
import money.open.cards.transaction.dto.TransactionRequestDto;
import money.open.cards.transaction.enums.CardTypesEnum;
import money.open.cards.transaction.enums.CountryModesEnum;
import money.open.cards.transaction.model.CardMaster;
import money.open.cards.transaction.model.CardMasterStatuses;
import money.open.cards.transaction.model.LimitMaster;
import money.open.cards.transaction.redis.model.CardDesignRedis;
import money.open.cards.transaction.redis.model.CardProductRedis;
import money.open.cards.transaction.redis.model.InstitutionRedis;
import money.open.cards.transaction.redis.model.IssuerBinRedis;
import money.open.cards.transaction.redis.model.IssuerSelectRedis;
import money.open.cards.transaction.redis.model.KeyMapperRedis;
import money.open.cards.transaction.redis.model.NetworkSelectRedis;
import money.open.cards.transaction.redis.model.PartnerEntityRedis;
import money.open.cards.transaction.redis.model.ProgramMasterRedis;
import money.open.cards.transaction.redis.model.TransactionGroupRedis;
import money.open.cards.transaction.redis.model.VendorMasterRedis;

public class Helper {

	private Helper() {

	}

	public static final String INSTITUTION_NAME = "Yes Bank";
	public static final String INSTITUTION_ID_PASS = "YES";
	public static final String INSTITUTION_ID_FAIL = "SBM";
	public static final String PARTNER_ID_PASS = "OPEN";
	public static final String PARTNER_ID_FAIL = "OPEN1";
	public static final String VENDOR_MASTER_ID_PASS = "MCT";
	public static final String VENDOR_MASTER_ID_FAIL = "MCT1";
	public static final String VENDOR_MASTER_SCHEME = "VISA";
	public static final String HSM_MASTER_ID = "PRIMARY";
	public static final String ISSUER_BIN_PASS = "434460";
	public static final String ISSUER_BIN_FAIL = "434460";
	public static final String ISSUER_BIN_FINAL = "434460";
	public static final String ISSUER_BIN_COUNTRYCODE = "424460";
	public static final String ISSUER_KEY = "ISSUER1";
	public static final String ISS_WORKING_KEY = "1PUNE000,5FCE43D796DCB4E8213DF25A91DA737EE5D6E597E994D1D8,8073EDCB3E8859F5";
	public static final String NETWORK_KEY_ID = "OPEN_CAS";
	public static final Long PROGRAM_MASTER_ID = 2L;
	public static final String CARD_DESIGN_ID_PASS = "MCT_CARD_DESIGN";
	public static final String CARD_DESIGN_ID_FAIL = "SHESHASAI_CARD_DESIGN";
	public static final String CARD_PRODUCT_ID_PASS = "OPEN_MONEY";
	public static final String CARD_PRODUCT_ID_FAIL = "OPEN";
	public static final String CARD_PRODUCT_ID_BILLING = "OPENCARDS";
	public static final String CARD_PRODUCT_ID_WITHOUT_MARK = "OPENCARD";
	public static final String ADMIN_URL = "/admin";
	public static final String INSTITUTION_URL = ADMIN_URL + "/institution";
	public static final String INSTITUTION_BY_ID_URL = INSTITUTION_URL + "/" + INSTITUTION_ID_PASS;
	public static final String PARTNER_URL = ADMIN_URL + "partner";
	public static final String PARTNER_BY_ID_URL = PARTNER_URL + "/" + PARTNER_ID_PASS;
	public static final String ISSUER_BIN_URL = ADMIN_URL + "/issuer";
	public static final String PROXY_CARD_NUMBER_PASS = "OPEN0000000136";
	public static final String PROXY_CARD_NUMBER_FAIL = "ABC";
	public static final String SUCCESS_CARD_NUMBER = "30dcba887cb623896f58ea19bd10a2839bbdbc28ee9edfa572ce46bcc2306979149a5282b6f7ca96ae031ff570d58025e5c204eb75f6592ec7df0141df317f7a";
	public static final String FAILURE_CARD_NUMBER = "30dcba887cb623896f58ea19bd10a2839bbdbc28ee9edfa572ce46bcc2306979149a5282b6f7ca96ae";
	public static final String PIN_BLOCK_CARD_NUMBER = "3896f58ea19bd10a2839bbdbc28ee9edfa572ce46bcc2306979149a5282b6f7ca96ae031ff570d58025e5c204eb75f6592ec7df0141df317f7a";
	public static final String PIN_BLOCK_TIMER_CARD_NUMBER = "3896f58ea19bd10a2839bbdbc28ee9edfa572ce46bcc2306979149a5282b6f7ca96ae031ff570d58025e5c204eb75f6592ec7df0141df";
	public static final String MANUAL_CARD_NUMBER = "3896f58ea19bd10a2839bbdbc28ee9edfa572ce46bcc2306979149a5282b6f7ca96ae031ff570d580257df0141df";
	public static final String MANUAL1_CARD_NUMBER = "a2839bbdbc28ee9edfa572ce46bcc2306979149a5282b6f7ca96ae031ff570d580257df0141df";
	public static final String CLEAR_CARD_NUMBER = "4344601234561234";
	public static final String SOURCE = "zwitch";
	public static final String PROGRAM_KEY = "open_cards";
	public static final String CustomerID = "1000003100";

	public static final String OrderID = "1";
	public static final String Invalid_CustomerID = "12abc";
	public static final String MobileNo = "7540001654";
	public static final String Invalid_MobileNo = "1234567890";
	public static final String emailID = "abc@gmail.com";
	public static final String BATCH_MASTER_ID_PASS = "MCT0001";
	public static final String BATCH_MASTER_ID_FAIL = "MCT0002";
	public static final String Virtual_CardType = "V";
	public static final String PHYSCIAL_CARD_TYPE = "P";
	public static final String Vendor_Id = "MCT";
	public static final String CARD_ACTIVE_STATUS = CardMasterStatuses.CARD_ACTIVATED.getValue();
	public static final String CARD_PIN_BLOCKED = CardMasterStatuses.CARD_TEMP_BLOCKED_PIN_EXCEEDED.getValue();
	public static final String CARD_PIN_LOCKED = CardMasterStatuses.CARD_TEMP_BLOCKED.getValue();
	public static final String KEY_MAPPER_STATIC = "static";
	public static final String KEY_MAPPER_DYNAMIC = "dynamic";
	public static final String KEY_MAPPER_FAIL = "static_old";
	public static final Long PROGRAM_MASTER_PASS = 1L;
	public static final Long PROGRAM_MASTER_FAIL = 2L;
	public static final Long CARD_MASTER_PASS = 1L;
	public static final Long CARD_MASTER_FAIL = 2L;
	public static final String CARD_ORDER_PASS = "ORDER1";
	public static final String CARD_ORDER_FAIL = "ORDER2";
	public static final String DELIVERY_ADDRESS_PASS = "DELADD1";
	public static final String DELIVERY_ADDRESS_FAIL = "DELADD2";
	public static final String LIMIT_MASTER_ID_PASS = "limit1";
	public static final String LIMIT_MASTER_ID_FAIL = "limit2";
	public static final String TP_CODE_01 = "01";
	public static final String TP_CODE_00 = "00";
	public static final String TP_CODE_000000 = "000000";
	public static final String LIMIT_ENTITY_ID = "OPENMONEY";
	public static final String COUNTRY_MODE_D = CountryModesEnum.D.getValue();
	public static final String COUNTRY_MODE_I = CountryModesEnum.I.getValue();
	public static final String ATM = "ATM";
	public static final String POS = "POS";
	public static final String ECOM = "ECOM";
	public static final Long LIMIT_ID_PASS = 1L;
	public static final Long LIMIT_ID_FAIL = 2L;
	public static final CardTypesEnum CARD_TYPE_VIRTUAL = CardTypesEnum.V;
	public static final List<String> STATUS_LIST = List.of(CardMasterStatuses.CARD_EMBOSS_FAILED.getValue());
	public static final String CARD_PRODUCT_ID = "OPEN_MONEY";
	public static final String DEFAULT_CHANNEL = "YYY";
	public static final String DI_ENABLED = "Y";
	public static final String TRANSACTION_GROUP_ID = "1";
	public static final String EXPIRY_DATE = "3003";
	public static final String FALSE_EXPIRY_DATE = "2103";
	public static final String WRONG_EXPIRY_DATE = "21";
	public static final String REQUEST_EXPRIY_DATE = "3003";
	public static final String FALSE_REQUEST_EXPIRY_DATE = "2103";
	public static final int PIN_RETRY_COUNT = 3;
	public static final String PIN_AUTO_RESET_MODE = "A";
	public static final String PIN_MANUAL_RESET_MODE = "M";
	public static final int PIN_RESET_INTERVAL = 24;
	public static final LocalDateTime LOCAL_DATE_TIME = LocalDateTime.of(2023, 11, 16, 15, 57, 49);
	public static final LocalDateTime OLD_LOCAL_DATE_TIME = LocalDateTime.of(2022, 11, 11, 15, 57, 49);
	public static final String ACQUIRER_ID = "VISA";
	public static final String ACQUIRER_ID_ONE = "VISA";
	public static final String ACQUIRER_ID_FAIL = "MASTER";
	public static final String ISSUER_ID = "SBM_PREPAID";
	public static final String ISSUER_ID_ONE = "SBM_PREPAID";
	public static final String STAR = "*";
	public static final String MTI = "0200";
	public static final String ISSUER_ID_FAIL = "YES_PREPAID";
	public static final String ATALLA = "ATALLA";
	public static final String INSTITUTION_ID = "SBM";
	public static final String CVV1_SERVICE_CODE = "206";
	public static final String CVV2_SERVICE_CODE = "000";
	public static final String ICVV_SERVICE_CODE = "999";
	public static final String PIN_RESET_MODE = "A";
	public static final int DOM_COUNTRY_CODE = 356;
	public static final int INT_COUNTRY_CODE = 256;
	public static final String TXN_GROUP_TP_CODE = "01|00|30|31";
	public static final String TXN_GROUP_SIX_TP_CODE = "010000|000000|300000|310000";
	public static final String TXN_GROUP_TWO = "2";
	public static final String TXN_GROUP_THREE = "3";

	public static CardMaster constructSuccessCardMaster() {
		CardMaster cardMaster = new CardMaster();
		cardMaster.setProxyCardNumber(PROXY_CARD_NUMBER_PASS);
		cardMaster.setStatus("01");
		cardMaster.setCardType("P");
		cardMaster.setCountryMode("D");
		cardMaster.setDefaultChannel("YYY");
		cardMaster.setTransactionGroupId("01");
		cardMaster.setExpiryDate("3003");
		cardMaster.setPinRetryCount(3);
		cardMaster.setPinBlockedDate(LOCAL_DATE_TIME);
		cardMaster.setCardNumber(SUCCESS_CARD_NUMBER);
		cardMaster.setProgramMasterId(PROGRAM_MASTER_PASS);
		return cardMaster;
	}

	public static CardMaster constructManualCardMaster() {
		CardMaster cardMaster = new CardMaster();
		cardMaster.setProxyCardNumber(PROXY_CARD_NUMBER_PASS);
		cardMaster.setStatus("03");
		cardMaster.setCardType("P");
		cardMaster.setCountryMode("D");
		cardMaster.setDefaultChannel("YYY");
		cardMaster.setTransactionGroupId("01");
		cardMaster.setExpiryDate("3003");
		cardMaster.setPinRetryCount(3);
		cardMaster.setPinBlockedDate(LOCAL_DATE_TIME);
		cardMaster.setCardNumber(MANUAL_CARD_NUMBER);
		cardMaster.setProgramMasterId(PROGRAM_MASTER_PASS);
		return cardMaster;
	}

	public static CardMaster constructPinBlockCardMaster() {
		CardMaster cardMaster = new CardMaster();
		cardMaster.setProxyCardNumber(PROXY_CARD_NUMBER_PASS);
		cardMaster.setStatus("06");
		cardMaster.setCardType("P");
		cardMaster.setCountryMode("D");
		cardMaster.setDefaultChannel("YYY");
		cardMaster.setTransactionGroupId("01");
		cardMaster.setExpiryDate("3003");
		cardMaster.setPinRetryCount(3);
		cardMaster.setPinBlockedDate(OLD_LOCAL_DATE_TIME);
		return cardMaster;
	}

	public static CardMaster constructPinBlockTimerCardMaster() {
		CardMaster cardMaster = new CardMaster();
		cardMaster.setProxyCardNumber(PROXY_CARD_NUMBER_PASS);
		cardMaster.setStatus("06");
		cardMaster.setCardType("P");
		cardMaster.setCountryMode("D");
		cardMaster.setDefaultChannel("YYY");
		cardMaster.setTransactionGroupId("01");
		cardMaster.setExpiryDate("3003");
		cardMaster.setPinRetryCount(3);
		cardMaster.setPinBlockedDate(LOCAL_DATE_TIME);
		return cardMaster;
	}

	public static CardMaster constructFailureCardMaster() {
		CardMaster cardMaster = new CardMaster();
		cardMaster.setProxyCardNumber(PROXY_CARD_NUMBER_PASS);
		cardMaster.setStatus(CARD_PIN_BLOCKED);
		cardMaster.setCardType(PHYSCIAL_CARD_TYPE);
		cardMaster.setCountryMode(COUNTRY_MODE_D);
		cardMaster.setDefaultChannel(DEFAULT_CHANNEL);
		cardMaster.setBatchMasterId(BATCH_MASTER_ID_PASS);
		cardMaster.setVendorId(Vendor_Id);
		cardMaster.setTransactionGroupId(TRANSACTION_GROUP_ID);
		cardMaster.setExpiryDate(EXPIRY_DATE);
		cardMaster.setPinBlockedDate(LOCAL_DATE_TIME);
		cardMaster.setPinRetryCount(PIN_RETRY_COUNT);
		cardMaster.setId(CARD_MASTER_PASS);
		return cardMaster;
	}

	public static PartnerEntityRedis constructPartnerEntityRedis() {
		PartnerEntityRedis partnerEntityRedis = new PartnerEntityRedis();
		partnerEntityRedis.setPartnerEntityId(PARTNER_ID_PASS);
		return partnerEntityRedis;
	}

	public static InstitutionRedis constructInstitutionRedis() {
		InstitutionRedis institutionRedis = new InstitutionRedis();
		institutionRedis.setInstitutionId(INSTITUTION_ID_PASS);
		return institutionRedis;
	}

	public static ProgramMasterRedis constructProgramMasterRedis() {
		ProgramMasterRedis programMasterRedis = new ProgramMasterRedis();
		programMasterRedis.setProgramMasterId(PROGRAM_MASTER_ID);
		programMasterRedis.setInstitutionId(constructInstitutionRedis());
		programMasterRedis.setPartnerEntityId(constructPartnerEntityRedis());
		programMasterRedis.setIssuerBin(constructIssuerBinRedis());
		programMasterRedis.setProgramKey(PROGRAM_KEY);
		return programMasterRedis;
	}

	public static CardProductRedis constructCardProductRedis() {
		CardProductRedis cardProductRedis = new CardProductRedis();
		cardProductRedis.setCardProductId(CARD_PRODUCT_ID_PASS);
		cardProductRedis.setCardType(CardTypesEnum.P);
		cardProductRedis.setProductName(CARD_PRODUCT_ID_PASS);
		cardProductRedis.setProgramMasterId(constructProgramMasterRedis());
		cardProductRedis.setCurrencyCode("0356");
		cardProductRedis.setMarkupPercent(2);
		return cardProductRedis;
	}

	public static CardProductRedis constructBillingCardProductRedis() {
		CardProductRedis cardProductRedis = new CardProductRedis();
		cardProductRedis.setCardProductId(CARD_PRODUCT_ID_BILLING);
		cardProductRedis.setCardType(CardTypesEnum.P);
		cardProductRedis.setProductName(CARD_PRODUCT_ID_PASS);
		cardProductRedis.setProgramMasterId(constructProgramMasterRedis());
		cardProductRedis.setCurrencyCode("0840");
		cardProductRedis.setMarkupPercent(2);
		return cardProductRedis;
	}

	public static CardProductRedis constructWithoutMarkUpBillingCardProductRedis() {
		CardProductRedis cardProductRedis = new CardProductRedis();
		cardProductRedis.setCardProductId(CARD_PRODUCT_ID_BILLING);
		cardProductRedis.setCardType(CardTypesEnum.P);
		cardProductRedis.setProductName(CARD_PRODUCT_ID_PASS);
		cardProductRedis.setProgramMasterId(constructProgramMasterRedis());
		cardProductRedis.setCurrencyCode("0840");
		return cardProductRedis;
	}

	public static IssuerBinRedis constructIssuerBinRedis() {
		IssuerBinRedis issuerBinRedis = new IssuerBinRedis();
		issuerBinRedis.setIssuerBin(ISSUER_BIN_PASS);
		return issuerBinRedis;
	}

	public static CardDesignRedis constructCardDesignRedis() {
		CardDesignRedis cardDesignRedis = new CardDesignRedis();
		cardDesignRedis.setCardDesignId(CARD_DESIGN_ID_PASS);
		cardDesignRedis.setPartnerEntityId(constructPartnerEntityRedis());
		cardDesignRedis.setIssuerBin(constructIssuerBinRedis());
		return cardDesignRedis;
	}

	public static KeyMapperRedis constructDynamicKeyMapper() throws Exception {
		KeyMapperRedis keyMapperRedis = new KeyMapperRedis();
		keyMapperRedis.setKeyRuleId(KEY_MAPPER_STATIC);
		String keys = "{\"CARD_PROD\": \"cardProductId\",\"BATCH_NO\": \"batchNo\",\"COUNT\": \"count\",\"BATCH_ID\":\"batchId\",\n"
				+ "\"CARD_DESIGN_ID\": \"cardDesignId\",\"INSTITUTIONID\": \"institutionId\",\"PARTNERID\":\"partnerEntityId\",\n"
				+ "\"ISSUERBIN\":\"issuerBin\",\"CRDTYPEID\":\"cardTypeId\"}";
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, String> keyMap = objectMapper.readValue(keys, new TypeReference<Map<String, String>>() {
		});
		keyMapperRedis.setKeys(keyMap);
		return keyMapperRedis;
	}

	public static KeyMapperRedis constructStaticKeyMapper() throws Exception {
		KeyMapperRedis keyMapperRedis = new KeyMapperRedis();
		keyMapperRedis.setKeyRuleId(KEY_MAPPER_STATIC);
		String keys = "{\"US\":\"_\"}";
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, String> keyMap = objectMapper.readValue(keys, new TypeReference<Map<String, String>>() {
		});
		keyMapperRedis.setKeys(keyMap);
		return keyMapperRedis;
	}

	public static VendorMasterRedis constructVendorMasterRedis() {
		VendorMasterRedis vendorMasterRedis = new VendorMasterRedis();
		vendorMasterRedis.setVendorId(Helper.VENDOR_MASTER_ID_PASS);
		return vendorMasterRedis;
	}

//	public static DataSequenceMaster constructDataSequenceMaster() {
//		DataSequenceMaster dataSequenceMaster = new DataSequenceMaster();
//		dataSequenceMaster.setDataSequenceId(constructDataSequenceIdPass());
//		dataSequenceMaster.setCurrentSeq(1L);
//		dataSequenceMaster.setMaxSeq(9999999L);
//		dataSequenceMaster.setStartSeq(0L);
//		return dataSequenceMaster;
//	}
//
//	public static DataSequenceId constructDataSequenceIdPass() {
//		return new DataSequenceId(PARTNER_ID_PASS, "CARD", ISSUER_BIN_PASS);
//	}

	public static LimitMaster constructLimitMaster() {
		LimitMaster limitMaster = new LimitMaster();
		limitMaster.setEntityId(LIMIT_ENTITY_ID);
		limitMaster.setChannel(ATM);
		limitMaster.setTpCode(TP_CODE_01);
		limitMaster.setPkey(LIMIT_ID_PASS);
		limitMaster.setCountryMode(COUNTRY_MODE_D);
		return limitMaster;
	}

	public static CardMasterDto constructCardMasterDto() {
		CardMasterDto cardMasterDto = new CardMasterDto();
		cardMasterDto.setProgramMasterId(PROGRAM_MASTER_PASS);
		cardMasterDto.setProxyCardNumber(PROXY_CARD_NUMBER_PASS);
		cardMasterDto.setStatus(CARD_PIN_BLOCKED);
		cardMasterDto.setCardType(PHYSCIAL_CARD_TYPE);
		cardMasterDto.setCountryMode(COUNTRY_MODE_D);
		cardMasterDto.setDefaultChannel(DEFAULT_CHANNEL);
		cardMasterDto.setTransactionGroupId(TRANSACTION_GROUP_ID);
		cardMasterDto.setExpiryDate(EXPIRY_DATE);
		cardMasterDto.setPinRetryCount(PIN_RETRY_COUNT);
		return cardMasterDto;
	}

	public static CardMasterDto constructFailureCardMasterDto() {
		CardMasterDto cardMasterDto = new CardMasterDto();
		cardMasterDto.setProgramMasterId(PROGRAM_MASTER_PASS);
		cardMasterDto.setProxyCardNumber(PROXY_CARD_NUMBER_PASS);
		cardMasterDto.setCardNumber(SUCCESS_CARD_NUMBER);
		return cardMasterDto;
	}

	public static List<LimitMasterDto> listLimitMasterDto() {
		List<LimitMasterDto> listLimitMaster = new ArrayList<>();
		LimitMasterDto limitMaster = new LimitMasterDto();
		limitMaster.setEntityId(LIMIT_ENTITY_ID);
		limitMaster.setChannel(ATM);
		limitMaster.setTpCode(TP_CODE_01);
		limitMaster.setPkey(LIMIT_ID_PASS);
		limitMaster.setCountryMode(COUNTRY_MODE_D);
		LimitMasterDto limitMasterSecond = new LimitMasterDto();
		limitMasterSecond.setEntityId(LIMIT_ENTITY_ID);
		limitMasterSecond.setChannel(POS);
		limitMasterSecond.setTpCode(TP_CODE_00);
		limitMasterSecond.setPkey(LIMIT_ID_PASS);
		limitMasterSecond.setCountryMode(COUNTRY_MODE_D);

		listLimitMaster.add(limitMaster);
		listLimitMaster.add(limitMasterSecond);
		return listLimitMaster;
	}

	public static List<NetworkSelectRedis> loadAllStarNetworkSelectData() {
		List<NetworkSelectRedis> networkSelectListData = new ArrayList<>();
		NetworkSelectRedis networkSelectData = new NetworkSelectRedis();
		networkSelectData.setNetworkId(NETWORK_KEY_ID);
		networkSelectData.setAcquirerId(ACQUIRER_ID);
		networkSelectData.setCardProduct(STAR);
		networkSelectData.setChannelType(STAR);
		networkSelectData.setIssuerId(ISSUER_ID);
		networkSelectData.setMti(STAR);
		networkSelectData.setTpCode(STAR);
		networkSelectListData.add(networkSelectData);
		NetworkSelectRedis networkSelectData1 = new NetworkSelectRedis();
		networkSelectData1.setNetworkId(NETWORK_KEY_ID);
		networkSelectData1.setAcquirerId(ACQUIRER_ID);
		networkSelectData1.setCardProduct(STAR);
		networkSelectData1.setChannelType(ATM);
		networkSelectData1.setIssuerId(ISSUER_ID);
		networkSelectData1.setMti(STAR);
		networkSelectData1.setTpCode(STAR);
		networkSelectListData.add(networkSelectData);
		return networkSelectListData;

	}

	public static List<NetworkSelectRedis> loadListNetworkSelectData() {
		List<NetworkSelectRedis> networkSelectListData = new ArrayList<>();
		NetworkSelectRedis networkSelectData = new NetworkSelectRedis();
		networkSelectData.setNetworkId(NETWORK_KEY_ID);
		networkSelectData.setAcquirerId(ACQUIRER_ID);
		networkSelectData.setCardProduct("*");
		networkSelectData.setChannelType(ATM);
		networkSelectData.setIssuerId(ISSUER_ID);
		networkSelectData.setMti("0200");
		networkSelectData.setTpCode("*");
		NetworkSelectRedis networkSelectData1 = new NetworkSelectRedis();
		networkSelectData1.setNetworkId(NETWORK_KEY_ID);
		networkSelectData1.setAcquirerId(ACQUIRER_ID);
		networkSelectData1.setCardProduct("*");
		networkSelectData1.setChannelType(ATM);
		networkSelectData1.setIssuerId(ISSUER_ID);
		networkSelectData1.setMti("0100");
		networkSelectData1.setTpCode("*");
		networkSelectListData.add(networkSelectData);
		return networkSelectListData;
	}

	public static NetworkSelectRedis loadNetworkSelectWithData() {
		NetworkSelectRedis networkSelectData1 = new NetworkSelectRedis();
		networkSelectData1.setTpCode(TP_CODE_00);
		networkSelectData1.setCardProduct(CARD_PRODUCT_ID_PASS);
		networkSelectData1.setChannelType(ATM);
		networkSelectData1.setMti(MTI);
		networkSelectData1.setNetworkId(NETWORK_KEY_ID);
		networkSelectData1.setIssuerId(ISSUER_ID);
		return networkSelectData1;
	}

	public static NetworkSelectRedis loadNetworkSelectSingleDigitWithData() {
		NetworkSelectRedis networkSelectData1 = new NetworkSelectRedis();
		networkSelectData1.setTpCode("1");
		networkSelectData1.setCardProduct(CARD_PRODUCT_ID_PASS);
		networkSelectData1.setChannelType(ATM);
		networkSelectData1.setMti(MTI);
		networkSelectData1.setNetworkId(NETWORK_KEY_ID);
		networkSelectData1.setIssuerId(ISSUER_ID);
		return networkSelectData1;
	}

	public static NetworkSelectRedis loadNetworkSelectLongDigitWithData() {
		NetworkSelectRedis networkSelectData1 = new NetworkSelectRedis();
		networkSelectData1.setTpCode("010000");
		networkSelectData1.setCardProduct(CARD_PRODUCT_ID_PASS);
		networkSelectData1.setChannelType(ATM);
		networkSelectData1.setMti(MTI);
		networkSelectData1.setNetworkId(NETWORK_KEY_ID);
		networkSelectData1.setIssuerId(ISSUER_ID);
		return networkSelectData1;
	}

	public static NetworkSelectRedis loadNetworkSelectAllStarData() {
		NetworkSelectRedis networkSelectData1 = new NetworkSelectRedis();
		networkSelectData1.setTpCode(STAR);
		networkSelectData1.setCardProduct(STAR);
		networkSelectData1.setChannelType(STAR);
		networkSelectData1.setMti(STAR);
		networkSelectData1.setNetworkId(NETWORK_KEY_ID);
		networkSelectData1.setIssuerId(STAR);
		return networkSelectData1;
	}

	public static NetworkSelectRedis loadNetworkSelectCardProductStarData() {
		NetworkSelectRedis networkSelectData1 = new NetworkSelectRedis();
		networkSelectData1.setTpCode(TP_CODE_01);
		networkSelectData1.setCardProduct(STAR);
		networkSelectData1.setChannelType(ATM);
		networkSelectData1.setMti(MTI);
		networkSelectData1.setNetworkId(NETWORK_KEY_ID);
		networkSelectData1.setIssuerId(ISSUER_ID);
		return networkSelectData1;
	}

	public static TransactionRequestDto loadTransactionRequestDto() {
		TransactionRequestDto transactionRequestDto = new TransactionRequestDto();
		transactionRequestDto.setAcquirerId(Helper.ACQUIRER_ID);
		transactionRequestDto.setCardProduct(Helper.CARD_PRODUCT_ID_PASS);
		transactionRequestDto.setChannelType(ATM);
		transactionRequestDto.setMti(MTI);
		transactionRequestDto.setTpCode(TP_CODE_01);
		return transactionRequestDto;
	}

	public static TransactionRequestDto loadAcqFailTransactionRequestDto() {
		TransactionRequestDto transactionRequestDto = new TransactionRequestDto();
		transactionRequestDto.setAcquirerId(Helper.ACQUIRER_ID_ONE);
		transactionRequestDto.setCardProduct(Helper.CARD_PRODUCT_ID_PASS);
		transactionRequestDto.setChannelType(ATM);
		transactionRequestDto.setMti(MTI);
		transactionRequestDto.setTpCode(TP_CODE_01);
		return transactionRequestDto;
	}

	public static TransactionRequestDto loadCardProductDummyTransactionRequestDto() {
		TransactionRequestDto transactionRequestDto = new TransactionRequestDto();
		transactionRequestDto.setAcquirerId(Helper.ACQUIRER_ID);
		transactionRequestDto.setChannelType(ATM);
		transactionRequestDto.setMti(MTI);
		transactionRequestDto.setTpCode(TP_CODE_01);
		transactionRequestDto.setProxyCardNumber(PROXY_CARD_NUMBER_PASS);
		transactionRequestDto.setCardNumber(SUCCESS_CARD_NUMBER);
		transactionRequestDto.setHashedPan(SUCCESS_CARD_NUMBER);
		transactionRequestDto.setPinResetMode("A");
		transactionRequestDto.setPinResetInterval(24);
		return transactionRequestDto;
	}

	public static TransactionRequestDto loadNoCardProductDummyTransactionRequestDto() {
		TransactionRequestDto transactionRequestDto = new TransactionRequestDto();
		transactionRequestDto.setAcquirerId(Helper.ACQUIRER_ID);
		transactionRequestDto.setCardProduct(CARD_PRODUCT_ID_FAIL);
		transactionRequestDto.setChannelType(ATM);
		transactionRequestDto.setMti(MTI);
		transactionRequestDto.setTpCode(TP_CODE_01);
		transactionRequestDto.setHashedPan(FAILURE_CARD_NUMBER);
		return transactionRequestDto;
	}

	public static TransactionRequestDto issuerBinTranasctionRequestDto() {
		TransactionRequestDto transactionRequestDto = new TransactionRequestDto();
		transactionRequestDto.setIssuerBin(ISSUER_BIN_PASS);
		transactionRequestDto.setCardNumber(CLEAR_CARD_NUMBER);
		transactionRequestDto.setHashedPan(MANUAL_CARD_NUMBER);
		return transactionRequestDto;
	}

	public static TransactionRequestDto issuerBinFailTranasctionRequestDto() {
		TransactionRequestDto transactionRequestDto = new TransactionRequestDto();
		transactionRequestDto.setIssuerBin("asd");
		transactionRequestDto.setCardNumber(CLEAR_CARD_NUMBER);
		return transactionRequestDto;
	}

	public static TransactionRequestDto issuerTranasctionRequestDto() {
		TransactionRequestDto transactionRequestDto = new TransactionRequestDto();
		transactionRequestDto.setIssuerBin(ISSUER_BIN_FINAL);
		transactionRequestDto.setCardNumber(CLEAR_CARD_NUMBER);
		return transactionRequestDto;
	}

	public static InstitutionRedis institutionRedisLoad() {
		InstitutionRedis institutionRedisLoad = new InstitutionRedis();
		institutionRedisLoad.setPrimaryHsmId(ATALLA);
		institutionRedisLoad.setMaxPinCount(PIN_RETRY_COUNT);
		institutionRedisLoad.setCountryCode(356);
		return institutionRedisLoad;
	}

	public static InstitutionRedis institutionCountryRedisLoad() {
		InstitutionRedis institutionRedisLoad = new InstitutionRedis();
		institutionRedisLoad.setPrimaryHsmId(ATALLA);
		institutionRedisLoad.setMaxPinCount(PIN_RETRY_COUNT);
		institutionRedisLoad.setCountryCode(256);
		return institutionRedisLoad;
	}

	public static IssuerBinRedis issuerBinSuccessRedisLoad() {
		IssuerBinRedis issuerBinLoad = new IssuerBinRedis();
		issuerBinLoad.setInstitutionId(Helper.institutionRedisLoad());
		issuerBinLoad.setIssuerBin(ISSUER_BIN_PASS);
		issuerBinLoad.setCvv1ServiceCode(CVV1_SERVICE_CODE);
		issuerBinLoad.setCvv2ServiceCode(CVV2_SERVICE_CODE);
		issuerBinLoad.setIcvvServiceCode(ICVV_SERVICE_CODE);
		issuerBinLoad.setPinResetMode(PIN_AUTO_RESET_MODE);
		issuerBinLoad.setPinResetPeriod(PIN_RESET_INTERVAL);
		return issuerBinLoad;
	}

	public static IssuerBinRedis issuerBinRedisLoad() {
		IssuerBinRedis issuerBinLoad = new IssuerBinRedis();
		issuerBinLoad.setInstitutionId(Helper.institutionRedisLoad());
		issuerBinLoad.setIssuerBin(ISSUER_BIN_FINAL);
		issuerBinLoad.setCvv1ServiceCode(CVV1_SERVICE_CODE);
		issuerBinLoad.setCvv2ServiceCode(CVV2_SERVICE_CODE);
		issuerBinLoad.setIcvvServiceCode(ICVV_SERVICE_CODE);
		issuerBinLoad.setPinResetMode(PIN_AUTO_RESET_MODE);
		issuerBinLoad.setPinResetPeriod(PIN_RESET_INTERVAL);
		return issuerBinLoad;
	}

	public static List<IssuerBinRedis> issuerBinFailureRedisLoad() {
		List<IssuerBinRedis> issuerBinLoad = new ArrayList<>();
		IssuerBinRedis issuerBinLoad1 = new IssuerBinRedis();
		issuerBinLoad1.setInstitutionId(Helper.institutionRedisLoad());
		issuerBinLoad1.setIssuerBin(ISSUER_BIN_FINAL);
		issuerBinLoad1.setCvv1ServiceCode(CVV1_SERVICE_CODE);
		issuerBinLoad1.setCvv2ServiceCode(CVV2_SERVICE_CODE);
		issuerBinLoad1.setIcvvServiceCode(ICVV_SERVICE_CODE);
		issuerBinLoad1.setPinResetMode(PIN_AUTO_RESET_MODE);
		issuerBinLoad1.setPinResetPeriod(PIN_RESET_INTERVAL);
		IssuerBinRedis issuerBinLoad2 = new IssuerBinRedis();
		issuerBinLoad2.setInstitutionId(Helper.institutionRedisLoad());
		issuerBinLoad2.setIssuerBin("123433");
		issuerBinLoad2.setCvv1ServiceCode(CVV1_SERVICE_CODE);
		issuerBinLoad2.setCvv2ServiceCode(CVV2_SERVICE_CODE);
		issuerBinLoad2.setIcvvServiceCode(ICVV_SERVICE_CODE);
		issuerBinLoad2.setPinResetMode(PIN_AUTO_RESET_MODE);
		issuerBinLoad2.setPinResetPeriod(PIN_RESET_INTERVAL);
		issuerBinLoad.add(issuerBinLoad2);
		issuerBinLoad.add(issuerBinLoad1);
		return issuerBinLoad;
	}

	public static List<IssuerSelectRedis> issuerSelectRedis() {
		List<IssuerSelectRedis> issuerSelectRedis = new ArrayList<>();
		IssuerSelectRedis issuerSelectRedis1 = new IssuerSelectRedis();
		issuerSelectRedis1.setIssuerSelectId(ISSUER_ID);
		issuerSelectRedis1.setChannelType(ATM);
		issuerSelectRedis1.setIssuerBin(ISSUER_BIN_PASS);
		issuerSelectRedis.add(issuerSelectRedis1);
		return issuerSelectRedis;
	}

	public static List<IssuerSelectRedis> issuerListSelectRedis() {
		List<IssuerSelectRedis> issuerSelectRedis = new ArrayList<>();
		IssuerSelectRedis issuerSelectRedis1 = new IssuerSelectRedis();
		issuerSelectRedis1.setIssuerSelectId(ISSUER_ID);
		issuerSelectRedis1.setChannelType(STAR);
		issuerSelectRedis1.setIssuerBin(ISSUER_BIN_FAIL);
		issuerSelectRedis.add(issuerSelectRedis1);
		return issuerSelectRedis;
	}

	public static TransactionGroupRedis transactionGroupRedis() {
		TransactionGroupRedis transactionGroupRedis = new TransactionGroupRedis();
		transactionGroupRedis.setTransactionGroupId(TRANSACTION_GROUP_ID);
		transactionGroupRedis.setTransactionCode(TXN_GROUP_TP_CODE);
		transactionGroupRedis.setStatus("Y");
		return transactionGroupRedis;
	}

	public static TransactionGroupRedis transactionGroupTwoRedis() {
		TransactionGroupRedis transactionGroupRedis = new TransactionGroupRedis();
		transactionGroupRedis.setTransactionGroupId(TXN_GROUP_TWO);
		transactionGroupRedis.setTransactionCode(TXN_GROUP_TP_CODE);
		transactionGroupRedis.setStatus("N");
		return transactionGroupRedis;
	}

	public static TransactionGroupRedis transactionGroupThreeRedis() {
		TransactionGroupRedis transactionGroupRedis = new TransactionGroupRedis();
		transactionGroupRedis.setTransactionGroupId(TXN_GROUP_THREE);
		transactionGroupRedis.setTransactionCode("");
		transactionGroupRedis.setStatus("Y");
		return transactionGroupRedis;
	}

	public static TransactionRequestDto programMasterTransactionGroupRequestDto() {
		TransactionRequestDto programMasterTransactionRequestDto = new TransactionRequestDto();
		programMasterTransactionRequestDto.setPartnerEntityId(PARTNER_ID_PASS);
		programMasterTransactionRequestDto.setInstitutionId(INSTITUTION_ID_PASS);
		return programMasterTransactionRequestDto;
	}

}
