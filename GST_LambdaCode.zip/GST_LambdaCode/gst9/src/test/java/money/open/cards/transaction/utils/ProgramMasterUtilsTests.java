package money.open.cards.transaction.utils;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import money.open.cards.transaction.helper.Helper;
import money.open.cards.transaction.redis.dao.ProgramMasterRedisDao;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ProgramMasterUtilsTests {

	@InjectMocks
	ProgramMasterUtils programMasterUtils;

	@Mock
	private ProgramMasterRedisDao programMasterRedisDao;

	@BeforeEach
	public void beforeEach() throws Exception {
		Mockito.when(programMasterRedisDao.findById(Helper.PROGRAM_MASTER_ID))
				.thenReturn(Optional.of(Helper.constructProgramMasterRedis()));
	}

	@Test
	@DisplayName("Program Master Utils Tests")
	void programMasterUtilsTests() {
		assertNotNull(
				programMasterUtils.setPartnerAndInst(Helper.issuerTranasctionRequestDto(), Helper.PROGRAM_MASTER_ID));
		assertNotNull(programMasterUtils.setPartnerAndInst(Helper.issuerTranasctionRequestDto(), 1L));
	}

}
