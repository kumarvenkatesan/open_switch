package money.open.cards.transaction.utils;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import money.open.cards.transaction.helper.Helper;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class FrameResponseCodeUtilsTests {

	@InjectMocks
	FrameResponseCodeUtils frameResponseCode;

	@ParameterizedTest
	@DisplayName("Frame Response Code Utils Tests")
	@ValueSource(strings = { Helper.MTI, "11" })
	void frameResponseCodeUtilsTests(String mti) {

		assertEquals(null, frameResponseCode.frameResponseCode(null));
		assertEquals("", frameResponseCode.frameResponseCode(""));
		assertNotNull(frameResponseCode.frameResponseCode(mti));
	}

}
