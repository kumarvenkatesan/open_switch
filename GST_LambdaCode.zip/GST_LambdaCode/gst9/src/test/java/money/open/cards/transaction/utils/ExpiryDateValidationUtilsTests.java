package money.open.cards.transaction.utils;

import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import money.open.cards.transaction.helper.Helper;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ExpiryDateValidationUtilsTests {

	@InjectMocks
	ExpiryDateValidationUtils expriyDateValidationUtils;

	@Test
	@DisplayName("Expriy Date Validation Tests")
	void expriyDateValidationUtilsTests() {

		assertTrue(expriyDateValidationUtils.expiryDateValidation(Helper.EXPIRY_DATE, Helper.REQUEST_EXPRIY_DATE));
		assertFalse(
				expriyDateValidationUtils.expiryDateValidation(Helper.FALSE_EXPIRY_DATE, Helper.REQUEST_EXPRIY_DATE));
		assertFalse(expriyDateValidationUtils.expiryDateValidation(Helper.FALSE_EXPIRY_DATE, Helper.FALSE_EXPIRY_DATE));
		assertFalse(expriyDateValidationUtils.expiryDateValidation(Helper.WRONG_EXPIRY_DATE, Helper.WRONG_EXPIRY_DATE));

	}

}
