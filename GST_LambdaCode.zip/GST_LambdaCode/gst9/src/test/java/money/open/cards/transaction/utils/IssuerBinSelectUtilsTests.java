package money.open.cards.transaction.utils;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import money.open.cards.transaction.helper.Helper;
import money.open.cards.transaction.redis.dao.IssuerBinRedisDao;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class IssuerBinSelectUtilsTests {

	@InjectMocks
	IssuerBinSelectUtils issuerBinSelectUtils;

	@Mock
	private IssuerBinRedisDao issuerBinRedisDao;

	@BeforeEach
	public void beforeEach() throws Exception {
		Mockito.when(issuerBinRedisDao.findByIssuerBin(Helper.ISSUER_BIN_PASS))
				.thenReturn(Helper.issuerBinSuccessRedisLoad());

		Mockito.when(issuerBinRedisDao.findByIssuerBin(Helper.ISSUER_BIN_FAIL)).thenReturn(null);

		Mockito.when(issuerBinRedisDao.findAll()).thenReturn(Helper.issuerBinFailureRedisLoad());

		Mockito.when(issuerBinRedisDao.findByIssuerBin(Helper.ISSUER_BIN_FINAL))
				.thenReturn(Helper.issuerBinRedisLoad());

	}

	@Test
	@DisplayName("Issuer Bin Redis Tests")
	void issuerBinSelectUtilsTests() {

		assertNull(issuerBinSelectUtils.issuerBinSelect(Helper.loadCardProductDummyTransactionRequestDto()));
		assertNotNull(issuerBinSelectUtils.issuerBinSelect(Helper.issuerBinFailTranasctionRequestDto()));

		assertNotNull(issuerBinSelectUtils.issuerBinSelect(Helper.issuerTranasctionRequestDto()));

	}
}
