package money.open.cards.transaction;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.TestConfiguration;

@TestConfiguration
class SwitchTransactionApplicationTests {

	@Test
	void demoTestMethod() {
		assertTrue(true);
	}
}
