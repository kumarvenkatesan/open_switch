package money.open.cards.transaction.utils;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class DuaInterfaceValidationUtilsTests {

	@InjectMocks
	DualInterfaceValidationUtils dualInterfaceValidationUtils;

	@Test
	@DisplayName("Dual Interface Validation Tests")
	void dualInterfaceValidationTests() {
		assertTrue(dualInterfaceValidationUtils.validateDiEnabled("Y", true));
		assertFalse(dualInterfaceValidationUtils.validateDiEnabled("N", false));
	}
}
