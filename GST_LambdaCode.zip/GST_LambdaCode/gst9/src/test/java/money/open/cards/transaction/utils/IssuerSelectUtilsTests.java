package money.open.cards.transaction.utils;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import money.open.cards.transaction.helper.Helper;
import money.open.cards.transaction.redis.dao.IssuerSelectRedisDao;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class IssuerSelectUtilsTests {

	@InjectMocks
	IssuerSelectUtils issuerSelectUtils;

	@Mock
	private IssuerSelectRedisDao issuerSelectRedisDao;

	@BeforeEach
	public void beforeEach() throws Exception {
		Mockito.when(issuerSelectRedisDao.findByIssuerBinAndChannelType(Helper.ISSUER_BIN_PASS, Helper.ATM))
				.thenReturn(Helper.issuerSelectRedis());
		Mockito.when(issuerSelectRedisDao.findByIssuerBinAndChannelType(Helper.ISSUER_BIN_FAIL, Helper.POS))
				.thenReturn(null);
		Mockito.when(issuerSelectRedisDao.findByIssuerBinAndChannelType(Helper.ISSUER_BIN_FINAL, Helper.STAR))
				.thenReturn(Helper.issuerListSelectRedis());

	}

	@Test
	@DisplayName("Issuer Bin Redis Tests")
	void issuerBinSelectUtilsTests() {
		assertNull(issuerSelectUtils.issuerSelectRedisData("ABC", null));
		assertNotNull(issuerSelectUtils.issuerSelectRedisData(Helper.ISSUER_BIN_PASS, Helper.ATM));
		assertNotNull(issuerSelectUtils.issuerSelectRedisData(Helper.ISSUER_BIN_FAIL, "ABC"));
		Mockito.when(issuerSelectRedisDao.findByIssuerBinAndChannelType(Helper.ISSUER_BIN_FINAL, Helper.STAR))
				.thenReturn(List.of());
		assertNull(issuerSelectUtils.issuerSelectRedisData(Helper.ISSUER_BIN_FAIL, "ABC"));

	}
}
