ALTER TABLE card_master RENAME COLUMN customer_master_id TO customer_id;
ALTER TABLE card_master ALTER COLUMN customer_id TYPE varchar USING customer_id::varchar;