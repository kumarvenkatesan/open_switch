-- limit_master_seq definition

-- DROP SEQUENCE limit_master_seq;

CREATE SEQUENCE limit_master_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;
	
	
-- accum_master_seq definition

-- DROP SEQUENCE accum_master_seq;

CREATE SEQUENCE accum_master_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;	
	
	
-- limit_master definition

-- Drop table

-- DROP TABLE limit_master;

CREATE TABLE limit_master (
	limit_config_id varchar(15) NOT NULL,
	partner_entity_id varchar(12) NOT NULL,
	entity_id varchar(32) NOT NULL,
	entity_type varchar(16) NOT NULL,
	country_mode varchar(1) NOT NULL,
	tp_code varchar(6) NOT NULL,
	daily_limit numeric(26, 4) NOT NULL,
	daily_count int8 NOT NULL,
	monthly_limit numeric(26, 4) NOT NULL,
	monthly_count int8 NOT NULL,
	channel varchar(32) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	pkey int8 NOT NULL DEFAULT nextval('limit_master_seq'::regclass),
	CONSTRAINT limit_master_pk PRIMARY KEY (pkey)
);	


-- accum_master definition

-- Drop table

-- DROP TABLE accum_master;

CREATE TABLE accum_master (
	limit_config_id varchar(15) NOT NULL,
	partner_entity_id varchar(12) NOT NULL,
	entity_id varchar(32) NOT NULL,
	entity_type varchar(16) NOT NULL,
	country_mode varchar(1) NOT NULL,
	tp_code varchar(6) NOT NULL,
	daily_limit numeric(26, 4) NOT NULL,
	daily_count int8 NOT NULL,
	monthly_limit numeric(26, 4) NOT NULL,
	monthly_count int8 NOT NULL,
	channel varchar(32) NOT NULL,
	last_transaction_date date NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	pkey int8 NOT NULL DEFAULT nextval('accum_master_seq'::regclass),
	CONSTRAINT accum_master_pk PRIMARY KEY (pkey)
);	