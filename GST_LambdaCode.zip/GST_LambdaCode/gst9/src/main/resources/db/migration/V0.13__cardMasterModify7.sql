ALTER TABLE card_master ALTER COLUMN pin_offset DROP NOT NULL;
ALTER TABLE card_master ALTER COLUMN old_pin_offset DROP NOT NULL;