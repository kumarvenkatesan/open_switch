ALTER TABLE transaction_master ADD txn_identifier varchar NULL;
