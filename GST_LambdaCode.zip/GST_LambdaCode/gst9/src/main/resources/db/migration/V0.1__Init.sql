CREATE SEQUENCE card_master_seq
   INCREMENT BY 1
   MINVALUE 1
   MAXVALUE 9223372036854775807
   START 1
   CACHE 1
   NO CYCLE;
   

-- card_master definition

-- Drop table

-- DROP TABLE card_master;

CREATE TABLE card_master (
	card_master_id int8 NOT NULL DEFAULT nextval('card_master_seq'::regclass),
	program_master_id int8 NOT NULL,
	card_product_id varchar(16) NOT NULL,
	issuer_bin varchar(12) NOT NULL,
	card_number varchar(128) NOT NULL,
	proxy_card_number varchar(32) NOT NULL,
	mask_card_number varchar(20) NOT NULL,
	order_ref_no varchar(32) NOT NULL,
	status varchar(2) NOT NULL,
	card_type varchar(1) NOT NULL,
	country_mode varchar(1) NOT NULL,
	default_channel varchar(3) NOT NULL,
	di_enabled varchar(1) NOT NULL,
	transaction_group_id varchar(15) NOT NULL,
	card_seq_no varchar(2) NOT NULL,
	pin_offset varchar(12) NOT NULL,
	old_pin_offset varchar(12) NOT NULL,
	display_name varchar(50) NOT NULL,
	activation_date date NULL,
	expiry_date date NULL,
	addon_status varchar(1) NOT NULL,
	mobile_number varchar(20) NOT NULL,
	email varchar(100) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	customer_master_id int8 NULL,
	vendor_id varchar(32) NULL,
	card_design_id varchar(32) NULL,
	delivery_address varchar(32) NULL,
	card_variant varchar(4) NOT NULL,
	batch_master_id varchar(32) NULL,
	limit_config_type varchar(15) NOT NULL DEFAULT 'default'::character varying,
	CONSTRAINT card_master_card_number_key UNIQUE (card_number),
	CONSTRAINT card_master_pkey PRIMARY KEY (card_master_id),
	CONSTRAINT card_master_proxy_card_number_key UNIQUE (proxy_card_number)
);

-- institution definition

-- Drop table

-- DROP TABLE institution;

CREATE TABLE institution (
	institution_id varchar(12) NOT NULL,
	institution_code varchar(12) NOT NULL,
	institution_name varchar(45) NOT NULL,
	institution_type varchar(3) NOT NULL,
	base_currency_code varchar(3) NOT NULL,
	alpha_currency_code varchar(3) NOT NULL,
	alpha_2_country_code varchar(2) NOT NULL,
	alpha_3_country_code varchar(3) NOT NULL,
	country_code varchar(3) NOT NULL,
	primary_bin varchar(12) NOT NULL,
	external_id varchar(12) NOT NULL,
	external_id_desc varchar(45) NOT NULL,
	pci_vault_id varchar(12) NOT NULL,
	max_pin_count int4 NOT NULL,
	primary_hsm_id varchar(11) NOT NULL,
	fallback_hsm_id varchar(11) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT institution_pkey PRIMARY KEY (institution_id)
);

-- issuer_bin definition

-- Drop table

-- DROP TABLE issuer_bin;

CREATE TABLE issuer_bin (
	issuer_bin varchar(12) NOT NULL,
	institution_id varchar(12) NOT NULL,
	bin_desc varchar(45) NULL DEFAULT NULL::character varying,
	bin_type varchar(12) NOT NULL,
	status varchar(1) NOT NULL,
	card_scheme varchar(12) NOT NULL,
	issuer_key_id varchar(20) NOT NULL,
	cms_flag varchar(1) NOT NULL,
	auth_flag varchar(4) NOT NULL,
	tfa_flag varchar(1) NOT NULL,
	card_len int4 NOT NULL,
	pin_len int4 NOT NULL,
	cvv1_service_code varchar(3) NOT NULL,
	cvv1_fdate varchar(4) NOT NULL,
	cvv2_service_code varchar(3) NOT NULL,
	cvv2_fdate varchar(4) NOT NULL,
	icvv_service_code varchar(3) NOT NULL,
	icvv_fdate varchar(4) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT auth_flag_chk CHECK (((auth_flag)::text = ANY ((ARRAY['Y'::character varying, 'P'::character varying])::text[]))),
	CONSTRAINT bin_type_chk CHECK (((bin_type)::text = ANY (ARRAY[('PREPAID'::character varying)::text, ('CREDIT'::character varying)::text, ('DEBIT'::character varying)::text]))),
	CONSTRAINT card_len_chk CHECK ((card_len = ANY (ARRAY[16, 19]))),
	CONSTRAINT card_scheme_chk CHECK (((card_scheme)::text = ANY (ARRAY[('VISA'::character varying)::text, ('MASTERCARD'::character varying)::text, ('RUPAY'::character varying)::text, ('CUP'::character varying)::text]))),
	CONSTRAINT cms_flag_chk CHECK (((cms_flag)::text = ANY ((ARRAY['Y'::character varying, 'N'::character varying])::text[]))),
	CONSTRAINT cvv1_fdate_chk CHECK (((cvv1_fdate)::text = ANY ((ARRAY['YYMM'::character varying, 'MMYY'::character varying])::text[]))),
	CONSTRAINT cvv2_fdate_chk CHECK (((cvv2_fdate)::text = ANY (ARRAY[('YYMM'::character varying)::text, ('MMYY'::character varying)::text]))),
	CONSTRAINT icvv_fdate_chk CHECK (((icvv_fdate)::text = ANY (ARRAY[('YYMM'::character varying)::text, ('MMYY'::character varying)::text]))),
	CONSTRAINT issuer_bin_pkey PRIMARY KEY (issuer_bin),
	CONSTRAINT pin_len_chk CHECK (((pin_len >= 4) AND (pin_len <= 12))),
	CONSTRAINT status_chk CHECK (((status)::text = ANY ((ARRAY['0'::character varying, '1'::character varying, '2'::character varying])::text[]))),
	CONSTRAINT tfa_flag_chk CHECK (((tfa_flag)::text = ANY ((ARRAY['Y'::character varying, 'N'::character varying])::text[]))),
	CONSTRAINT fk_issuer_bin FOREIGN KEY (institution_id) REFERENCES institution(institution_id)
);

-- issuer_select definition

-- Drop table

-- DROP TABLE issuer_select;

CREATE TABLE issuer_select (
	issuer_select_id varchar(255) NOT NULL,
	channel_type varchar(255) NULL,
	description varchar(255) NULL,
	from_offset varchar(255) NULL,
	imf_data varchar(255) NULL,
	imf_value varchar(255) NULL,
	issuer_bin varchar(255) NULL,
	to_offset varchar(255) NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT issuer_select_pkey PRIMARY KEY (issuer_select_id)
);

-- network_master definition

-- Drop table

-- DROP TABLE network_master;

CREATE TABLE network_master (
	network_id varchar(12) NOT NULL,
	business_date date NOT NULL,
	cut_over_flag varchar(1) NOT NULL,
	echo_flag varchar(1) NOT NULL,
	echo_interval int4 NOT NULL,
	end_point varchar(128) NOT NULL,
	end_point_type varchar(45) NOT NULL,
	key_exchg_flag varchar(1) NOT NULL,
	network_key_id varchar(12) NOT NULL,
	network_name varchar(45) NOT NULL,
	network_type varchar(1) NOT NULL,
	signon_flag varchar(1) NOT NULL,
	timeout_action varchar(1) NOT NULL,
	timeout_period int4 NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT network_master_pkey PRIMARY KEY (network_id)
);

-- network_select definition

-- Drop table

-- DROP TABLE network_select;

CREATE TABLE network_select (
	network_id varchar(12) NOT NULL,
	acquirer_id varchar(12) NOT NULL,
	card_product varchar(12) NOT NULL,
	channel_type varchar(12) NOT NULL,
	description varchar(255) NULL,
	from_offset varchar(16) NULL,
	imf_data varchar(128) NULL,
	imf_search_flag varchar(255) NULL,
	imf_value varchar(128) NULL,
	issuer_id varchar(12) NOT NULL,
	mti varchar(4) NOT NULL,
	to_offset varchar(45) NULL,
	tp_code varchar(6) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT network_select_pkey PRIMARY KEY (network_id)
);

CREATE SEQUENCE transaction_group_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;
	
-- transaction_group definition

-- Drop table

-- DROP TABLE transaction_group;

CREATE TABLE transaction_group (
	transaction_group_id int8 NOT NULL DEFAULT nextval('transaction_group_seq'::regclass),
	transaction_group varchar(16) NOT NULL,
	transaction_code varchar(30) NOT NULL,
	status bpchar(1) NOT NULL,
	description varchar(100) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT group_code_status_uq UNIQUE (transaction_group, transaction_code, status),
	CONSTRAINT status_chk CHECK ((status = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
	CONSTRAINT transaction_group_pkey PRIMARY KEY (transaction_group_id)
);

-- transaction_key definition

-- Drop table

-- DROP TABLE transaction_key;

CREATE TABLE transaction_key (
	transaction_key_id varchar(16) NOT NULL,
	acquirer_id varchar(12) NOT NULL,
	channel_type varchar(12) NOT NULL,
	description varchar(255) NULL,
	imf_data varchar(128) NOT NULL,
	mti varchar(4) NOT NULL,
	tp_code varchar(6) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT transaction_key_pkey PRIMARY KEY (transaction_key_id)
);

CREATE SEQUENCE transaction_master_seq
   INCREMENT BY 1
   MINVALUE 1
   MAXVALUE 9223372036854775807
   START 1
   CACHE 1
   NO CYCLE;
   
-- Drop table
-- DROP TABLE transaction_master;
CREATE TABLE transaction_master (
	transaction_seq int8 NOT NULL DEFAULT nextval('transaction_master_seq'::regclass),
	mti varchar(4) NOT NULL,
	proxy_card_number varchar(32) NOT NULL,
	tpcode varchar(6) NOT NULL,
	transaction_amount numeric(26, 8) NOT NULL,
	billing_amount numeric(26, 8) NOT NULL,
	billing_fee_amount numeric(26, 8) NOT NULL,
	transaction_fee_amount numeric(26, 8) NOT NULL,
	settlement_amount numeric(26, 8) NOT NULL,
	settlement_fee_amount numeric(26, 8) NULL,
	transaction_processing_fee_amount numeric(26, 8) NULL,
	settlement_processing_fee_amount numeric(26, 8) NULL,
	settlement_coversion_rate numeric(26, 8) NOT NULL,
	billing_coversion_rate numeric(26, 8) NOT NULL,
	transaction_date_time timestamp NOT NULL,
	stan varchar(6) NOT NULL,
	local_time varchar NOT NULL,
	local_date date NOT NULL,
	expiry_date date NOT NULL,
	settlement_date date NULL,
	conversion_date date NOT NULL,
	capture_date date NULL,
	mcc varchar(4) NULL,
	acq_inst_country_code varchar(4) NOT NULL,
	fwd_inst_country_code varchar(4) NULL,
	pos_entry_mode varchar(4) NOT NULL,
	card_seq_num varchar(4) NOT NULL,
	pos_condition_code varchar(12) NULL,
	pos_pin_capture_code varchar(4) NOT NULL,
	auth_id_resp varchar(4) NOT NULL,
	acquirer_bin varchar(12) NOT NULL,
	track_2_data varchar(128) NOT NULL,
	rrn varchar(12) NOT NULL,
	card_acceptor_terminal_id varchar(11) NULL,
	card_acceptor_id varchar(16) NULL,
	card_acceptor_terminal_location varchar(64) NULL,
	transaction_currency_code varchar(4) NOT NULL,
	settlement_currency_code varchar(4) NOT NULL,
	billing_currency_code varchar(4) NOT NULL,
	pin_data varchar(55) NOT NULL,
	security_related_control_information varchar(128) NULL,
	security_info varchar(128) NULL,
	security_result varchar(128) NULL,
	settlement_inst_id_code varchar(64) NOT NULL,
	receiving_inst_id_code varchar(3) NOT NULL,
	settlement_code varchar(3) NOT NULL,
	receiving_inst_country_code varchar(3) NOT NULL,
	settlement_inst_country_code varchar(3) NOT NULL,
	original_data_elements varchar(64) NOT NULL,
	account_identification_1 varchar(12) NOT NULL,
	account_identification_2 varchar(12) NOT NULL,
	network_type varchar(12) NOT NULL,
	acquirer_institution_id varchar(11) NOT NULL,
	channel_type varchar(6) NOT NULL,
	transaction_type varchar(2) NOT NULL,
	issuer_bin varchar(12) NOT NULL,
	issuer_institution_id varchar(6) NOT NULL,
	transaction_key varchar(128) NOT NULL,
	masked_pan varchar(25) NOT NULL,
	hashed_pan varchar(128) NOT NULL,
	account_number varchar(16) NOT NULL,
	accum_flag varchar(1) NOT NULL,
	acquirer_id varchar(12) NULL,
	issuer_id varchar(6) NULL,
	network_id varchar(12) NULL,
	api_ref_no varchar(512) NOT NULL,
	auth_number varchar(6) NOT NULL,
	available_balance numeric(26, 8) NOT NULL,
	business_date date NULL,
	charge_accum_flag varchar(1) NOT NULL,
	cin varchar(128) NULL,
	dr_cr_amount numeric(26, 8) NULL,
	dr_cr_flag varchar(1) NULL,
	iss_conv_rate numeric(26, 8) NULL,
	iss_currency_code varchar(3) NULL,
	kyc_flag varchar(1) NULL,
	product_id varchar(11) NULL,
	reason_code varchar(4) NULL,
	response_code varchar(3) NOT NULL,
	rev_amount numeric(26, 8) NULL,
	rev_flag varchar(2) NULL,
	transaction_status varchar(1) NOT NULL,
	reserver_fld1 varchar(512) NULL,
	reserver_fld2 varchar(512) NULL,
	reserver_fld3 varchar(512) NULL,
	reserver_fld4 varchar(512) NULL,
	reserver_fld5 varchar(512) NULL,
	reserver_fld6 varchar(512) NULL,
	reserver_fld7 varchar(512) NULL,
	reserver_fld8 varchar(512) NULL,
	reserver_fld9 varchar(512) NULL,
	reserver_fld10 varchar(512) NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	inc_txn_count int4 NOT NULL,
	CONSTRAINT api_ref_no_unique UNIQUE (api_ref_no),
	CONSTRAINT tranasaction_master_pkey PRIMARY KEY (transaction_seq),
	CONSTRAINT transaction_key_unique UNIQUE (transaction_key)
);