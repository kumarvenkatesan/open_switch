ALTER TABLE transaction_master ALTER COLUMN original_data_elements DROP NOT NULL;
