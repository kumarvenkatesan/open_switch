ALTER TABLE "transaction".transaction_master ADD org_txn_key varchar(128) NULL;
ALTER TABLE "transaction".transaction_master ADD org_txn_date_time timestamp NULL;