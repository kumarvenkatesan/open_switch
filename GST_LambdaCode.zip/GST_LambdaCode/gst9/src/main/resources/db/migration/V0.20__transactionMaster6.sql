ALTER TABLE transaction_master ALTER COLUMN org_txn_date_time TYPE varchar USING org_txn_date_time::varchar;
ALTER TABLE transaction_master RENAME COLUMN trandatetime TO tran_date_time;
