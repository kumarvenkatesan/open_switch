ALTER TABLE card_master ADD pinretrycount _int2 NULL;
ALTER TABLE card_master ADD pinblockeddatatime timestamp NULL;