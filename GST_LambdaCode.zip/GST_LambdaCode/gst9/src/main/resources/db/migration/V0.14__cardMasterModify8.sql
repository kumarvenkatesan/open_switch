ALTER TABLE card_master ADD dcvv_flag varchar(1) NULL;
ALTER TABLE card_master ADD dcvv_value varchar(3) NULL;