ALTER TABLE card_master DROP COLUMN pinretrycount;
ALTER TABLE card_master ADD pinretrycount int2 NULL;