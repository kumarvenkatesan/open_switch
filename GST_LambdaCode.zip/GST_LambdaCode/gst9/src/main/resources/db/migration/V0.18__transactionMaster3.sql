ALTER TABLE transaction_master ADD trandatetime varchar(10) NOT NULL DEFAULT 0000000000;
