ALTER TABLE card_master DROP COLUMN pinretrycount;
ALTER TABLE card_master DROP COLUMN pinblockeddatatime;
ALTER TABLE card_master ADD pin_retry_count int2 NULL;
ALTER TABLE card_master ADD pin_blocked_date timestamp NULL;
