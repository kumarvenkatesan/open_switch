package money.open.cards.transaction.utils;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.transaction.dto.TransactionRequestDto;
import money.open.cards.transaction.enums.TransactionTypeEnum;
import money.open.cards.transaction.redis.dao.TransactionKeyRedisDao;
import money.open.cards.transaction.redis.model.TransactionKeyRedis;

@Slf4j
@Service
public class TransactionKeyUtils {

	@Autowired
	TransactionKeyRedisDao transactionKeyRedisDao;

	@Autowired
	KeyValueMapperUtils imfDataGeneration;

	private static final float STAR_PRIORITY = 0.5f;

	public TransactionRequestDto transactionKeyFormationData(TransactionRequestDto transactionRequestDto) {

		String acquirerId = transactionRequestDto.getAcquirerId();
		String channelType = transactionRequestDto.getChannelType();
		String mti = transactionRequestDto.getMti();
		String tpCode = transactionRequestDto.getTpCode().substring(0, 2);

		if (StringUtils.isEmpty(acquirerId)) {
			transactionRequestDto.setResponseCode(SwitchResponseCodes.SYSTEM_ERROR.getCode());
			return transactionRequestDto;
		}

		List<TransactionKeyRedis> networkSelectData = transactionKeyRedisDao.findByAcquirerId(acquirerId);
		if (networkSelectData.isEmpty()) {
			log.info("Network Select Data is Not Present in Redis");
			transactionRequestDto.setResponseCode(SwitchResponseCodes.SYSTEM_ERROR.getCode());
			return transactionRequestDto;
		}

		float masterMatchProbability = 0;
		float channelPriority;
		float mtiPriority;
		float tpCodePriority;
		mtiPriority = channelPriority = tpCodePriority = 1f;
		TransactionKeyRedis filteredTransactionKey = null;

		for (TransactionKeyRedis tranKeyData : networkSelectData) {
			float currentMatchProbability = 0f;

			float channelProbability = this.findProbability(tranKeyData.getChannelType(), channelType, channelPriority);
			if (channelProbability < 0)
				continue;

			currentMatchProbability = currentMatchProbability + channelProbability;

			float mtiProbability = this.findProbability(tranKeyData.getMti(), mti, mtiPriority);
			if (mtiProbability < 0)
				continue;

			currentMatchProbability = currentMatchProbability + mtiProbability;

			float tpCodeProbability = this.findProbability(tranKeyData.getTpCode(), tpCode, tpCodePriority);
			if (tpCodeProbability < 0)
				continue;
			currentMatchProbability = currentMatchProbability + tpCodeProbability;

			if (currentMatchProbability > masterMatchProbability) {
				masterMatchProbability = currentMatchProbability;
				filteredTransactionKey = tranKeyData;
			}
		}

		if (filteredTransactionKey == null)

		{
			log.info("Transaction Key Data not Found in Transaction Key Redis");
			transactionRequestDto.setResponseCode(SwitchResponseCodes.SYSTEM_ERROR.getCode());
			return transactionRequestDto;
		}

		transactionRequestDto.setDrCrFlag(filteredTransactionKey.getDrCrFlag());
		transactionRequestDto.setTransactionType(TransactionTypeEnum.valueOf(filteredTransactionKey.getTxnType()));
		transactionRequestDto.setTransactionKey(
				imfDataGeneration.keyValueMapper(filteredTransactionKey.getImfData(), transactionRequestDto));
		transactionRequestDto.setLimitValidationFlag(filteredTransactionKey.getLimitRequired());

		return transactionRequestDto;
	}

	public float findProbability(String value, String anotherValue, float priority) {
		if (value.equals(anotherValue)) {
			return priority;
		} else if (value.equals("*")) {
			return STAR_PRIORITY;
		}
		return -1f;
	}
}
//				List<TransactionKeyRedis> tranKey = networkSelectData.stream()
//						.filter(p -> (p.getAcquirerId().equals(acquirerId) && p.getChannelType().equals(channelType)))
//						.collect(Collectors.toList());
//				if (!tranKey.isEmpty()) {
//					List<TransactionKeyRedis> tranKey1 = tranKey
//							.stream().filter(p -> (p.getAcquirerId().equals(acquirerId)
//									&& p.getChannelType().equals(channelType) && p.getMti().equals(mti)))
//							.collect(Collectors.toList());
//					if (!tranKey1.isEmpty()) {
//						List<TransactionKeyRedis> tranKey3 = tranKey1.stream()
//								.filter(p -> (p.getAcquirerId().equals(acquirerId)
//										&& p.getChannelType().equals(channelType) && p.getMti().equals(mti)
//										&& p.getTpCode().equals(tpCode.substring(0, 2))))
//								.collect(Collectors.toList());
//						if (!tranKey3.isEmpty()) {
//
//						} else {
//							List<TransactionKeyRedis> tranKey4 = tranKey1.stream()
//									.filter(p -> (p.getAcquirerId().equals(acquirerId)
//											&& p.getChannelType().equals(channelType) && p.getMti().equals(mti)
//											&& p.getTpCode().equals(tpCode.substring(0, 6))))
//									.collect(Collectors.toList());
//							if (!tranKey4.isEmpty()) {
//								imfData = tranKey4.get(0).getImfData();
//								drCrFlag = tranKey4.get(0).getDrCrFlag();
//								txnType = tranKey4.get(0).getTxnType();
//								limitRequired = tranKey4.get(0).getLimitRequired();
//							} else {
//								List<TransactionKeyRedis> tranKey5 = networkSelectData.stream()
//										.filter(p -> (p.getAcquirerId().equals(acquirerId)
//												&& p.getChannelType().equals(channelType) && p.getMti().equals(mti)
//												&& p.getTpCode().equals("*")))
//										.collect(Collectors.toList());
//								if (!tranKey5.isEmpty()) {
//									imfData = tranKey5.get(0).getImfData();
//									drCrFlag = tranKey5.get(0).getDrCrFlag();
//									txnType = tranKey5.get(0).getTxnType();
//									limitRequired = tranKey5.get(0).getLimitRequired();
//								} else {
//									log.info("TranKey5 Data not Present");
//								}
//							}
//						}
//					} else {
//						List<TransactionKeyRedis> tranKey5 = networkSelectData.stream()
//								.filter(p -> (p.getAcquirerId().equals(acquirerId)
//										&& p.getChannelType().equals(channelType) && p.getMti().equals("*")))
//								.collect(Collectors.toList());
//						if (!tranKey5.isEmpty()) {
//							List<TransactionKeyRedis> tranKey3 = tranKey5.stream()
//									.filter(p -> (p.getAcquirerId().equals(acquirerId)
//											&& p.getChannelType().equals(channelType) && p.getMti().equals("*")
//											&& p.getTpCode().equals(tpCode.substring(0, 2))))
//									.collect(Collectors.toList());
//							if (!tranKey3.isEmpty()) {
//								imfData = tranKey3.get(0).getImfData();
//								drCrFlag = tranKey3.get(0).getDrCrFlag();
//								txnType = tranKey3.get(0).getTxnType();
//								limitRequired = tranKey3.get(0).getLimitRequired();
//							} else {
//								List<TransactionKeyRedis> tranKey4 = networkSelectData.stream()
//										.filter(p -> (p.getAcquirerId().equals(acquirerId)
//												&& p.getChannelType().equals(channelType) && p.getMti().equals("*")
//												&& p.getTpCode().equals(tpCode.substring(0, 6))))
//										.collect(Collectors.toList());
//								if (!tranKey4.isEmpty()) {
//									imfData = tranKey4.get(0).getImfData();
//									drCrFlag = tranKey4.get(0).getDrCrFlag();
//									txnType = tranKey4.get(0).getTxnType();
//									limitRequired = tranKey4.get(0).getLimitRequired();
//								} else {
//									List<TransactionKeyRedis> tranKey6 = networkSelectData.stream()
//											.filter(p -> (p.getAcquirerId().equals(acquirerId)
//													&& p.getChannelType().equals(channelType) && p.getMti().equals("*")
//													&& p.getTpCode().equals("*")))
//											.collect(Collectors.toList());
//									if (!tranKey6.isEmpty()) {
//										imfData = tranKey6.get(0).getImfData();
//										drCrFlag = tranKey6.get(0).getDrCrFlag();
//										txnType = tranKey6.get(0).getTxnType();
//										limitRequired = tranKey6.get(0).getLimitRequired();
//									} else {
//										log.info("tranKey6 Data not Present");
//									}
//								}
//							}
//						} else {
//							log.info("Configuration MisMatch");
//						}
//					}
//				} else {
//					List<TransactionKeyRedis> tranKey2 = networkSelectData.stream()
//							.filter(p -> (p.getAcquirerId().equals(acquirerId) && p.getChannelType().equals("*")))
//							.collect(Collectors.toList());
//					if (!tranKey2.isEmpty()) {
//						List<TransactionKeyRedis> tranKey1 = tranKey2
//								.stream().filter(p -> (p.getAcquirerId().equals(acquirerId)
//										&& p.getChannelType().equals("*") && p.getMti().equals(mti)))
//								.collect(Collectors.toList());
//						if (!tranKey1.isEmpty()) {
//							List<TransactionKeyRedis> tranKey3 = tranKey1.stream()
//									.filter(p -> (p.getAcquirerId().equals(acquirerId) && p.getChannelType().equals("*")
//											&& p.getMti().equals(mti) && p.getTpCode().equals(tpCode.substring(0, 2))))
//									.collect(Collectors.toList());
//							if (!tranKey3.isEmpty()) {
//								imfData = tranKey3.get(0).getImfData();
//								drCrFlag = tranKey3.get(0).getDrCrFlag();
//								txnType = tranKey3.get(0).getTxnType();
//								limitRequired = tranKey3.get(0).getLimitRequired();
//							} else {
//								List<TransactionKeyRedis> tranKey4 = tranKey3.stream()
//										.filter(p -> (p.getAcquirerId().equals(acquirerId)
//												&& p.getChannelType().equals("*") && p.getMti().equals(mti)
//												&& p.getTpCode().equals(tpCode.substring(0, 6))))
//										.collect(Collectors.toList());
//								if (!tranKey4.isEmpty()) {
//									imfData = tranKey4.get(0).getImfData();
//									drCrFlag = tranKey4.get(0).getDrCrFlag();
//									txnType = tranKey4.get(0).getTxnType();
//									limitRequired = tranKey4.get(0).getLimitRequired();
//								} else {
//									List<TransactionKeyRedis> tranKey5 = networkSelectData.stream()
//											.filter(p -> (p.getAcquirerId().equals(acquirerId)
//													&& p.getChannelType().equals("*") && p.getMti().equals(mti)
//													&& p.getTpCode().equals("*")))
//											.collect(Collectors.toList());
//									if (!tranKey5.isEmpty()) {
//										imfData = tranKey5.get(0).getImfData();
//										drCrFlag = tranKey5.get(0).getDrCrFlag();
//										txnType = tranKey5.get(0).getTxnType();
//										limitRequired = tranKey5.get(0).getLimitRequired();
//									} else {
//										log.info("TranKey5 Data not Present");
//									}
//								}
//							}
//						} else {
//							List<TransactionKeyRedis> tranKey5 = networkSelectData
//									.stream().filter(p -> (p.getAcquirerId().equals(acquirerId)
//											&& p.getChannelType().equals("*") && p.getMti().equals("*")))
//									.collect(Collectors.toList());
//							if (!tranKey5.isEmpty()) {
//								List<TransactionKeyRedis> tranKey3 = tranKey5.stream()
//										.filter(p -> (p.getAcquirerId().equals(acquirerId)
//												&& p.getChannelType().equals("*") && p.getMti().equals("*")
//												&& p.getTpCode().equals(tpCode.substring(0, 6))))
//										.collect(Collectors.toList());
//								if (!tranKey3.isEmpty()) {
//									imfData = tranKey3.get(0).getImfData();
//									drCrFlag = tranKey3.get(0).getDrCrFlag();
//									txnType = tranKey3.get(0).getTxnType();
//								} else {
//									List<TransactionKeyRedis> tranKey4 = networkSelectData.stream()
//											.filter(p -> (p.getAcquirerId().equals(acquirerId)
//													&& p.getChannelType().equals("*") && p.getMti().equals("*")
//													&& p.getTpCode().equals(tpCode.substring(0, 2))))
//											.collect(Collectors.toList());
//									if (!tranKey4.isEmpty()) {
//										imfData = tranKey4.get(0).getImfData();
//										drCrFlag = tranKey4.get(0).getDrCrFlag();
//										txnType = tranKey4.get(0).getTxnType();
//									} else {
//										List<TransactionKeyRedis> tranKey6 = networkSelectData.stream()
//												.filter(p -> (p.getAcquirerId().equals(acquirerId)
//														&& p.getChannelType().equals("*") && p.getMti().equals("*")
//														&& p.getTpCode().equals("*")))
//												.collect(Collectors.toList());
//										if (!tranKey6.isEmpty()) {
//											imfData = tranKey6.get(0).getImfData();
//											drCrFlag = tranKey6.get(0).getDrCrFlag();
//											txnType = tranKey6.get(0).getTxnType();
//										} else {
//											log.info("tranKey6 Data not Present");
//										}
//									}
//								}
//							}
//						}
//					}
//				}
//			} else {
//				log.info("AcquirerId/ issuerSelect Id not present");
//			}
//		}
//
//	}
//}