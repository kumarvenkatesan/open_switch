package money.open.cards.transaction.enums;

public enum CurrencyModesEnum {
	S,H
}
