package money.open.cards.transaction.enums;

public enum PinPrintMethodsEnum{
	I,O;
}
