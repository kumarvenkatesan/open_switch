package money.open.cards.transaction.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import money.open.cards.transaction.dto.LimitMasterDto;
import money.open.cards.transaction.model.LimitMaster;

@Mapper
public interface LimitMasterMapper {

	LimitMasterMapper INSTANCE = Mappers.getMapper(LimitMasterMapper.class);

	LimitMaster LimitMasterDtoToLimitMaster(LimitMasterDto transactionRequestDto);
}
