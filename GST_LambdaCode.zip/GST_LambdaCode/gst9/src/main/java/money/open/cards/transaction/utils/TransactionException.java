package money.open.cards.transaction.utils;

import lombok.Getter;

public class TransactionException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Getter
	final ResponseCodes responseCode;
	
	public TransactionException(ResponseCodes responseCode){
		super(responseCode.getMessage());
		this.responseCode = responseCode;
	}
}
