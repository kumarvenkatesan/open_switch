package money.open.cards.transaction;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.util.backoff.FixedBackOff;

@Configuration
@EnableKafka
@Profile("!test")
public class SpringKafkaConfig {

	@Value("${kafka.local.server.config}")
	private String kafkaBoostrapServer;

	@Value("${kafka.consumer.group.id}")
	private String consumerGroupId;

	@Value("${consumer.container.concurrency}")
	private int consumerContainerConcurrency;

	@Value("${kafka.sasl.enabled}")
	private boolean kafkaSASLEnabled;

	@Value("${spring.kafka.properties.sasl.mechanism}")
	private String saslMechanism;

	@Value("${spring.kafka.properties.security.protocol}")
	private String securityProtocolConfig;

	@Value("${spring.kafka.properties.sasl.jaas.config}")
	private String saslJaasConfig;

	@Value("${kakfa.cardUpdater.topic.name}")
	private String cardUpdaterTopicName;

	@Value("${kakfa.cardUpdater.partition}")
	private int cardUpdaterTopicPartition;

	@Value("${kakfa.transaction.consumer3.topic.name}")
	private String consumer3TopicName;

	@Value("${kakfa.transaction.consumer3.topic.partition}")
	private int consumer3Partition;

	@Bean
	NewTopic transactionTopic() {
		return TopicBuilder.name(consumer3TopicName).partitions(consumer3Partition).build();
	}

	@Bean
	NewTopic cardUpdaterTopic() {
		return TopicBuilder.name(cardUpdaterTopicName).partitions(cardUpdaterTopicPartition).build();
	}

	@Bean
	KafkaAdmin admin() {
		Map<String, Object> configMap = new HashMap<>();
		configMap.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBoostrapServer);
		if (kafkaSASLEnabled) {
			configMap.put(AdminClientConfig.SECURITY_PROTOCOL_CONFIG, securityProtocolConfig);
			configMap.put(SaslConfigs.SASL_MECHANISM, saslMechanism);
			configMap.put(SaslConfigs.SASL_JAAS_CONFIG, saslJaasConfig);
		}
		return new KafkaAdmin(configMap);
	}

	@Bean
	public ProducerFactory<String, String> producerFactory() {
		Map<String, Object> configMap = new HashMap<>();
		configMap.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBoostrapServer);
		configMap.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		configMap.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		if (kafkaSASLEnabled) {
			configMap.put(AdminClientConfig.SECURITY_PROTOCOL_CONFIG, securityProtocolConfig);
			configMap.put(SaslConfigs.SASL_MECHANISM, saslMechanism);
			configMap.put(SaslConfigs.SASL_JAAS_CONFIG, saslJaasConfig);
		}
		return new DefaultKafkaProducerFactory<>(configMap);
	}

	@Bean
	public KafkaTemplate<String, String> kafkaTemplate() {
		return new KafkaTemplate<>(producerFactory());
	}

	@Bean
	public ConsumerFactory<String, String> consumerFactory() {
		Map<String, Object> configMap = new HashMap<>();
		configMap.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBoostrapServer);
		configMap.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		configMap.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		configMap.put(ConsumerConfig.GROUP_ID_CONFIG, consumerGroupId);
		if (kafkaSASLEnabled) {
			configMap.put(AdminClientConfig.SECURITY_PROTOCOL_CONFIG, securityProtocolConfig);
			configMap.put(SaslConfigs.SASL_MECHANISM, saslMechanism);
			configMap.put(SaslConfigs.SASL_JAAS_CONFIG, saslJaasConfig);
		}
		return new DefaultKafkaConsumerFactory<>(configMap);
	}

	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {
		ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConcurrency(consumerContainerConcurrency);
		factory.setConsumerFactory(consumerFactory());
		factory.setCommonErrorHandler(new DefaultErrorHandler(new FixedBackOff(0L, 0L)));
		return factory;
	}
}
