package money.open.cards.transaction.dto;

import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class VerifyPinOffsetServiceDataDto {
    @NotBlank
    private String cardNumber;
    @NotBlank @Length(min = 4,max = 4)
    private String pinOffset;
    @NotBlank @Length(max = 32)
    private String pinBlock;
}
