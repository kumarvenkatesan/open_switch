package money.open.cards.transaction.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import money.open.cards.transaction.model.AccumMaster;

public interface AccumMasterRepository extends JpaRepository<AccumMaster, String> {

	Optional<AccumMaster> findByPartnerEntityIdAndEntityIdAndEntityTypeAndTpCodeAndCountryModeAndChannel(
			String partnerEntityId, String entityId, String entityType, String tpCode, String countryModeEnum,
			String channelType);

}
