package money.open.cards.transaction.enums;

public enum TransactionModes {
	SYNC,
	ASYNC;
}
