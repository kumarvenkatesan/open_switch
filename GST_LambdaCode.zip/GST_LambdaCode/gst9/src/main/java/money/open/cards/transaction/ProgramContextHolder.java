package money.open.cards.transaction;

public class ProgramContextHolder {
    private static final ThreadLocal<String> program = new ThreadLocal<>();

    public static String getProgram(){
        return program.get();
    }

    public static void setProgram(String tenant){
        program.set(tenant);
    }

    public static void removeCurrentProgram(){
        program.remove();
    }
}
