package money.open.cards.transaction.enums;

public enum SignonFlagEnum {
	Y,N
}
