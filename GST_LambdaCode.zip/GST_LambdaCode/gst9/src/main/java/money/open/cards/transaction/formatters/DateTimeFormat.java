package money.open.cards.transaction.formatters;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.Year;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.Locale;

import org.springframework.stereotype.Service;

/**
 * Utility class for date time formats.
 */
@Service
public class DateTimeFormat {

	private static final String YYYYMMDD = "yyyy-MM-dd";

	private static final String YYYYMMDDHHMMSS = "yyyy-MM-dd HH:mm:ss";

	private DateTimeFormat() {
		// Defeat object creation.
	}

	public static DateTimeFormatter formatYYYYMMDD() {
		return DateTimeFormatter.ofPattern(YYYYMMDD);
	}

	public static SimpleDateFormat simpleDateFormatYYYYMMDDWithLocale() {
		return new SimpleDateFormat(YYYYMMDD, Locale.ENGLISH);
	}

	public static DateTimeFormatter formatYYYYMMDDHHMMSS() {
		return DateTimeFormatter.ofPattern(YYYYMMDD);
	}

	public static SimpleDateFormat simpleDateFormatYYYYMMDDHHMMSSWithLocale() {
		return new SimpleDateFormat(YYYYMMDDHHMMSS, Locale.ENGLISH);
	}

	public LocalDateTime formatter(String transactionDateTime) {
		Year thisYear = Year.now(ZoneId.systemDefault());
		DateTimeFormatter formatter = new DateTimeFormatterBuilder().appendPattern("MMddHHmmss")
				.parseDefaulting(ChronoField.YEAR, thisYear.getValue()).toFormatter();
		return LocalDateTime.parse(transactionDateTime, formatter);
	}

}
