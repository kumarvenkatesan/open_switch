package money.open.cards.transaction.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import money.open.cards.transaction.redis.dao.ProgramMasterRedisDao;
import money.open.cards.transaction.redis.model.ProgramMasterRedis;

@Service
public class ProgramNameFinder {
	
	@Autowired
	ProgramMasterRedisDao programMasterRedisDao;
	
	public String getProgramName(String issuerBin) {
		
		ProgramMasterRedis programKey =  programMasterRedisDao.findByIssuerBinIssuerBin(issuerBin);
		return programKey.getProgramKey();
	}

}
