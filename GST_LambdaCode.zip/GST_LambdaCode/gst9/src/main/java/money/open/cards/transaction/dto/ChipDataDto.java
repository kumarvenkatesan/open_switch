package money.open.cards.transaction.dto;

import lombok.Data;
import lombok.ToString;

@ToString
@Data
public class ChipDataDto {
	private String terminalCapabilityProfile;
	private String terminalVerificationResult;
	private String unPredictableNumber;
	private String issuerApplicationData;
	private String cryptogram;
	private String applicationTranCounter;
	private String applicationInterProfile;
	private String cryptoTranType;
	private String terminalCountryCode;
	private String terminalTranDate;
	private String cryptoAmount;
	private String cryptoCurrencyCode;
	private String cryptoCashBackAmt;
	private String iccDataSegment;
	private String arpc;
	private String authResponseCode;
}
