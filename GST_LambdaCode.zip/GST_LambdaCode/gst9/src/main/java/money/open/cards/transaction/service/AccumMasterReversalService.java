package money.open.cards.transaction.service;

import java.math.BigDecimal;

import money.open.cards.transaction.enums.CountryModesEnum;
import money.open.cards.transaction.utils.TransactionException;

public interface AccumMasterReversalService {

	void accumMasterReversal(String partnerEntityId, String cardProduct, String tpCode, String limitConfigType,
			String proxyCardNumber, BigDecimal drCrAmount, String drCrFlag, CountryModesEnum countryModeEnum,
			String channelType) throws TransactionException;
}
