package money.open.cards.transaction.service;

import com.fasterxml.jackson.core.JsonProcessingException;

import money.open.cards.transaction.dto.TransactionRequestDto;
import money.open.cards.transaction.model.TransactionMaster;

public interface ProcessReversalOrAdjustmentService {

	public TransactionRequestDto processReversalTranasction(TransactionRequestDto transactionRequestDto,
			TransactionMaster originalTransaction) throws JsonProcessingException;
}
