package money.open.cards.transaction.enums;

public enum CardSchemesEnum {
	VISA,MASTER,RUPAY,CUP
}
