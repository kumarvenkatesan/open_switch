package money.open.cards.transaction.enums;

public enum CardGenTypesEnum {
	I,P
}
