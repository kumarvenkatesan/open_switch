package money.open.cards.transaction.utils;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.transaction.redis.dao.IssuerSelectRedisDao;
import money.open.cards.transaction.redis.model.IssuerSelectRedis;

@Slf4j
@Service
public class IssuerSelectUtils {

	@Autowired
	private IssuerSelectRedisDao issuerSelectRedisDao;

	public String issuerSelectRedisData(String issuserBin, String channelType) {

		String issuerSelectId = null;
		if (channelType == null) {
			log.info("Channel Type is Empty in request for issuerBin :: {} ", issuserBin);
			return null;
		}

		List<IssuerSelectRedis> issuerSelectData = issuerSelectRedisDao.findByIssuerBinAndChannelType(issuserBin,
				channelType);
		if (!issuerSelectData.isEmpty()) {
			issuerSelectId = issuerSelectData.get(0).getIssuerSelectId();
			return issuerSelectId;
		}
		List<IssuerSelectRedis> issuerSelectAllData = issuerSelectRedisDao.findByIssuerBinAndChannelType(issuserBin,
				"*");
		if (issuerSelectAllData.isEmpty()) {
			log.info("configuration Not found for aquirer and channel type for issuer bin {} and Channel Type {}",
					issuserBin, channelType);
			return null;
		}
		for (int i = 0; i < issuerSelectAllData.size(); i++) {
			if (issuerSelectAllData.get(i).getChannelType().equals("*")) {
				issuerSelectId = issuerSelectAllData.get(i).getIssuerSelectId();
				return issuerSelectId;
			}
		}
		return issuerSelectId;

	}
}
