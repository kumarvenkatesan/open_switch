package money.open.cards.transaction.enums;

import lombok.Getter;

@Getter
public enum ReversalFlag {
	FULLY_REVERSED('F'),PARTIALLY_REVERSED('P');
	
	Character flag;

	private ReversalFlag(Character flag) {
		this.flag = flag;
	}
}
