package money.open.cards.transaction.utils;

import lombok.Getter;

public class DataSourceLookupException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	@Getter
	final ResponseCodes responseCodes;

	public DataSourceLookupException(ResponseCodes responseCodes) {
		super(responseCodes.getMessage());
		this.responseCodes = responseCodes;
	}

}
