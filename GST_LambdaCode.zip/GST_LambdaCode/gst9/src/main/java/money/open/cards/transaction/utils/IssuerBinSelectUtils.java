package money.open.cards.transaction.utils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.transaction.dto.TransactionRequestDto;
import money.open.cards.transaction.redis.dao.IssuerBinRedisDao;
import money.open.cards.transaction.redis.model.IssuerBinRedis;

@Slf4j
@Service
public class IssuerBinSelectUtils {

	@Autowired
	IssuerBinRedisDao issuerBinRedisDao;

	public TransactionRequestDto issuerBinSelect(TransactionRequestDto transactionRequestDto) {
		if (transactionRequestDto.getIssuerBin() != null) {

			IssuerBinRedis issuerBin = issuerBinRedisDao.findByIssuerBin(transactionRequestDto.getIssuerBin());
			if (issuerBin != null) {
				transactionRequestDto.setIssuerBin(issuerBin.getIssuerBin());
				transactionRequestDto.setPrimaryHsmId(issuerBin.getInstitutionId().getPrimaryHsmId());
				transactionRequestDto.setCvv1ServiceCode(issuerBin.getCvv1ServiceCode());
				transactionRequestDto.setCvv2ServiceCode(issuerBin.getCvv2ServiceCode());
				transactionRequestDto.setICvvServiceCode(issuerBin.getIcvvServiceCode());
				transactionRequestDto.setIssuerInstitutionId(issuerBin.getInstitutionId().getInstitutionId());
				transactionRequestDto.setPinResetMode(issuerBin.getPinResetMode());
				transactionRequestDto.setPinResetInterval(issuerBin.getPinResetPeriod());
				transactionRequestDto.setIssCurrencyCode(issuerBin.getInstitutionId().getBaseCurrencyCode());
				return transactionRequestDto;
			}

			log.info("Framing Issuer Bin data From Issuer Bin Redis");
			List<IssuerBinRedis> issuerBinData = issuerBinRedisDao.findAll();
			List<String> list = new ArrayList<>();
			list.add(transactionRequestDto.getCardNumber().substring(0, 12));
			list.add(transactionRequestDto.getCardNumber().substring(0, 11));
			list.add(transactionRequestDto.getCardNumber().substring(0, 10));
			list.add(transactionRequestDto.getCardNumber().substring(0, 9));
			list.add(transactionRequestDto.getCardNumber().substring(0, 8));
			list.add(transactionRequestDto.getCardNumber().substring(0, 7));
			list.add(transactionRequestDto.getCardNumber().substring(0, 6));

			for (int i = 0; i < issuerBinData.size(); i++) {
				Iterator<String> itr = list.iterator();
				while (itr.hasNext()) {
					if (itr.next().equals(issuerBinData.get(i).getIssuerBin())) {
						log.info("Bin {} Selection done ", issuerBinData.get(i).getIssuerBin());
						transactionRequestDto.setIssuerBin(issuerBinData.get(i).getIssuerBin());
						transactionRequestDto
								.setPrimaryHsmId(issuerBinData.get(i).getInstitutionId().getPrimaryHsmId());
						transactionRequestDto.setCvv1ServiceCode(issuerBinData.get(i).getCvv1ServiceCode());
						transactionRequestDto.setCvv2ServiceCode(issuerBinData.get(i).getCvv2ServiceCode());
						transactionRequestDto.setICvvServiceCode(issuerBinData.get(i).getIcvvServiceCode());
						transactionRequestDto
								.setInstitutionId(issuerBinData.get(i).getInstitutionId().getInstitutionId());
						transactionRequestDto.setPinResetMode(issuerBinData.get(i).getPinResetMode());
						transactionRequestDto.setPinResetInterval(issuerBinData.get(i).getPinResetPeriod());
						return transactionRequestDto;
					}
				}
			}
		}
		return null;
	}
}
