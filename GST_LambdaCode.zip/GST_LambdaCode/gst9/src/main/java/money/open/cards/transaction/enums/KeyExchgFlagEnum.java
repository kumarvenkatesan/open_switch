package money.open.cards.transaction.enums;

public enum KeyExchgFlagEnum {
	Y,N
}
