package money.open.cards.transaction.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import money.open.cards.transaction.dto.CardMasterDto;
import money.open.cards.transaction.service.CardMasterService;
import money.open.cards.transaction.utils.ResponseCodes;
import money.open.cards.transaction.utils.TransactionException;
import money.open.cards.transaction.utils.TransactionResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Map;

@RestController
@RequestMapping(value = "/tran")
@Slf4j
public class CardMasterController {

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private CardMasterService cardUpdaterService;

	@PostMapping("/cardUpdater")
	public TransactionResponse cardUpdater(@Valid @RequestBody CardMasterDto cardUpdaterDto)
			throws TransactionException {
		try {
			log.info("Post Method Card Updater Request Dto {} ", cardUpdaterDto.toString());
			return cardUpdaterService.postCardUpdater(cardUpdaterDto);
		} catch (Exception e) {
			return new TransactionResponse(null, ResponseCodes.FAILURE.getCode(), e.getMessage());
		}
	}

	@PatchMapping(path = "/cardUpdater", consumes = "application/json")
	public TransactionResponse patchCardUpdater(@RequestParam String proxyCardNumber,
			@RequestBody Map<String, Object> patchFields) throws TransactionException {

		try {
			log.info("Patch Method Card Updater Request Dto {} ", objectMapper.writeValueAsString(patchFields));
			return cardUpdaterService.patchCardUpdater(proxyCardNumber, patchFields);
		} catch (JsonProcessingException e) {
			return new TransactionResponse(null, ResponseCodes.FAILURE.getCode(), e.getMessage());
		}
	}

	@GetMapping(value = "/cardUpdater")
	public TransactionResponse fetchCustomeDetails(@Valid @RequestParam String proxyCardNumber) {

		try {
			log.info("Get Method Card Updater Request Param {} ", proxyCardNumber);
			return cardUpdaterService.getCardMasterDetails(proxyCardNumber);
		} catch (Exception e) {
			return new TransactionResponse(null, ResponseCodes.FAILURE.getCode(), e.getMessage());
		}
	}

}
