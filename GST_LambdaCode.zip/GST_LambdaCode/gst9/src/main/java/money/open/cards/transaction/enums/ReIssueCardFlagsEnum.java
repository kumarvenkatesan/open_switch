package money.open.cards.transaction.enums;

public enum ReIssueCardFlagsEnum {
	O,N
}
