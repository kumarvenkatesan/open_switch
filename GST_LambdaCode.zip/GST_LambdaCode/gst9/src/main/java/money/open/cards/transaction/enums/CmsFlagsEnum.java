package money.open.cards.transaction.enums;

public enum CmsFlagsEnum {
	Y,N;
}
