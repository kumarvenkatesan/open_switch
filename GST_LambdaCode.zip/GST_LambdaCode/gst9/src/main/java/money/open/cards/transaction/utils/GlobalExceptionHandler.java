package money.open.cards.transaction.utils;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.MismatchedInputException;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.transaction.dto.TransactionRequestDto;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@Override
    protected ResponseEntity<Object>
    handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
                                 HttpHeaders headers,
                                 HttpStatus status, WebRequest request) {
		log.info("Http not readable :: {}",ex.getMessage());
        TransactionResponse resp = new TransactionResponse();
        resp.setResponseCode(ResponseCodes.FIELD_ERROR.getCode());
        resp.setException(ex.getBindingResult().getFieldError().getDefaultMessage());
        return new ResponseEntity<>(resp, headers, HttpStatus.BAD_REQUEST);
    }
	
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		log.info("Http not readable :: {}",ex.getMessage());
		Throwable t = ex.getCause();
		TransactionResponse resp = null;
		if(t instanceof MismatchedInputException) {
			MismatchedInputException mie = (MismatchedInputException) t;
			for(JsonMappingException.Reference ref:mie.getPath()) {
				String expMsg = "Not a valid format for field :: "+"'"+ref.getFieldName()+"'";
				resp = new TransactionResponse();
				resp.setException(expMsg);
				resp.setResponseCode(ResponseCodes.FIELD_ERROR.getCode());
				return new ResponseEntity<>(resp,headers,HttpStatus.BAD_REQUEST);
			}
		} else {
			resp = new TransactionResponse();
			resp.setException(ex.getMessage());
			resp.setResponseCode(ResponseCodes.FIELD_ERROR.toString());
		}
		
		return new ResponseEntity<>(resp,headers,HttpStatus.BAD_REQUEST);
	}
	
	@Override
	protected ResponseEntity<Object> handleServletRequestBindingException(ServletRequestBindingException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		TransactionResponse resp = new TransactionResponse();
		resp.setException(ex.getMessage());
		resp.setResponseCode(ResponseCodes.FIELD_ERROR.getCode());
		log.info("Bad request response:: {}",resp);
		return new ResponseEntity<>(resp,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(Exception.class)
	@ResponseBody
	public TransactionRequestDto handleUnCaughtException(Exception ex){
		log.error("Uncaught exception :: {}",ex);
		TransactionRequestDto transactionRequestDto = new TransactionRequestDto();
		transactionRequestDto.setResponseCode(SwitchResponseCodes.SYSTEM_ERROR.getCode());
		transactionRequestDto.setReasonCode(ex.getMessage());
		return transactionRequestDto;
	}
}