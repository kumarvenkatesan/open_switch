package money.open.cards.transaction.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Validated
@SuperBuilder(toBuilder = true)
public class PinValidationRequestDto {

    @Valid
    @NotNull
    private DefaultKeyDto defaultData;

    @NotNull @Valid
    private VerifyPinOffsetServiceDataDto serviceData;

}