package money.open.cards.transaction.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import money.open.cards.transaction.dto.TransactionRequestDto;
import money.open.cards.transaction.model.TransactionMaster;

@Mapper
public interface TransactionMasterMapper {

	TransactionMasterMapper INSTANCE = Mappers.getMapper(TransactionMasterMapper.class);

	TransactionMaster transactionMasterDtoToTranMaster(TransactionRequestDto transactionRequestDto);
}
