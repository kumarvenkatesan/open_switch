package money.open.cards.transaction.utils;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import money.open.cards.transaction.model.CardMasterStatuses;

@Service
public class CardStatusResponseCode {

	public Map<String, String> getResponseCodeForCardStatus() {
		Map<String, String> responseForCardStatus = new HashMap<>();
		responseForCardStatus.put(CardMasterStatuses.CARD_PERMANENT_BLOCKED.getValue(),
				SwitchResponseCodes.BLOCKED_CARD.getCode());
		responseForCardStatus.put(CardMasterStatuses.CARD_DORMANT.getValue(),
				SwitchResponseCodes.DORMANT_CARD.getCode());
		responseForCardStatus.put(CardMasterStatuses.CARD_PICKUP.getValue(), SwitchResponseCodes.PICKUP_CARD.getCode());
		responseForCardStatus.put(CardMasterStatuses.CARD_EXPIRED_CARD.getValue(),
				SwitchResponseCodes.EXPIRED_CARD.getCode());
		responseForCardStatus.put(CardMasterStatuses.CARD_STOLEN.getValue(), SwitchResponseCodes.STOLEN_CARD.getCode());
		responseForCardStatus.put(CardMasterStatuses.CARD_CLOSE.getValue(),
				SwitchResponseCodes.REFER_TO_CARD_ISSUER.getCode());
		responseForCardStatus.put(CardMasterStatuses.CARD_LOST.getValue(), SwitchResponseCodes.LOST_CARD.getCode());
		responseForCardStatus.put(CardMasterStatuses.CARD_TEMP_BLOCKED.getValue(),
				SwitchResponseCodes.RESTRICTED_CARD.getCode());
		responseForCardStatus.put(CardMasterStatuses.CARD_ACTIVATED.getValue(),
				SwitchResponseCodes.APPROVED_OR_COMPLETED.getCode());
		responseForCardStatus.put(CardMasterStatuses.CARD_SUSPECTED_FRAUD.getValue(),
				SwitchResponseCodes.SUSPECTED_FRAUD.getCode());
		responseForCardStatus.put(CardMasterStatuses.CARD_ISSUED.getValue(),
				SwitchResponseCodes.INVALID_CARD_OR_ACCOUNT_NUMBER.getCode());
		responseForCardStatus.put(CardMasterStatuses.CARD_TEMP_BLOCKED_PIN_EXCEEDED.getValue(),
				SwitchResponseCodes.PIN_TRY_LIMIT_EXCEEDS.getCode());
		return responseForCardStatus;
	}

}
