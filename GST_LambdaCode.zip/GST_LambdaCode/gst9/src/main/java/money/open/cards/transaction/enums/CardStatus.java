package money.open.cards.transaction.enums;

public enum CardStatus {

	NOTACTIVE, // 0
	ALLOCATED, // 1
	LOCKED, // 2
	BLOCKED, // 3
	SURRENDERD, // 4
	DELINKED, // 5
	REPLACED, // 6
	DORMANT, // 7
	PICKUP, // 8
	EXPIRED_CARD, // 9
	STOLEN, // 10
	LOST, // 11
	RESTRICTED, // 12
	FRAUD // 13

}
