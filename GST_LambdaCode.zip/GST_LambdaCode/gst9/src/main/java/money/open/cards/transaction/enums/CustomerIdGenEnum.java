package money.open.cards.transaction.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CustomerIdGenEnum {
    P("Pass"),S("Sequence");

    final String description;
}
