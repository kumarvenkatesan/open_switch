package money.open.cards.transaction.utils;

import lombok.Getter;

public enum ResponseCodes {
	SUCCESS("T00", "Success"), FIELD_ERROR("T01", "Field Error"), JSON_PARSE_ERROR("T02", "Json Parse Error"),
	CONFIG_ERROR("T03", "Config Error"), FAILURE("T05", "Transaction Failure"),
	CARD_REGISTERED("T05", "Card Already Registerd"), PROXY_CARD_NOT_FOUND("T05", "Proxy Card Number Not Found"),
	KEY_MAP_NOT_CONFIGURED("T06", "Key map not configured"), SYSTEM_ERROR("T07", "System Eror"),
	REMOTE_CALL_FAILED("T08", "Remote Call Failed"), AUTH_TRANSACTION("T09", "Processed Transaction"),
	API_REF_NOT_PRESENT("T10", "Api Ref Not Present"), API_REF_UNIQUE("T11", "Api Ref No Should be Unique"),
	CHANNEL_TYPE_ACQ_NOT_PRESENT_IN_REQUEST("T12", "Channel Type and Acquirer Id Not Present in the Request"),
	CARD_NOT_ACTIVE("T13", "Card Not Active / Card Number Not Present"),
	INVALID_CHANNEL_TYPE("T14", "Invalid Channel Type"),
	TRANSACTION_NOT_ALLOWED_IN_TRANSACTION_GROUP("T15", "Transaction Not Allowed in Transaction Group"),
	COUNTRY_CODE_VERIFICATION_FAILURE("T16", "Country Code Verification Failure"),
	RECORD_NOT_FOUND_IN_ISSUERBIN_REDIS("T17", "Record Not Found In IssuerBin Redis"),
	RECORD_NOT_FOUND_IN_ISSUERBIN("T18", "Record Not Found In IssuerBin"),
	AUTH_FLAG_ENUM_NOT_PRESENT("T19", "Auth Flag Enum Not Present"),
	TRANSACTION_KEY_EMPTY("T20", "Transaction Key is Empty"), DUAL_INTERFACE_MISMATCH("T21", "Dual Interface Mismatch"),
	LIMIT_VALIDATION_FAILURE("T22", "Limit Validation Failure"),
	ISSUER_SELECT_ID_EMPTY("T23", "Issuer Select Id is Empty"),
	NETWORK_MASTER_DATA_NOT_PRESENT_IN_REDIS("T24", "Network Master Data Not Present in Redis"),
	NETWORK_ID_NOT_PRESENT("T25", "Network Id Not Present"), INVALID_DR_CR_FLAG("T26", "Invalid C / D Flag"),
	LIMIT_MASTER_DATA_NOT_PRESENT_IN_REDIS("T27", "Limit Master Data Not Present in Redis"),
	CONFIGURATION_DATA_NOT_PRESENT("T28", "Configuration data not present"),
	SECURITY_INFO_NOT_PRESENT("T29", "Security Info Not Present In the Request"),
	INVALID_PROGRAM_ID("T30", "Invalid Program Id"),
	INTERNATIONAL_TRANSACTION_NOT_ALLOWED("T31", "International Transaction Not allowed"),
	DAILY_AMOUNT_LIMIT_EXCEEDED("T32", "Exceedes daily withdraw Limit"),
	DAILY_COUNT_LIMIT_EXCEEDED("T32", "Exceedes daily count Limit"),
	MONTHLY_AMOUNT_LIMIT_EXCEEDED("T32", "Exceedes monthly withdraw Limit"),
	MONTHLY_COUNT_LIMIT_EXCEEDED("T32", "Exceedes monthly count Limit"),
	TXN_DECLINED_CVV2_NOT_PRESENT("T33", "Ecom Transaction declined because cvv2 Value Not present"),
	CAVV_VERIFICATION_FAILURE("T44", "Cavv Verification Failure");

	@Getter
	String code;

	@Getter
	String message;

	private ResponseCodes(String code, String message) {
		this.code = code;
		this.message = message;
	}

}
