package money.open.cards.transaction.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class VerifyEMVDataDto {

	@NotBlank
	private String cardNumber;

	@NotBlank
	private String cardSeqNumber;

	@NotBlank
	private String authResponseCode;

	@Valid
	@NotNull
	private ChipDataDto cdolData;
}
