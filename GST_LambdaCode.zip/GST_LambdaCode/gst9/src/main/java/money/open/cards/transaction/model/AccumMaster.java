package money.open.cards.transaction.model;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;
import money.open.cards.transaction.utils.AbstractEntity;

@Entity
@Table(name = "accum_master")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder(toBuilder = true)
@ToString(callSuper = true)
public class AccumMaster extends AbstractEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long pkey;
	private String limitConfigId;
	private String partnerEntityId;
	private String entityId;
	private String entityType;
	private String countryMode;
	private String tpCode;
	private BigDecimal dailyLimit;
	private long dailyCount;
	private BigDecimal monthlyLimit;
	private long monthlyCount;
	private String channel;
	@JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd")
	private String lastTransactionDate;
}
