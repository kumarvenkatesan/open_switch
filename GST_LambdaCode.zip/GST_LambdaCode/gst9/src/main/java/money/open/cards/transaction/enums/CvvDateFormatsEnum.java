package money.open.cards.transaction.enums;

public enum CvvDateFormatsEnum {
	YYMM,MMYY;
}
