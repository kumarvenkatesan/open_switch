package money.open.cards.transaction.utils;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import money.open.cards.transaction.dto.TransactionRequestDto;
import money.open.cards.transaction.redis.dao.ProgramMasterRedisDao;
import money.open.cards.transaction.redis.model.ProgramMasterRedis;

@Service
public class ProgramMasterUtils {

	@Autowired
	ProgramMasterRedisDao programMasterRedisDao;

	public TransactionRequestDto setPartnerAndInst(TransactionRequestDto transactionRequestDto, Long programMasterId) {
		Optional<ProgramMasterRedis> programMaster = programMasterRedisDao.findById(programMasterId);
		if (programMaster.isPresent()) {
			transactionRequestDto.setPartnerEntityId(programMaster.get().getPartnerEntityId().getPartnerEntityId());
			transactionRequestDto.setIssuerInstitutionId(programMaster.get().getInstitutionId().getInstitutionId());
		}
		return transactionRequestDto;
	}
}
