package money.open.cards.transaction.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ExpiryDateValidationUtils {

	public Boolean expiryDateValidation(String expiryDate, String cardDetailsExpiryDate) {
		try {
			if (!expiryDate.equals(cardDetailsExpiryDate)) {
				return false;
			}

			SimpleDateFormat formatter = new SimpleDateFormat("yyMM", Locale.ENGLISH);
			Date reqDate = formatter.parse(expiryDate);
			Date currDate = new Date();
			if (currDate.compareTo(reqDate) < 0) {
				log.info("Card Expiry Validation Done");
				return true;
			} else {
				log.info("Card Expired");
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}
}
