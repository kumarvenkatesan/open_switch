package money.open.cards.transaction.dto;

import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DefaultKeyDto extends DefaultDataDto{
	
    @NotBlank
    private String networkKeyId;
    @NotBlank
    private String issuerKeyId;
}