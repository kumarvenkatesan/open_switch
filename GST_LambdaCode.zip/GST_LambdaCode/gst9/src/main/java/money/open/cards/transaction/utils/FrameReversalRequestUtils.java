package money.open.cards.transaction.utils;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.transaction.dto.TransactionRequestDto;
import money.open.cards.transaction.formatters.DateTimeFormat;

@Service
@Slf4j
public class FrameReversalRequestUtils {

	@Autowired
	TransactionKeyUtils transactionKeyUtils;

	@Autowired
	FrameResponseCodeUtils frameMti;

	@Autowired
	private DateTimeFormat dateTimeFormat;

	public TransactionRequestDto reversalRequestDto(TransactionRequestDto transactionRequestDto) {
		log.info("Framing Manual Reversal Request for original Transaction Key {} ",
				transactionRequestDto.getTransactionKey());
		transactionRequestDto.setMti("0420");
		transactionRequestDto.setOrgTxnKey(transactionRequestDto.getTransactionKey());
		transactionRequestDto.setOrgTxnDateTime(transactionRequestDto.getTranDateTime());
		transactionRequestDto.setApiRefNo(UUID.randomUUID().toString());
		transactionRequestDto.setReasonCode("Reversal Initiated");
		transactionRequestDto.setResponseCode(SwitchResponseCodes.APPROVED_OR_COMPLETED.getCode());
		transactionRequestDto.setTransactionStatus("P");
		return transactionKeyUtils.transactionKeyFormationData(transactionRequestDto);

	}

	public TransactionRequestDto splitOriginalDataElement(TransactionRequestDto transactionRequestDto) {
		transactionRequestDto.setOrgMti(transactionRequestDto.getOriginalDataElements().substring(0, 4));
		transactionRequestDto.setOrgStan(transactionRequestDto.getOriginalDataElements().substring(4, 10));
		if (!transactionRequestDto.getOriginalDataElements().substring(10, 20).equals("0000000000")) {
			transactionRequestDto.setOrgTxnDateTime(transactionRequestDto.getOriginalDataElements().substring(10, 20));
			transactionRequestDto
					.setOrgTransactionDate((dateTimeFormat.formatter(transactionRequestDto.getOrgTxnDateTime())));
		}

		transactionRequestDto.setOrgAcquirerId(transactionRequestDto.getOriginalDataElements().substring(20, 31));
//			transactionRequestDto
//					.setOrgForwardingInstIdCode((transactionRequestDto.getOriginalDataElements().substring(31, 42)));
		transactionRequestDto.setDrCrAmount(transactionRequestDto.getTransactionAmount());
		transactionRequestDto.setOrgTxnKey(transactionRequestDto.getOrgMti() + transactionRequestDto.getOrgStan()
				+ transactionRequestDto.getOrgTxnDateTime() + transactionRequestDto.getOrgAcquirerId());
		return transactionRequestDto;
	}
}
