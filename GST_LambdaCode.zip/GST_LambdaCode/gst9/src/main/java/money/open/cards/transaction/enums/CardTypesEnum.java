package money.open.cards.transaction.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum CardTypesEnum {
	P("PHYSICAL"),V("VIRTUAL");
	@Getter
	String value;
}
