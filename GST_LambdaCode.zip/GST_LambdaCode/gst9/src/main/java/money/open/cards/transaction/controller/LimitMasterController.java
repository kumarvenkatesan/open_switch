package money.open.cards.transaction.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.transaction.dto.LimitMasterDto;
import money.open.cards.transaction.service.LimitService;
import money.open.cards.transaction.utils.ResponseCodes;
import money.open.cards.transaction.utils.TransactionException;
import money.open.cards.transaction.utils.TransactionResponse;

@RestController
@RequestMapping(value = "/tran")
@Slf4j
public class LimitMasterController {

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	LimitService limitService;

	@PostMapping("/limitUpdate")
	public TransactionResponse limitUpdate(@Valid @RequestBody List<LimitMasterDto> cardUpdaterDto)
			throws TransactionException {
		try {
			log.info("Post Method Limit Updater Request Dto {} ", objectMapper.writeValueAsString(cardUpdaterDto));
			return limitService.updateLimitMaster(cardUpdaterDto);
		} catch (Exception e) {
			return new TransactionResponse(null, ResponseCodes.FAILURE.getCode(), e.getMessage());
		}
	}

}
