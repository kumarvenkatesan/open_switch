package money.open.cards.transaction.repository;

import java.time.LocalDateTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import money.open.cards.transaction.model.CardMaster;

public interface CardMasterRepository extends JpaRepository<CardMaster, String>{
	
	CardMaster findByCardNumberAndProxyCardNumber(String cardNumber, String kitNo);
	
	CardMaster findByProxyCardNumber(String kitNo);
	
	CardMaster findByCardNumber(String hashCardNumber);
	
	@Modifying
	@Query("update CardMaster u set u.pinRetryCount = :pinRetryCount, u.status= :status, u.pinBlockedDate=:pinBlockedDate where u.proxyCardNumber = :proxyCardNumber")
	void updateStatusAndCount(@Param(value = "pinRetryCount") Integer pinRetryCount,@Param(value = "status") String status, @Param(value = "pinBlockedDate") LocalDateTime pinBlockedDate,@Param(value = "proxyCardNumber") String proxyCardNumber );
	
	
	@Modifying
	@Query("update CardMaster u set u.dcvvFlag = :dcvvFlag where u.proxyCardNumber = :proxyCardNumber")
	void updateDcvvFlag(@Param(value = "dcvvFlag") String dcvvFlag,@Param(value = "proxyCardNumber") String proxyCardNumber );
}
