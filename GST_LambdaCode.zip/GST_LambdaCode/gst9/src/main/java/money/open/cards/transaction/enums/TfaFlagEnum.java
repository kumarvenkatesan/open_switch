package money.open.cards.transaction.enums;

public enum TfaFlagEnum {
	Y,N
}
