package money.open.cards.transaction.dto;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.ToString;

@Data
@JsonIgnoreProperties()
@ToString(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LimitMasterDto {

	private long pkey;
	private String limitConfigId;
	private String partnerEntityId;
	private String entityId;
	private String entityType;
	private String countryMode;
	private String tpCode;
	private BigDecimal dailyLimit;
	private long dailyCount;
	private BigDecimal monthlyLimit;
	private long monthlyCount;
	private String channel;
	private String status;
}
