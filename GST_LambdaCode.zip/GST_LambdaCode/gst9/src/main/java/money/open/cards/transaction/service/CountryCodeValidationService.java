package money.open.cards.transaction.service;

import money.open.cards.transaction.dto.TransactionRequestDto;

public interface CountryCodeValidationService {

	TransactionRequestDto validateCountryCode(int countryCode, String issuerBin,
			TransactionRequestDto transactionRequestDto, String cardCountryMode);
}
