package money.open.cards.transaction.utils;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ReverseDrCrFlag {

	public String getReverseDrCrFlag(String drCrFlag) {
		log.info("Get the Reverse DrCrFlag for {}", drCrFlag);
		if (drCrFlag.equals("D")) {
			drCrFlag = "C";
			return drCrFlag;
		}

		if (drCrFlag.equals("C"))
			drCrFlag = "D";
		return drCrFlag;
	}
}
