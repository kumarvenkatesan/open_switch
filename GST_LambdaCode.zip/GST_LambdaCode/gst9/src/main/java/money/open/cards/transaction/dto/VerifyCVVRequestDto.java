package money.open.cards.transaction.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Validated
public class VerifyCVVRequestDto {

    @Valid
    @NotNull
    private DefaultKeyDto defaultData;

    @NotNull @Valid
    private VerifyCVVServiceDataDto serviceData;




}
