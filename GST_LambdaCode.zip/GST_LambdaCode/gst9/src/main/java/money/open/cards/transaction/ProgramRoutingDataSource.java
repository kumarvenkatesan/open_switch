package money.open.cards.transaction;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import money.open.cards.transaction.utils.DataSourceLookupException;
import money.open.cards.transaction.utils.ResponseCodes;

import javax.sql.DataSource;

public class ProgramRoutingDataSource extends AbstractRoutingDataSource {
    @Override
    protected Object determineCurrentLookupKey() {
        return ProgramContextHolder.getProgram();
    }

    @Override
    protected DataSource determineTargetDataSource() {
        try {
            return super.determineTargetDataSource();
        } catch (IllegalStateException e){
            throw new DataSourceLookupException(ResponseCodes.INVALID_PROGRAM_ID);
        }
    }
}
