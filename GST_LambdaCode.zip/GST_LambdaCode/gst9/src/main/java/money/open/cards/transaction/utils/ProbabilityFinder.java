package money.open.cards.transaction.utils;

public class ProbabilityFinder {

	private static final float STAR_PRIORITY = 0.5f;

	public float findProbability(String value, String anotherValue, float priority) {
		if (value.equals(anotherValue)) {
			return priority;
		} else if (value.equals("*")) {
			return STAR_PRIORITY;
		}
		return -1f;
	}
}
