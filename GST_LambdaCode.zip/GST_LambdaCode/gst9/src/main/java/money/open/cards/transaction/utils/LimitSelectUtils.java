package money.open.cards.transaction.utils;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.transaction.enums.CountryModesEnum;
import money.open.cards.transaction.model.LimitMaster;
import money.open.cards.transaction.redis.dao.LimitMasterRedisDao;
import money.open.cards.transaction.redis.model.LimitMasterRedis;
import money.open.cards.transaction.repository.LimitMasterRepository;

@Slf4j
@Service
public class LimitSelectUtils {

	@Autowired
	private LimitMasterRedisDao limitMasterRedisDao;

	@Autowired
	private LimitMasterRepository limitMasterDao;

	private static final float STAR_PRIORITY = 0.5f;

	public LimitMasterRedis fetchLimitMasterDefaultRow(String limitConfigId, String partnerEntityId, String entityId,
			String entityType, CountryModesEnum dOrI, String tpCode, String channelType) {

		if (channelType.equals("ATM") && tpCode.equals("00")) {
			log.info("ATM and tp Code mismatch");
			return null;
		}

		if (!limitConfigId.equalsIgnoreCase("DEFAULT")) {
			log.info("Limit Config Id is not {}", limitConfigId);
		}

		List<LimitMasterRedis> limitMasterRedis = limitMasterRedisDao
				.findByPartnerEntityIdAndEntityIdAndEntityTypeAndStatusAndTpCode(partnerEntityId, entityId, entityType,
						"A", tpCode);

		if (limitMasterRedis.isEmpty()) {
			log.info("Redis Data Not Found in Limit Master");
			return null;
		}

		float masterMatchProbability = 0;
		float countryModePriority;
		float channelTypePriority;
		countryModePriority = channelTypePriority = 1f;
		LimitMasterRedis filteredLimitMasterRedis = null;

		for (LimitMasterRedis tranKeyData : limitMasterRedis) {
			float currentMatchProbability = 0f;

			float countryModeProbability = this.findProbability(tranKeyData.getCountryMode(), dOrI.getValue(),
					countryModePriority);
			if (countryModeProbability < 0)
				continue;
			else
				currentMatchProbability = currentMatchProbability + countryModeProbability;

			float channelTypeProbability = this.findProbability(tranKeyData.getChannel(), channelType,
					channelTypePriority);
			if (channelTypeProbability < 0)
				continue;
			else
				currentMatchProbability = currentMatchProbability + channelTypeProbability;

			if (currentMatchProbability > masterMatchProbability) {
				masterMatchProbability = currentMatchProbability;
				filteredLimitMasterRedis = tranKeyData;
			}
		}

		if (filteredLimitMasterRedis == null) {
			log.info("Transaction Key Data not Found in Transaction Key Redis");
			return null;
		}

		return filteredLimitMasterRedis;
	}

//			if (limitMasterRedis.size() > 3) {
//				List<LimitMasterRedis> limitMaster = limitMasterRedis.stream()
//						.filter(p -> (p.getPartnerEntityId().equals(partnerEntityId) && p.getEntityId().equals(entityId)
//								&& p.getEntityType().equals(entityType) && p.getTpCode().equals(tpCode)
//								&& p.getCountryMode().equals(dOrI.getValue())))
//						.collect(Collectors.toList());
//				if (!limitMaster.isEmpty()) {
//					List<LimitMasterRedis> limitMaster1 = limitMaster.stream()
//							.filter(p -> (p.getPartnerEntityId().equals(partnerEntityId)
//									&& p.getEntityId().equals(entityId) && p.getEntityType().equals(entityType)
//									&& p.getTpCode().equals(tpCode) && p.getCountryMode().equals(dOrI.getValue())
//									&& p.getChannel().equals(channelType)))
//							.collect(Collectors.toList());
//					if (!limitMaster1.isEmpty()) {
//						return limitMaster1.get(0);
//					} else {
//						List<LimitMasterRedis> limitMasterWithChannel = limitMaster.stream()
//								.filter(p -> (p.getPartnerEntityId().equals(partnerEntityId)
//										&& p.getEntityId().equals(entityId) && p.getEntityType().equals(entityType)
//										&& p.getTpCode().equals(tpCode) && p.getCountryMode().equals(dOrI.getValue())
//										&& p.getChannel().equals("*")))
//								.collect(Collectors.toList());
//						if (!limitMasterWithChannel.isEmpty()) {
//							limitMasterWithChannel.get(0).setChannel(channelType);
//							return limitMasterWithChannel.get(0);
//						} else {
//							log.info("Data Not Found");
//							return null;
//						}
//					}
//				} else {
//					log.info("Configuration mismatch");
//					return null;
//				}
//			} else {
//				List<LimitMasterRedis> limitMaster = limitMasterRedis.stream()
//						.filter(p -> (p.getPartnerEntityId().equals(partnerEntityId) && p.getEntityId().equals(entityId)
//								&& p.getEntityType().equals(entityType) && p.getTpCode().equals(tpCode)
//								&& p.getCountryMode().equals("*")))
//						.collect(Collectors.toList());
//				if (!limitMaster.isEmpty()) {
//					List<LimitMasterRedis> limitMaster1 = limitMaster.stream()
//							.filter(p -> (p.getPartnerEntityId().equals(partnerEntityId)
//									&& p.getEntityId().equals(entityId) && p.getEntityType().equals(entityType)
//									&& p.getTpCode().equals(tpCode) && p.getCountryMode().equals("*")
//									&& p.getChannel().equals(channelType)))
//							.collect(Collectors.toList());
//					if (!limitMaster1.isEmpty()) {
//						limitMaster1.get(0).setCountryMode(dOrI.getValue());
//						return limitMaster1.get(0);
//					} else {
//						List<LimitMasterRedis> limitMasterWithChannel = limitMaster.stream()
//								.filter(p -> (p.getPartnerEntityId().equals(partnerEntityId)
//										&& p.getEntityId().equals(entityId) && p.getEntityType().equals(entityType)
//										&& p.getTpCode().equals(tpCode) && p.getCountryMode().equals("*")
//										&& p.getChannel().equals("*")))
//								.collect(Collectors.toList());
//						if (!limitMasterWithChannel.isEmpty()) {
//							limitMasterWithChannel.get(0).setCountryMode(dOrI.getValue());
//							return limitMasterWithChannel.get(0);
//						} else {
//							log.info("Data Not Found");
//							return null;
//						}
//					}
//				} else {
//					log.info("Configuration mismatch");
//					return null;
//				}
//			}
//		} else {
//			log.info("Default String mismatch");
//			return null;
//		}
//	}

	public LimitMaster fetchLimitMasterCustomRow(String limitConfigId, String partnerEntityId, String entityId,
			String entityType, CountryModesEnum dOrI, String tpCode, String channelType) {

		if (!limitConfigId.equalsIgnoreCase("CUSTOM")) {
			log.info("Default String mismatch");
			return null;
		}

		List<LimitMaster> limitMaster = limitMasterDao.findByPartnerEntityIdAndEntityIdAndEntityTypeAndTpCodeAndStatus(
				partnerEntityId, entityId, entityType, tpCode, "A");

		if (limitMaster.isEmpty()) {
			log.info("Redis Data Not Found in Limit Master");
			return null;
		}

		float masterMatchProbability = 0;
		float countryModePriority;
		float channelTypePriority;
		countryModePriority = channelTypePriority = 1f;
		LimitMaster filteredLimitMaster = null;

		for (LimitMaster limitMasterData : limitMaster) {
			float currentMatchProbability = 0f;

			float countryModeProbability = this.findProbability(limitMasterData.getCountryMode(), dOrI.getValue(),
					countryModePriority);
			if (countryModeProbability < 0)
				continue;
			else
				currentMatchProbability = currentMatchProbability + countryModeProbability;

			float channelTypeProbability = this.findProbability(limitMasterData.getChannel(), channelType,
					channelTypePriority);
			if (channelTypeProbability < 0)
				continue;
			else
				currentMatchProbability = currentMatchProbability + channelTypeProbability;

			if (currentMatchProbability > masterMatchProbability) {
				masterMatchProbability = currentMatchProbability;
				filteredLimitMaster = limitMasterData;
			}
		}

		if (filteredLimitMaster == null) {
			log.info("Transaction Key Data not Found in Transaction Key Redis");
			return null;
		}

		return filteredLimitMaster;
	}

	public float findProbability(String value, String anotherValue, float priority) {
		if (value.equals(anotherValue)) {
			return priority;
		} else if (value.equals("*")) {
			return STAR_PRIORITY;
		}
		return -1f;
	}
}

//		if (limitConfigId.equalsIgnoreCase("CUSTOM")) {
//			List<LimitMaster> limitMasterRedis = limitMasterDao
//					.findByPartnerEntityIdAndEntityIdAndEntityTypeAndTpCodeAndStatus(partnerEntityId, entityId,
//							entityType, tpCode, "A");
//			if (limitMasterRedis.size() > 3) {
//				List<LimitMaster> limitMaster = limitMasterRedis.stream()
//						.filter(p -> (p.getPartnerEntityId().equals(partnerEntityId) && p.getEntityId().equals(entityId)
//								&& p.getEntityType().equals(entityType) && p.getTpCode().equals(tpCode)
//								&& p.getCountryMode().equals(dOrI.getValue())))
//						.collect(Collectors.toList());
//				if (!limitMaster.isEmpty()) {
//					List<LimitMaster> limitMaster1 = limitMaster.stream()
//							.filter(p -> (p.getPartnerEntityId().equals(partnerEntityId)
//									&& p.getEntityId().equals(entityId) && p.getEntityType().equals(entityType)
//									&& p.getTpCode().equals(tpCode) && p.getCountryMode().equals(dOrI.getValue())
//									&& p.getChannel().equals(channelType)))
//							.collect(Collectors.toList());
//					if (!limitMaster1.isEmpty()) {
//						return limitMaster1.get(0);
//					} else {
//						List<LimitMaster> limitMasterWithChannel = limitMaster.stream()
//								.filter(p -> (p.getPartnerEntityId().equals(partnerEntityId)
//										&& p.getEntityId().equals(entityId) && p.getEntityType().equals(entityType)
//										&& p.getTpCode().equals(tpCode) && p.getCountryMode().equals(dOrI.getValue())
//										&& p.getChannel().equals("*")))
//								.collect(Collectors.toList());
//						if (limitMasterWithChannel.isEmpty()) {
//							limitMasterWithChannel.get(0).setChannel(channelType);
//							return limitMasterWithChannel.get(0);
//						} else {
//							log.info("Data Not Found");
//							return null;
//						}
//					}
//				} else {
//					log.info("Configuration mismatch");
//					return null;
//				}
//			} else {
//				List<LimitMaster> limitMaster = limitMasterRedis.stream()
//						.filter(p -> (p.getPartnerEntityId().equals(partnerEntityId) && p.getEntityId().equals(entityId)
//								&& p.getEntityType().equals(entityType) && p.getTpCode().equals(tpCode)
//								&& p.getCountryMode().equals(CountryModesEnum.STAR.getValue())))
//						.collect(Collectors.toList());
//				if (!limitMaster.isEmpty()) {
//					List<LimitMaster> limitMaster1 = limitMaster.stream()
//							.filter(p -> (p.getPartnerEntityId().equals(partnerEntityId)
//									&& p.getEntityId().equals(entityId) && p.getEntityType().equals(entityType)
//									&& p.getTpCode().equals(tpCode)
//									&& p.getCountryMode().equals(CountryModesEnum.STAR.getValue())
//									&& p.getChannel().equals(channelType)))
//							.collect(Collectors.toList());
//					if (!limitMaster1.isEmpty()) {
//						limitMaster1.get(0).setCountryMode(dOrI.getValue());
//						return limitMaster1.get(0);
//					} else {
//						List<LimitMaster> limitMasterWithChannel = limitMaster.stream()
//								.filter(p -> (p.getPartnerEntityId().equals(partnerEntityId)
//										&& p.getEntityId().equals(entityId) && p.getEntityType().equals(entityType)
//										&& p.getTpCode().equals(tpCode)
//										&& p.getCountryMode().equals(CountryModesEnum.STAR.getValue())
//										&& p.getChannel().equals("*")))
//								.collect(Collectors.toList());
//						if (limitMasterWithChannel.isEmpty()) {
//							limitMasterWithChannel.get(0).setCountryMode(dOrI.getValue());
//							limitMasterWithChannel.get(0).setChannel(channelType);
//							return limitMasterWithChannel.get(0);
//						} else {
//							log.info("Data Not Found");
//							return null;
//						}
//					}
//				} else {
//					log.info("Configuration mismatch");
//					return null;
//				}
//			}
//		} else {
//			log.info("Default String mismatch");
//			return null;
//		}
