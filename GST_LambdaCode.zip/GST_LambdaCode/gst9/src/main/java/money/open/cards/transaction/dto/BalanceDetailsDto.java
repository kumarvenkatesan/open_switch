package money.open.cards.transaction.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class BalanceDetailsDto {

	private String accountType;
	private String amountType;
	private String currencyCode;
	private char signAmount;
	private BigDecimal availableBalance;
}
