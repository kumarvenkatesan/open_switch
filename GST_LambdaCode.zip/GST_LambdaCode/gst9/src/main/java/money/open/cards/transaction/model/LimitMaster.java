package money.open.cards.transaction.model;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import money.open.cards.transaction.utils.AbstractEntity;

@Entity
@Table(name = "limit_master")
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@DynamicUpdate
public class LimitMaster extends AbstractEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long pkey;
	private String limitConfigId;
	private String partnerEntityId;
	private String entityId;
	private String entityType;
	private String countryMode;
	private String tpCode;
	private BigDecimal dailyLimit;
	private long dailyCount;
	private BigDecimal monthlyLimit;
	private long monthlyCount;
	private String channel;
	private String currencyMode;
	private String status;
}
