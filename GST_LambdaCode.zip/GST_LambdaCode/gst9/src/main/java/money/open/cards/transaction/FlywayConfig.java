package money.open.cards.transaction;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.zaxxer.hikari.HikariDataSource;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.transaction.utils.CommonUtils;

@Component
@Slf4j
public class FlywayConfig {
	
    @Autowired
    private TransactionConfig transactionConfig;

    @PostConstruct
    public void afterPropertiesSet() throws Exception {

        Map<String, String> map = new HashMap<>();
        LocalDate d1 = LocalDate.now();
        LocalDate startDate = d1.withDayOfMonth(1);
        LocalDate endDate = d1.withDayOfMonth(d1.lengthOfMonth());

        map.put("date", d1.format(CommonUtils.DATE_MMYYYY));
        map.put("start_date", startDate.format(CommonUtils.DATE_YYYY_MM_DD));
        map.put("end_date", endDate.format(CommonUtils.DATE_YYYY_MM_DD));

        for (Map.Entry<Object, Object> entry : transactionConfig.getAvailableDataSources().entrySet()) {
            log.info("Running flyway migrations for program key {} :: ", entry.getKey());
            HikariDataSource hikariDataSource = (HikariDataSource) entry.getValue();
            Flyway.configure().baselineOnMigrate(true).baselineVersion("0.0").schemas(hikariDataSource.getSchema())
                    .defaultSchema(hikariDataSource.getSchema()).dataSource(hikariDataSource).locations("classpath:db/migration")
                    .placeholders(map).load().migrate();
        }
    }

}
