package money.open.cards.transaction.enums;

import lombok.Getter;

public enum Cvv2ResultCodeEnum {

	CVV2_NOT_PROCESSED("P"), CVV2_NOT_MATCHED("N"), CVV2_MATCHED("M");

	@Getter
	String code;

	private Cvv2ResultCodeEnum(String code) {
		this.code = code;
	}
}
