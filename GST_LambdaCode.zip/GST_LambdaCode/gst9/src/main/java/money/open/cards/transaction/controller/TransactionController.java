package money.open.cards.transaction.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.transaction.dto.TransactionRequestDto;
import money.open.cards.transaction.service.TransactionSplitService;
import money.open.cards.transaction.utils.ResponseCodes;
import money.open.cards.transaction.utils.TransactionException;
import money.open.cards.transaction.utils.TransactionResponse;

@RestController
@RequestMapping(value = "/tran")
@Slf4j
public class TransactionController {

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	private TransactionSplitService transactionSplitService;

	@PostMapping("/authTransaction")
	public TransactionResponse cardUpdater(@RequestBody TransactionRequestDto transactionRequestDto)
			throws TransactionException {
		try {
			log.info("Post Transaction Request Dto {} ", objectMapper.writeValueAsString(transactionRequestDto));
			if (transactionRequestDto.getSettlementConversionRate() == null) {
				transactionRequestDto.setSettlementConversionRate("0.000000");
				transactionRequestDto.setBillingConversionRate("0.00000");
				transactionRequestDto.setSettlementCurrencyCode("356");
				transactionRequestDto.setBillingCurrencyCode("356");
			}
			TransactionRequestDto tranResponse = transactionSplitService.splitTransaction(transactionRequestDto);
			TransactionResponse responseDto = new TransactionResponse();
			responseDto.setResult(tranResponse);
			return responseDto;
		} catch (JsonProcessingException e) {
			return new TransactionResponse(null, ResponseCodes.FAILURE.getCode(), e.getMessage());
		}
	}

}
