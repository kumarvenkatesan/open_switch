package money.open.cards.transaction.utils;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.transaction.dto.TransactionRequestDto;
import money.open.cards.transaction.redis.dao.NetworkSelectRedisDao;
import money.open.cards.transaction.redis.model.NetworkSelectRedis;

@Slf4j
@Service
public class NetworkSelectUtils {

	@Autowired
	private NetworkSelectRedisDao networkSelectRedisDao;

	public String networkSelectRedisData(TransactionRequestDto transactionRequestDto, String issuerSelectId) {

		String acquirerId = transactionRequestDto.getAcquirerId();
		String cardProduct = StringUtils.isEmpty(transactionRequestDto.getCardProduct()) ? "*"
				: transactionRequestDto.getCardProduct();

		String channelType = transactionRequestDto.getChannelType();
		String mti = transactionRequestDto.getMti();
		String tpCode = transactionRequestDto.getTpCode();

		if (StringUtils.isNotEmpty(acquirerId) && StringUtils.isNotEmpty(issuerSelectId)) {
			List<NetworkSelectRedis> networkSelectData = networkSelectRedisDao.findByAcquirerIdAndIssuerId(acquirerId,
					issuerSelectId);

			for (int i = 0; i < networkSelectData.size(); i++) {
				if (networkSelectData.get(i).getCardProduct().equals(cardProduct)) {
					log.info("CardProduct :: {}", cardProduct);
					return this.fetchNetworkIdByChannelType(networkSelectData.get(i), channelType, mti, tpCode);
				} else if (networkSelectData.get(i).getCardProduct().equals("*")) {
					log.info("CardProduct :: {}", "*");
					return this.fetchNetworkIdByChannelType(networkSelectData.get(i), channelType, mti, tpCode);
				}
			}
		}
		return null;
	}

	public String fetchNetworkIdByChannelType(NetworkSelectRedis networkSelectData, String channelType, String mti,
			String tpCode) {
		if (networkSelectData.getChannelType().equals(channelType)) {
			log.info("Channel Type :: {}", channelType);
			return this.fetchNetworkIdByMti(networkSelectData, mti, tpCode);
		} else if (networkSelectData.getChannelType().equals("*")) {
			log.info("Channel Type :: {}", "*");
			return this.fetchNetworkIdByMti(networkSelectData, mti, tpCode);
		} else {
			log.info("No ChannelType Found");
			return null;
		}
	}

	public String fetchNetworkIdByMti(NetworkSelectRedis networkSelectData, String mti, String tpCode) {
		if (networkSelectData.getMti().equals(mti)) {
			log.info("Mti :: {}", mti);
			return this.fetchNetworkIdByTpCode(networkSelectData, tpCode);
		} else if (networkSelectData.getMti().equals("*")) {
			log.info("Mti :: {}", "*");
			return this.fetchNetworkIdByTpCode(networkSelectData, tpCode);
		} else {
			log.info("No Mti Found");
			return null;
		}
	}

	public String fetchNetworkIdByTpCode(NetworkSelectRedis networkSelectData, String requestTpCode) {
		if (networkSelectData.getTpCode().length() == 2
				&& networkSelectData.getTpCode().substring(0, 2).equals(requestTpCode)) {
			log.info("Tp Code :: {}", requestTpCode.substring(0, 2));
			return networkSelectData.getNetworkId();
		} else if (networkSelectData.getTpCode().length() == 6
				&& networkSelectData.getTpCode().substring(0, 6).equals(requestTpCode)) {
			log.info("Tp Code :: {}", requestTpCode.substring(0, 6));
			return networkSelectData.getNetworkId();
		} else if (networkSelectData.getTpCode().equals("*")) {
			log.info("Tp Code :: {}", "*");
			return networkSelectData.getNetworkId();
		} else {
			log.info("Tp Code MisMatch");
			return null;

		}
	}
}
