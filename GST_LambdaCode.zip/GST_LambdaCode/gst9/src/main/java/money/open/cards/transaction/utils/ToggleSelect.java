package money.open.cards.transaction.utils;

public enum ToggleSelect {
	Y,N;
}
