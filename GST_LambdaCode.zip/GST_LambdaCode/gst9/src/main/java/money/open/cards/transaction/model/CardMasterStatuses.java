package money.open.cards.transaction.model;

import java.util.HashMap;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum CardMasterStatuses {

	CARD_GENERATED_UNREGISTERED("10", "Card generated. Customer un-registered"), CARD_GENERATED("11", "Card generated"),
	CARD_EMBOSS_FAILED("12", "Card embossing failed"),
	CARD_EMBOSS_FAILED_UNREGISTERED("13", "Card embossing failed. Card Un-registered"),
	CARD_EMBOSS_INPROGRESS_UNREGISTERED("14", "Card embossing in-progress. Card un-registered"),
	CARD_EMBOSS_INPROGRESS("15", "Card Embossing in-progress"), CARD_EMBOSSED("16", "Card embossed"),
	CARD_EMBOSSED_UNREGISTERED("17", "Card embossed. Customer unregistered"),
	CARD_ISSUE_FAILED("18", "Card issue failed"), CARD_ISSUED("00", "Card issued"),
	CARD_ACTIVATED("01", "Card Activated"), CARD_CLOSE("02", "Card Closed"),
	CARD_TEMP_BLOCKED("03", "Temporarily Blocked"), CARD_PERMANENT_BLOCKED("04", "Permanently Blocked"),
	CARD_REISSUED("05", "Card Reissued"), CARD_TEMP_BLOCKED_PIN_EXCEEDED("06", "Temporarily blocked by Pin Exceeded"),
	CARD_DORMANT("07", "Dormant Card"), CARD_PICKUP("08", "PickUp Card"), CARD_EXPIRED_CARD("09", "Expired Card"),
	CARD_STOLEN("10", "Stolen Card"), CARD_LOST("11", "Lost Card"), CARD_SUSPECTED_FRAUD("12", "Suspected Fraud");

	final String value;
	final String message;
	public static final Map<String, CardMasterStatuses> map = new HashMap<>();

	static {
		for (CardMasterStatuses c : CardMasterStatuses.values()) {
			map.put(c.getValue(), c);
		}
	}
}
