package money.open.cards.transaction.utils;

import lombok.Getter;

public enum SwitchResponseCodes {

	APPROVED_OR_COMPLETED("00", "Success Transaction", "B"), REFER_TO_CARD_ISSUER("01", "Refer to Card Issuer", "B"),
	REFER_TO_CARD_ISSUER_SPECIAL_CONDITION("02", "Refer to Card Issuer Special condition", "B"),
	INVALID_MERCHANT("03", "Invalid Merchant", "B"), CAPTURE_CARD("07", "Capture Card", "B"),
	DO_NOT_HONOR("05", "Do Not Honor", "B"), BLOCKED_CARD("05", "Blocked Card", "B"),
	DORMANT_CARD("05", "Dormant Card", "B"), ERROR("06", "Error", "B"), PICKUP_CARD("04", "PickUp Card", "B"),
	PARTIAL_APPROVAL("10", "Partial Approval", "B"), V_I_P_APPROVAL("11", "VIP Approval", "B"),
	INVALID_TRANSACTION("12", "Invalid Transaction", "B"), INVALID_AMOUNT("13", "Invalid Amount", "B"),
	INVALID_CARD_OR_ACCOUNT_NUMBER("14", "Invalid Account Number", "B"), INVALID_ISSUER("15", "No Such Issuer", "B"),
	REENTER_TRANSACTION("19", "ReEnter Transaction", "B"), NO_ACTION_TAKEN("21", "No Action Taken", "B"),
	UNABLE_TO_LOCATE_RECORD("25", "Unable to locate Record / Account Number is missing from inquiry", "B"),
	FILE_TEMP_UNAVAILABLE("28", "File is Temporarily Unavailable", "B"),
	INVALID_CREDIT_ACCOUNT("39", "No Credit Account", "B"), LOST_CARD("41", "Lost Card", "B"),
	STOLEN_CARD("43", "Stolen Card", "B"),
	INSUFFICIENT_BALANCE_OR_OVER_CREDIT_LIMIT("51", "Insufficient Balance Or Over Credit Limit", "B"),
	INVALID_CHECKING_ACCOUNT("52", "No Checking Account", "B"),
	INVALID_SAVINGS_ACCOUNT("53", "No Savings Account", "B"), EXPIRED_CARD("54", "Invalid Card", "B"),
	INVALID_PIN("55", "Invalid Pin", "B"), TRANSACTION_NOT_PERMITTED("57", "Transaction Not Permitted", "B"),
	TRANSACTION_NOT_PERMITTED_TO_TERMINAL("58", "Transaction Not Permitted to Terminal", "B"),
	SUSPECTED_FRAUD("59", "Suspected Fraud", "B"), AMOUNT_LIMIT_EXCEEDED("61", "Amount Limit Exceeded", "B"),
	RESTRICTED_CARD("62", "Resticted Card", "B"), SECURITY_VIOLATION("63", "Security Violation", "B"),
	TRANSACTION_NOT_FULFILL_AML_REQ("64", "Transaction does not fulfill AML requirement", "B"),
	EXCEED_WITHDRAWL_COUNT_LIMIT("65", "Activity Count Limit Exceeded", "B"), // Daily Transaction Count
	PIN_TRY_LIMIT_EXCEEDS("75", "Pin Try Limit Exceeds", "B"), RRN_MISMATCH("76", "RRN mismatch", "B"),
	REVESAL_DATA_INSCONSISTENT("77",
			"Previous message located for a repeat or reversal, but repeat or reversal data are inconsistent with original message",
			"B"),
	BLOCKED_FIRST_USED("78", "The transaction is from a new cardholder, and the card has not been properly unblocked",
			"B"),
	TRANSACTION_ALREADY_REVERSED("79", "Transaction already Reversed", "B"),
	CREDIT_ISSUER_UNAVAILABLE("80", "Credit issuer unavailable. Private label and check acceptance: Invalid date", "B"),
	PIN_CRYPTOGRAPHY_ERROR("81",
			"PIN cryptographic error found (error found by VIC security module during PIN decryption)", "B"),
	NEGATIVE_ONLINE("82", "Negative Online CAM, dCVV, iCVV, or CVV results", "B"),
	// to be done
	BENEFICIARY_LIMIT_HOLD_REACHED("83", "Beneficiary Limit Hold Reached", "B"),
	INVALID_AUTHORIZATION_LIFE_CYCLE("84", "Invalid Authorizatio Life Cycle", "B"),
	NOT_DECLINED("85", "Account Number Verification Not Declined", "B"),
	PIN_VALIDATION_NOTPOSSIBLE("86", "Pin Validation Not Possible", "B"),
	PURCHASE_AMOUNT_ONLY("87", "Purchase Amount Only", "B"), CRYPTOGRAPHIC_FEATURE("88", "Cryptographic Feature", "B"),
	UNACCEPTABLE_PIN_TRANSACTION_DECLINED("89", "Unacceptable Pin Transaction Declined", "B"),
	ISSUER_SYSTEM_INOPERATIVE("91", "Issuer System Inoperative", "B"),
	UNABLE_TO_ROUTE_TRANSACTION("92", "Unable to Route Transaction", "B"),
	DUPLICATE_TRANSACTION_DETECTED("94", "Duplicate Transaction Detected", "B"),
	LOYALTY_FAILED("93", "Loyalty Failed", "B"), SYSTEM_ERROR("96", "System Error", "S"),
	INVALID_CREDIT_ACCOUNT_POS("T8", "Invalid Credit Account ", "B"),
	ARQC_VERIFICATION_FAILURE("E3", "ARQC Verification Failure", "B"),
	TVR_VERIFICATION_FAILURE("E4", "TVR Verification Failure", "B"),
	CVR_VERIFICATION_FAILURE("E5", "CVR Verification Failure", "B");

	@Getter
	String code;

	@Getter
	String message;

	@Getter
	String type;

	private SwitchResponseCodes(String code, String message, String type) {
		this.code = code;
		this.message = message;
		this.type = type;
	}
}
