package money.open.cards.transaction.enums;

import lombok.Getter;

public enum CountryModesEnum {
	 	D("D"),
	 	I("I"),
	   	STAR("*");

	@Getter
	private String value;
	
	private CountryModesEnum(String value) {
		this.value = value;
	}
}
