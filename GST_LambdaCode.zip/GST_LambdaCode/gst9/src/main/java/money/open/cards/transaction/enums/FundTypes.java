package money.open.cards.transaction.enums;

import lombok.Getter;

@Getter
public enum FundTypes {
	AMOUNT("Transaction amount",'A',"amount"),FEE("Transaction fee",'F',"feeAmount"),INTEREST("Transaction interest",'I',"interestAmount");
	
	String description;
	Character code;
	String field;
	
	private FundTypes(String description, Character code,String field) {
		this.description = description;
		this.code = code;
		this.field = field;
	}
}
