package money.open.cards.transaction.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class InfDataDto {
	private String authCharIndicator; // incremental transaction -- I
	private String tranId;
	private String marketSpecDataId;
	private String duration;
}
