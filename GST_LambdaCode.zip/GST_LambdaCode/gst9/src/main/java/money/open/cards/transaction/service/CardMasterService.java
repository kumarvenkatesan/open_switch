package money.open.cards.transaction.service;

import java.util.Map;

import money.open.cards.transaction.dto.CardMasterDto;
import money.open.cards.transaction.model.CardMaster;
import money.open.cards.transaction.utils.TransactionException;
import money.open.cards.transaction.utils.TransactionResponse;

public interface CardMasterService {

	TransactionResponse postCardUpdater(CardMasterDto cardMasterDto) throws TransactionException;

	TransactionResponse patchCardUpdater(String proxyCardNumber, Map<String, Object> patchFields)
			throws TransactionException;

	TransactionResponse getCardMasterDetails(String kitNo) throws TransactionException;

	CardMaster validateCardMaster(String hashedCardNumber, String pinResetMode, int pinResetInterval)
			throws TransactionException;
}
