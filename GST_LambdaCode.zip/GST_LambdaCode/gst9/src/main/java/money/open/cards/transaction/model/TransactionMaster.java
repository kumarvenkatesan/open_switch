package money.open.cards.transaction.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import money.open.cards.transaction.utils.AbstractEntity;

@Entity
@Table(name = "transaction_master")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class TransactionMaster extends AbstractEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "transaction_seq", nullable = false)
	private Long transactionSeq;

	@Column(name = "mti", nullable = false, length = 4)
	private String mti;

	@Column(name = "proxy_card_number", nullable = false, length = 32)
	private String proxyCardNumber;

	@Column(name = "tpcode", nullable = false, length = 6)
	private String tpCode;

	@Column(name = "transaction_amount", precision = 26, scale = 8, nullable = false)
	private BigDecimal transactionAmount;

	@Column(name = "billing_amount", nullable = false, precision = 26, scale = 8)
	private BigDecimal billingAmount;

	@Column(name = "transaction_fee_amount", nullable = false, precision = 26, scale = 8)
	private BigDecimal transactionFeeAmount;

	@Column(name = "settlement_amount", precision = 26, scale = 8, nullable = false)
	private BigDecimal settlementAmount;

	@Column(name = "settlement_coversion_rate", nullable = false, precision = 26, scale = 8)
	private BigDecimal settlementConversionRate;

	@Column(name = "billing_coversion_rate", nullable = false, precision = 26, scale = 8)
	private BigDecimal billingConversionRate;

	@Column(name = "transaction_date_time", nullable = false)
	@JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime transactionDateTime;

	@Column(name = "stan", nullable = false, length = 6)
	private String stan;

	@Column(name = "local_time", nullable = false)
	private String localTime;

	@Column(name = "local_date", nullable = false)
	@JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate localDate;

	@Column(name = "expiry_date", nullable = false)
	private String expiryDate;

	@Column(name = "settlement_date")
	@JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate settlementDate;

	@Column(name = "conversion_date")
	@JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate conversionDate;

	@Column(name = "mcc", length = 4)
	private String mcc;

	@Column(name = "acq_inst_country_code", nullable = false, length = 3)
	private String acqInstCountryCode;

	@Column(name = "fwd_inst_country_code", nullable = false, length = 3)
	private String fwdInstCountryCode;

	@Column(name = "pos_entry_mode", nullable = false, length = 4)
	private String posEntryMode;

	@Column(name = "card_seq_num", nullable = false, length = 3)
	private String cardSeqNum;

	@Column(name = "pos_condition_code", length = 12)
	private String posConditionCode;

	@Column(name = "pos_pin_capture_code", nullable = false, length = 4)
	private String posPinCaptureCode;

	@Column(name = "auth_id", nullable = false, length = 6)
	private String authId;

	@Column(name = "rrn", nullable = false, length = 12)
	private String rrn;

	@Column(name = "card_acceptor_terminal_id", length = 11)
	private String cardAcceptorTerminalId;

	@Column(name = "card_acceptor_id", length = 16)
	private String cardAcceptorId;

	@Column(name = "card_acceptor_terminal_location", length = 64)
	private String cardAcceptorTerminalLocation;

	@Column(name = "transaction_currency_code", nullable = false, length = 3)
	private String transactionCurrencyCode;

	@Column(name = "settlement_currency_code", nullable = false, length = 3)
	private String settlementCurrencyCode;

	@Column(name = "billing_currency_code", nullable = false, length = 3)
	private String billingCurrencyCode;

	@Column(name = "security_info", length = 128)
	private String securityInfo;

	@Column(name = "security_result", length = 128)
	private String securityResult;

	@Column(name = "original_data_elements", nullable = false, length = 64)
	private String originalDataElements;

	@Column(name = "account_identification_1", nullable = false, length = 12)
	private String accountIdentification1;

	@Column(name = "account_identification_2", nullable = false, length = 12)
	private String accountIdentification2;

	@Column(name = "network_type", nullable = false, length = 12)
	private String networkType; // acqNetworkId

	@Column(name = "acquirer_institution_id", nullable = false, length = 11)
	private String acquirerInstitutionId;

	@Column(name = "channel_type", nullable = false, length = 6)
	private String channelType;

	@Column(name = "transaction_type", nullable = false, length = 2)
	private String transactionType;

	@Column(name = "issuer_bin", nullable = false, length = 8)
	private String issuerBin;

	@Column(name = "issuer_institution_id", nullable = false, length = 6)
	private String issuerInstitutionId;

	@Column(name = "transaction_key", nullable = false, length = 128)
	private String transactionKey;

	@Column(name = "masked_pan", nullable = false, length = 18)
	private String maskedPan;

	@Column(name = "hashed_pan", nullable = false, length = 128)
	private String hashedPan;

//	@Enumerated(EnumType.STRING)
	@Column(name = "accum_flag", nullable = false, length = 1)
	private String accumFlag;

	@Column(name = "api_ref_no", length = 512)
	private String apiRefNo;

	@Column(name = "available_balance", nullable = false, precision = 26, scale = 8)
	private BigDecimal availableBalance;

	@Column(name = "business_date")
	@JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate businessDate;

//	@Enumerated(EnumType.STRING)
	@Column(name = "charge_accum_flag", nullable = false, length = 1)
	private String chargeAccumFlag;

	@Column(name = "cin", length = 128)
	private String cin;

	@Column(name = "dr_cr_amount", precision = 26, scale = 8)
	private BigDecimal drCrAmount;

//	@Enumerated(EnumType.STRING)
	@Column(name = "dr_cr_flag", length = 1)
	private String drCrFlag;

	@Column(name = "iss_conv_rate", precision = 26, scale = 8)
	private BigDecimal issConvRate;

	@Column(name = "iss_currency_code", length = 3)
	private String issCurrencyCode;

	@Column(name = "product_id", nullable = false, length = 11)
	private String productId;

	@Column(name = "reason_code", length = 4)
	private String reasonCode;

	@Column(name = "response_code", nullable = false, length = 3)
	private String responseCode;

//	@Enumerated(EnumType.STRING)
	@Column(name = "rev_flag", length = 2)
	private String revFlag;

//	@Enumerated(EnumType.STRING)
	@Column(name = "transaction_status", nullable = false, length = 1)
	private String transactionStatus;

	@Column(name = "inc_txn_count", nullable = false, length = 2)
	private int incrementalTransactionCount;

	@Column(name = "reserver_fld1", length = 512)
	private String reserverFld1;

	@Column(name = "reserver_fld2", length = 512)
	private String reserverFld2;

	@Column(name = "reserver_fld3", length = 512)
	private String reserverFld3;

	@Column(name = "reserver_fld4", length = 512)
	private String reserverFld4;

	@Column(name = "reserver_fld5", length = 512)
	private String reserverFld5;

	@Column(name = "reserver_fld6", length = 512)
	private String reserverFld6;

	@Column(name = "reserver_fld7", length = 512)
	private String reserverFld7;

	@Column(name = "reserver_fld8", length = 512)
	private String reserverFld8;

	@Column(name = "reserver_fld9", length = 512)
	private String reserverFld9;

	@Column(name = "reserver_fld10", length = 512)
	private String reserverFld10;

	@Column(name = "org_txn_key", length = 128)
	private String orgTxnKey;

	@Column(name = "org_txn_date_time", nullable = false)
	private String orgTxnDateTime;

	@Column(name = "tran_date_time", length = 10, nullable = false)
	private String tranDateTime;

	@Column(name = "txn_identifier", length = 10, nullable = false)
	private String txnIdentifier;

	@Column(name = "iss_markup_rate", length = 05, nullable = false)
	private Integer issMarkupRate;
}
