package money.open.cards.transaction.utils;

import java.time.LocalDateTime;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import org.apache.commons.lang3.StringUtils;


public class PersistenceListener {
	@PrePersist
	void onPreCreate(Object entity) {
		AbstractEntity baseEntity = (AbstractEntity) entity;
		baseEntity.setCreatedAt(LocalDateTime.now());
		baseEntity.setModifiedAt(LocalDateTime.now());
		var createdBy = "SYSTEM";
		if(StringUtils.isEmpty(baseEntity.getCreatedBy())) {
			baseEntity.setCreatedBy(createdBy);
		}
		if(StringUtils.isEmpty(baseEntity.getModifiedBy())) {
			baseEntity.setModifiedBy(createdBy);
		}	
	}

	@PreUpdate
	void onPreUpdate(Object entity) {
		AbstractEntity baseEntity = (AbstractEntity) entity;
		baseEntity.setModifiedAt(LocalDateTime.now());
		var changedBy = "SYSTEM";
		if(StringUtils.isEmpty(baseEntity.getModifiedBy())) {
			baseEntity.setModifiedBy(changedBy);
		}
	}
}
