package money.open.cards.transaction.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import money.open.cards.transaction.utils.TransactionResponse;
import open.money.external.adapters.utils.EaTransactionResponse;

@Mapper(componentModel = "spring",unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface TransactionResponseMapper {

	TransactionResponse toTransactionResponse(EaTransactionResponse transactionResponse);
}
