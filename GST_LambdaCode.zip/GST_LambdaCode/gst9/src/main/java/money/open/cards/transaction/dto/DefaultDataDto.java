package money.open.cards.transaction.dto;

import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DefaultDataDto {

    @NotBlank
    private String traceId;
    @NotBlank
    private String hsmId;
    @NotBlank
    private String securityKeyId;
    private String userData;

}
