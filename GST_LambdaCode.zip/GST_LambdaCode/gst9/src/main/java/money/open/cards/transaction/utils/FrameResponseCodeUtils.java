package money.open.cards.transaction.utils;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FrameResponseCodeUtils {

	public String frameResponseCode(String mti) {

		if (mti == null || mti.length() == 0) {
			log.info("Mti Value is not present");
			return mti;
		} else {

			if (mti.substring(0, mti.length() - 1).equals("1")) {
				mti = mti.substring(0, mti.length() - 1) + "0";
			}

			int number = Integer.parseInt(mti) + 10;
			return "0" + Integer.toString(number);
		}

	}
}
