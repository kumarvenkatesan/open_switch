package money.open.cards.transaction;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import money.open.cards.transaction.utils.ResponseCodes;
import money.open.cards.transaction.utils.TransactionException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class ProgramKeyInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        String programId = request.getHeader("program");
        //TODO: Enable this code after multi tenant routing is done

        if(StringUtils.isEmpty(programId))
            throw new TransactionException(ResponseCodes.INVALID_PROGRAM_ID);

        ProgramContextHolder.setProgram(programId);
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        ProgramContextHolder.removeCurrentProgram();
    }
}
