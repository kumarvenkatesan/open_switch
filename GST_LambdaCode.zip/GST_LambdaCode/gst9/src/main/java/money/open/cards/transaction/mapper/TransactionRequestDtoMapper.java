package money.open.cards.transaction.mapper;

import money.open.cards.transaction.dto.TransactionRequestDto;
import open.money.external.adapters.dto.EaTransactionRequestDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface TransactionRequestDtoMapper {

	@Mapping(source = "transactionRequestDto.infData", target = "infData")
	TransactionRequestDto switchTranDtotoTransactionRequestDto(EaTransactionRequestDto transactionRequestDto);

	@Mapping(source = "transactionRequestDto.infData", target = "infData")
	EaTransactionRequestDto transactionMasterDtoToSwitchTranDto(TransactionRequestDto transactionRequestDto);
}
