package money.open.cards.transaction.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class VisaPrivateUseDto {

	private CavvDataDto cavvData;
	private String cvv2;
	private String posEnvironment;
}
