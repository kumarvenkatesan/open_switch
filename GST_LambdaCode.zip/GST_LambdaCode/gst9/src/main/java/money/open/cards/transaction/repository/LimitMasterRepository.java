package money.open.cards.transaction.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import money.open.cards.transaction.model.LimitMaster;

public interface LimitMasterRepository extends JpaRepository<LimitMaster, String> {

	List<LimitMaster> findByPartnerEntityIdAndEntityIdAndEntityTypeAndTpCodeAndStatus(String partnerEntityId,
			String entityId, String entityType, String tpCode, String status);

	List<LimitMaster> findByPartnerEntityIdAndEntityIdAndEntityTypeAndStatus(String partnerEntityId, String entityId,
			String entityType, String status);

	LimitMaster findByTpCodeAndEntityIdAndCountryModeAndChannelAndStatus(String tpCode, String entityId,
			String countryMode, String channel, String status);

	@Modifying
	@Query("update LimitMaster u set u.dailyLimit = :dailyLimit, u.dailyCount= :dailyCount, u.monthlyLimit=:monthlyLimit,u.monthlyCount=:monthlyCount, u.status=:status  where u.tpCode = :tpCode and u.entityId=:entityId and u.countryMode=:countryMode and u.channel=:channel")
	void updateStatusAndCount(@Param(value = "dailyLimit") BigDecimal dailyLimit,
			@Param(value = "dailyCount") Long dailyCount, @Param(value = "monthlyLimit") BigDecimal monthlyLimit,
			@Param(value = "monthlyCount") Long monthlyCount, @Param(value = "tpCode") String tpCode,
			@Param(value = "entityId") String entityId, @Param(value = "countryMode") String countryMode,
			@Param(value = "channel") String channel, @Param(value = "status") String status);

}
