package money.open.cards.transaction.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class CardMasterDto {

	@NotNull(message = "programMasterId must not be empty")
	private Long programMasterId;
	@Size(max = 16)
	@NotNull(message = "cardProductId must not be empty")
	private String cardProductId;
	@NotNull(message = "customerId must not be empty")
	private String customerId;
	@Size(max = 12)
	@NotNull(message = "issuerBin must not be empty")
	private String issuerBin;
	@Size(max = 128)
	@NotNull(message = "cardNumber must not be empty")
	@ToString.Exclude
	private String cardNumber;
	@Size(max = 32)
	@NotNull(message = "proxyCardNumber must not be empty")
	private String proxyCardNumber;
	@Size(max = 20)
	@NotNull(message = "maskCardNumber must not be empty")
	private String maskCardNumber;
	@Size(max = 32)
	@NotNull(message = "orderRefNo must not be empty")
	private String orderRefNo;
	@Size(max = 2)
	@NotNull(message = "status must not be empty")
	private String status;
	@NotNull(message = "cardType must not be empty")
	private String cardType;
	@NotNull(message = "countryMode must not be empty")
	private String countryMode;
	@NotNull(message = "defaultChannel must not be empty")
	private String defaultChannel;
	@NotNull(message = "diEnabled must not be empty")
	private String diEnabled;
	@Size(min = 1, max = 15)
	@NotNull(message = "transactionGroupId must not be empty")
	private String transactionGroupId;
	@Size(min = 1, max = 15)
	@NotNull(message = "limitConfigType must not be empty")
	private String limitConfigType;
	@Size(min = 1, max = 2)
	@NotNull(message = "cardSeqNo must not be empty")
	private String cardSeqNo;
	@Size(min = 1, max = 12)
	private String pinOffset;
	@Size(min = 1, max = 12)
	private String oldPinOffset;
	@Size(min = 3, max = 50)
	@NotNull(message = "displayName must not be empty")
	private String displayName;
	private LocalDate activationDate;
	private String expiryDate;
	@Size(min = 1, max = 1)
	@NotNull(message = "operationStatus must not be empty")
	private String operationStatus;
	@NotNull(message = "mobileNumber must not be empty")
	@Pattern(regexp = "(^$|[0-9]{10})", message = "Invalid")
	private String mobileNumber;
	@NotBlank(message = "Email must not be empty")
	@Email(message = "Email must be a valid email address")
	private String email;
	private String cardVariant;
	private int pinRetryCount;
	private LocalDateTime pinBlockedDateTime;

}
