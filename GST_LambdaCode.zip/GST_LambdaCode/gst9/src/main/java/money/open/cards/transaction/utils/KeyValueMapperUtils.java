package money.open.cards.transaction.utils;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class KeyValueMapperUtils {

	@Autowired
	ObjectMapper mapper;

	public String keyValueMapper(String imfData, Object transactionRequestDto) {

		Map<String, Object> targetMap = mapper.convertValue(transactionRequestDto,
				new TypeReference<Map<String, Object>>() {
				});
		StringBuilder builder = new StringBuilder();
		String[] imfDataArray = imfData.split(",");
		for (int j = 0; j < imfDataArray.length; j++) {
			char firstChar = imfDataArray[j].charAt(0);
			String sourceKey = imfDataArray[j].substring(1);
			if (firstChar == '#') {
				builder.append(targetMap.get(sourceKey));
			} else {
				if (firstChar == '$') {
					String staticKey = imfDataArray[j].substring(1);
					builder.append(staticKey);
				}
			}
		}
		return builder.toString();
	}
}
