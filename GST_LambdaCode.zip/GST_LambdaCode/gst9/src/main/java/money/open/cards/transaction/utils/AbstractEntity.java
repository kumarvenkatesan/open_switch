package money.open.cards.transaction.utils;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@NoArgsConstructor
@MappedSuperclass
@SuperBuilder(toBuilder = true)
@Getter
@Setter
@EntityListeners(value = PersistenceListener.class)
public abstract class AbstractEntity{
	@Column(nullable = false)
	String createdBy;
	@Column(nullable = false)
	LocalDateTime createdAt;
	@Column(nullable = false)
	String modifiedBy;
	@Column(nullable = false)
	LocalDateTime modifiedAt;
}