package money.open.cards.transaction.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class VerifyEMVRequestDto {

	@Valid
	@NotNull
	private DefaultKeyDto defaultData;

	@NotNull
	@Valid
	private VerifyEMVDataDto serviceData;
}
