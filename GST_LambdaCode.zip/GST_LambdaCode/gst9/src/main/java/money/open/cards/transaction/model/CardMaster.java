package money.open.cards.transaction.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import money.open.cards.transaction.utils.AbstractEntity;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "card_master")
public class CardMaster extends AbstractEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "card_master_id", nullable = false)
	private Long id;
	@Column(name = "program_master_id", nullable = false)
	private Long programMasterId;
	@Column(name = "card_product_id", nullable = false, length = 16)
	private String cardProductId;
	private String customerId;
	@Column(name = "issuer_bin", nullable = false, length = 12)
	private String issuerBin;
	@Column(name = "card_number", nullable = false, length = 128)
	private String cardNumber;
	@Column(name = "proxy_card_number", nullable = false, length = 32)
	private String proxyCardNumber;
	@Column(name = "mask_card_number", nullable = false, length = 20)
	private String maskCardNumber;
	@Column(name = "order_ref_no", nullable = false, length = 32)
	private String orderRefNo;
	@Column(name = "status", nullable = false, length = 2)
	private String status;
	@Transient
	private String statusDesc;
	@Column(name = "card_type", nullable = false, length = 2)
	private String cardType;
	@Column(name = "card_variant", nullable = false, length = 2)
	private String cardVariant;
	@Column(name = "country_mode", nullable = false, length = 2)
	private String countryMode;
	@Column(name = "default_channel", nullable = false, length = 3)
	private String defaultChannel;
	@Column(name = "di_enabled", nullable = false, length = 2)
	private String diEnabled;
	@Column(name = "transaction_group_id", nullable = false)
	private String transactionGroupId;
	@Column(name = "card_seq_no", nullable = false, length = 2)
	private String cardSeqNo;
	@Column(name = "pin_offset", length = 12)
	private String pinOffset;
	@Column(name = "old_pin_offset", length = 12)
	private String oldPinOffset;
	@Column(name = "display_name", nullable = false, length = 50)
	private String displayName;
	@Column(name = "activation_date", nullable = false)
	private LocalDate activationDate;
	@Column(name = "expiry_date", nullable = false) // yyMM
	private String expiryDate;
	@Column(name = "operation_status", nullable = false, length = 1)
	private String operationStatus;
	@Column(name = "mobile_number", nullable = false, length = 20)
	private String mobileNumber;
	private Integer pinRetryCount;
	private LocalDateTime pinBlockedDate;
	private String vendorId;
	private String deliveryAddress;
	private String cardDesignId;
	private String batchMasterId;
	private String limitConfigType;
	@Column(name = "email", nullable = false, length = 100)
	private String email;
	private String dcvvFlag;
	private String dcvvValue;

	public String getStatusDesc() {
		CardMasterStatuses cardMasterStatus = CardMasterStatuses.map.get(this.status);
		return cardMasterStatus.getMessage();
	}
}