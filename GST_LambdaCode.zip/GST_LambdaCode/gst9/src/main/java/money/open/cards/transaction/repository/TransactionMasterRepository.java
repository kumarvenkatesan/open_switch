package money.open.cards.transaction.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import money.open.cards.transaction.model.TransactionMaster;

public interface TransactionMasterRepository extends JpaRepository<TransactionMaster, String> {

	List<TransactionMaster> findByTransactionType(String transactionType);

	@Modifying
	@Query("update TransactionMaster c set c.responseCode = :responseCode, c.reasonCode = :reasonCode, c.mti = :mti, c.transactionStatus = :transactionStatus, c.securityResult =:securityResult, c.incrementalTransactionCount = :incrementalTransactionCount, c.drCrAmount = :drCrAmount, c.authId = :authId WHERE c.transactionKey = :tranasctionKey")
	void updateSuccessTransaction(@Param("responseCode") String responseCode, @Param("reasonCode") String reasonCode,
			@Param("tranasctionKey") String transactionKey, @Param("mti") String mti,
			@Param("transactionStatus") String transactionStatus, @Param("securityResult") String securityResult,
			@Param("incrementalTransactionCount") int count, @Param("drCrAmount") BigDecimal drCrAmount,
			@Param("authId") String authId);

	TransactionMaster findByApiRefNo(String apiRefNo);

	TransactionMaster findByTransactionKey(String transactionKey);

	List<TransactionMaster> findByTransactionKeyAndMti(String transactionKey, String mti);

	@Modifying
	@Query("update TransactionMaster tm set tm.responseCode = :responseCode, tm.reasonCode = :reasonCode, tm.transactionStatus = :transactionStatus WHERE tm.transactionKey = :tranasctionKey and tm.mti = :mti")
	void updateSaveTransaction(@Param("responseCode") String responseCode, @Param("reasonCode") String reasonCode,
			@Param("tranasctionKey") String transactionKey, @Param("mti") String mti,
			@Param("transactionStatus") String transactionStatus);

	List<TransactionMaster> findByStanAndRrnAndTxnIdentifier(String stan, String rrn, String txnIdentifier);

	List<TransactionMaster> findByProxyCardNumberAndStanAndRrnAndTxnIdentifier(String proxyCardNumber, String stan,
			String rrn, String txnIdentifier);

}
