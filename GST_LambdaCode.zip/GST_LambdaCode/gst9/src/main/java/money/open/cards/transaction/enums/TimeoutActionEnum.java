package money.open.cards.transaction.enums;

public enum TimeoutActionEnum {
	R
}
