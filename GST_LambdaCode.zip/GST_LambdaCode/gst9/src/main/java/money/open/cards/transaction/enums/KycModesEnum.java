package money.open.cards.transaction.enums;

public enum KycModesEnum {
	F,P,N
}
