package money.open.cards.transaction.enums;

public enum CvvTypesEnum {
    CVV1,CVV2,ICVV,CAVV;
}
