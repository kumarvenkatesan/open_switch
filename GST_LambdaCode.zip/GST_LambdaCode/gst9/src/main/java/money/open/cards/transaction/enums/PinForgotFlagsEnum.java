package money.open.cards.transaction.enums;

public enum PinForgotFlagsEnum {
	O,N
}
