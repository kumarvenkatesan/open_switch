package money.open.cards.transaction.enums;

public enum CutOverFlagEnum {
	Y,N
}
