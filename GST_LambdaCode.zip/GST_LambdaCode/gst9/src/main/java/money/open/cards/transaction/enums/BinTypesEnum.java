package money.open.cards.transaction.enums;

public enum BinTypesEnum {
	PREPAID,CREDIT,DEBIT;
}
