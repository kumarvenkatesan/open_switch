package money.open.cards.transaction.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import money.open.cards.transaction.redis.dao.KeyMapperRedisDao;
import money.open.cards.transaction.redis.model.KeyMapperRedis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Optional;

@Service
@Slf4j
public class KeyMapperRedisUtils {

	@Autowired
	KeyMapperRedisDao keyMapperDao;
	
	ObjectMapper mapper;
	
	@Autowired
	public void setMapper(ObjectMapper mapper) {
		this.mapper = mapper;
	}

	public String formKeyByConfig(Object targetMapObj, String format) throws TransactionException {
		
		Map<String, Object> targetMap = mapper.convertValue(targetMapObj, new TypeReference<Map<String, Object>>() {});

		String[] arr = format.split("\\|");

		Optional<KeyMapperRedis> dynamicMapper = keyMapperDao.findById("dynamic");
		Optional<KeyMapperRedis> staticMapper = keyMapperDao.findById("static");

		if (staticMapper.isEmpty() || dynamicMapper.isEmpty())
			throw new TransactionException(ResponseCodes.KEY_MAP_NOT_CONFIGURED);

		KeyMapperRedis dynamickeyMapper = dynamicMapper.get();
		KeyMapperRedis staticKeyMapper = staticMapper.get();
		
		Map<String, String> sourceMapDynamic = dynamickeyMapper.getKeys();
		Map<String, String> sourceMapStatic = staticKeyMapper.getKeys();
		
		StringBuilder builder = new StringBuilder();

		for (int i = 0; i < arr.length; i++) {
			char c = arr[i].charAt(0);
			String sourceKey = arr[i].substring(1);
			if(c == '#') {
				String key = sourceMapDynamic.get(sourceKey);
				if(key == null) {
					log.info("Key '{}' not found in key mapper config",sourceKey);
					throw new TransactionException(ResponseCodes.KEY_MAP_NOT_CONFIGURED);
				}
				builder.append(targetMap.get(key));

			}else if(c == '$') {
				String value = sourceMapStatic.get(sourceKey);
				if(value == null) {
					log.info("Key '{}' not found in key mapper congig",sourceKey);
					throw new TransactionException(ResponseCodes.KEY_MAP_NOT_CONFIGURED);
				}
				builder.append(value);
			}
		}

		return builder.toString();

	}
}
