package money.open.cards.transaction.dto;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import money.open.cards.transaction.enums.AuthFlagsEnum;
import money.open.cards.transaction.enums.CountryModesEnum;
import money.open.cards.transaction.enums.TransactionTypeEnum;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@ToString
public class TransactionRequestDto {

	private String apiRefNo;
	private String mti;
	private String proxyCardNumber;// proxyCardNo
	private String tpCode;// transaction processing code
	private BigDecimal transactionAmount;// transaction amount
	private BigDecimal settlementAmount;
	private BigDecimal billingAmount;// billing amount
	private BigDecimal transactionFeeAmount;// transaction fee
	private String settlementConversionRate;
	private String billingConversionRate;
	@JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime transactionDateTime;// transaction datetime
	private String stan;// stan
	private String localTime;
	@JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate localDate;
	private String expiryDate;
	@JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate settlementDate;
	@JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate conversionDate;
	private String mcc;// mcc
	private int acqInstCountryCode;
	private String fwdInstCountryCode;
	private String posEntryMode;// pos entry mode
	private String cardSeqNum;
	private String posConditionCode;// pos condition code
	private String posPinCaptureCode;
	private String authId;
	private String forwardingInstIdCode;
	private String rrn;// rrn
	private String cardAcceptorTerminalId;// terminalId
	private String cardAcceptorId;// merchantId
	private String cardAcceptorTerminalLocation;// terminalLocation
	private String transactionCurrencyCode;
	private String settlementCurrencyCode;
	private String billingCurrencyCode;
	private String visaPosInformation;
	private String financialNetworkCode;
	private String originalDataElements;
	private String accountIdentification1;
	private String accountIdentification2;
	private String acqNetworkId; // Network Type
	private String acqInstitutionId;// Acquirer Institution Id
	private String channelType;// Channel Type // acquirerChannel
	private TransactionTypeEnum transactionType;// Transaction Type
	private String issuerBin;// IssuerId/IssuerBin
	private String issuerInstId;// Issuer Institution Id
	private String transactionKey;
	private String securityInfo;// <PIN/CVV1/CCV2/EMV/iCVV/CAVV>YYYNYN
	private String securityResult;// <S/F>
	private String accumFlag;
	private BigDecimal availableBalance;
	private Date businessDate;
	private String chargeAccumFlag;
	private String cin;
	private BigDecimal drCrAmount;
	private String drCrFlag;
	private String issConvRate;
	private String issCurrencyCode;
	private String productId;
	private String reasonCode;
	private String responseCode;
	private String responseType; // to identify business or finacial Decline
	private String revFlag;
	private String transactionStatus;
	private int incTxnCount;
	private String reserverFld1;
	private String reserverFld2;
	private String reserverFld3;
	private String reserverFld4;
	private String reserverFld5;
	private String reserverFld6;
	private String reserverFld7;
	private String reserverFld8;
	private String reserverFld9;
	private String reserverFld10;
	private String cardProduct;
	private String acquirerInstitutionId;
	private String networkType;
	private String replyTopic;
	private String issuerInstitutionId;
	private String maskedPan;
	private String hashedPan;
	private Boolean contactlessTransaction; // 0 -- false , 1-- true
	@ToString.Exclude
	private String cardNumber;
	private CountryModesEnum countryModeEnum;
	private String orgMti;
	private String orgStan;
	private String orgTxnDateTime;
	private String orgAcquirerId;
	private String orgForwardingInstIdCode;
	private String orgTxnKey;
	@JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime orgTransactionDate;
	private String primaryHsmId;
	private String cvv1;
	private String emvValue;
	private String iCvv;
	private String cavv;
	private String cvv1ServiceCode;
	private String cvv2ServiceCode;
	private String iCvvServiceCode;
	private Integer pinRetryCount;
	private String limitConfigType;
	private String tranDateTime;
	private AuthFlagsEnum authFlag;
	private List<BalanceDetailsDto> balanceDetails;
	private String txnIdentifier;
	private String institutionId;
	private String partnerEntityId;
	private String pinResetMode;
	private int pinResetInterval;
	private ChipDataDto iccRelatedData;
	private InfDataDto infData;
	private Boolean partialTransaction;
	private BigDecimal partialTransactionAmount;// Reversal amount
	private String cvv2ResultCode;
	private String limitValidationFlag;
	private Boolean repeatTransaction;
	private Integer issMarkupRate;
	private String acquirerId;
	private String pinData;
	private ArrayList<String> transactionKeyList;
	private VisaPrivateUseDto visaPrivateUse;
}
