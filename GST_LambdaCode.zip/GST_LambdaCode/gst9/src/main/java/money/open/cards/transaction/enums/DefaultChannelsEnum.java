package money.open.cards.transaction.enums;

public enum DefaultChannelsEnum {
	YYY,YYN,YNN,NYY
}
