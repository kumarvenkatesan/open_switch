package money.open.cards.transaction.enums;

public enum FileTypes {
    TXT,XLS;
}
