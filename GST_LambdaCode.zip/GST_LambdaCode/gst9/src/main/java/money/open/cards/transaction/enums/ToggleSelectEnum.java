package money.open.cards.transaction.enums;

public enum ToggleSelectEnum {
	Y,N
}
