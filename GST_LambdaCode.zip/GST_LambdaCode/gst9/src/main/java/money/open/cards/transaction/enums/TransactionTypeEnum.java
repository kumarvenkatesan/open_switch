package money.open.cards.transaction.enums;

import lombok.Getter;

public enum TransactionTypeEnum {
	F("F", "Financial Transaction"), N("N", "Non Finacial Transaction"), H("H", "Merchandise Return/ Hold"),
	R("R", "Release Transaction"), C("C", "Cancel Merchandise Return/ Hold"), A("A", "Advice Transaction");

	@Getter
	String code;

	@Getter
	String message;

	private TransactionTypeEnum(String code, String message) {
		this.code = code;
		this.message = message;
	}
}
