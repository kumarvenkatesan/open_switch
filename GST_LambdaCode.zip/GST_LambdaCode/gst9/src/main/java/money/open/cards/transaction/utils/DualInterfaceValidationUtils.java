package money.open.cards.transaction.utils;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.transaction.enums.ToggleSelectEnum;

@Service
@Slf4j
public class DualInterfaceValidationUtils {

	public Boolean validateDiEnabled(String cardMasterDi, Boolean requestContactLessTransaction) {
		log.info("Validating Dual Interface Transaction::");
		return (cardMasterDi.equals(ToggleSelectEnum.Y.toString())
				&& Boolean.TRUE.equals(requestContactLessTransaction));
	}
}
