package money.open.cards.transaction.service;

import com.fasterxml.jackson.core.JsonProcessingException;

import money.open.cards.transaction.dto.TransactionRequestDto;
import money.open.cards.transaction.utils.TransactionException;

public interface ReversalTransactionService {
	
	TransactionRequestDto reversalTransactionService(TransactionRequestDto transactionRequestDto) throws TransactionException, JsonProcessingException;

}
