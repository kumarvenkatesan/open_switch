package money.open.cards.transaction.utils;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransactionResponse {
	
	Object result;
	String responseCode;
	String exception;
	
	public TransactionResponse(ResponseCodes responseCodes){
		this.responseCode = responseCodes.getCode();
		this.exception = responseCodes.getMessage();
	}

	public TransactionResponse(Object result){
		this.result = result;
		this.responseCode = ResponseCodes.SUCCESS.getCode();
	}
}
