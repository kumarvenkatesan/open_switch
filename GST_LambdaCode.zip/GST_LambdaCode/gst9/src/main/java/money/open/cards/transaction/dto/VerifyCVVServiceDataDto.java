package money.open.cards.transaction.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import money.open.cards.transaction.enums.CvvTypesEnum;

import org.hibernate.validator.constraints.Length;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Validated
public class VerifyCVVServiceDataDto{

    @NotBlank @Length(min = 3,max = 3)
    private String cvv;
    @NotNull
    private CvvTypesEnum type;
    @NotBlank
    private String cardNumber;
    @NotBlank @Length(min = 4,max = 4)
    private String expiryDate;
    @NotBlank @Length(min = 3,max = 3)
    private String serviceCode;
    private String cavvData;
}
