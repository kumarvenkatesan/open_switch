package money.open.cards.transaction.enums;

public enum EndPointTypes {
    SFTP,S3
}
