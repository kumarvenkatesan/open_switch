package money.open.cards.transaction.enums;

public enum CardVariantEnum {
	MG,OC,DI
}
