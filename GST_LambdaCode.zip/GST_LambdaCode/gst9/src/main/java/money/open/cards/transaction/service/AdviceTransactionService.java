package money.open.cards.transaction.service;

import money.open.cards.transaction.dto.TransactionRequestDto;
import money.open.cards.transaction.utils.TransactionException;

public interface AdviceTransactionService {

	TransactionRequestDto adviceTransactionService(TransactionRequestDto transactionRequestDto) throws TransactionException;
}
