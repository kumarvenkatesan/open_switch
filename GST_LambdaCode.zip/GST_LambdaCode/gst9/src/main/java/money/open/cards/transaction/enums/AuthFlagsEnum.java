package money.open.cards.transaction.enums;

public enum AuthFlagsEnum {
	Y,P;
}
