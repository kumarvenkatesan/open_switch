package money.open.cards.transaction.enums;

public enum NetworkTypeEnum {
	I,N
}
