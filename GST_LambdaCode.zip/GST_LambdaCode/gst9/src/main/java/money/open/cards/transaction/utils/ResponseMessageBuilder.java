package money.open.cards.transaction.utils;

import org.springframework.stereotype.Service;

import money.open.cards.transaction.dto.TransactionRequestDto;

@Service
public class ResponseMessageBuilder {

	public TransactionRequestDto frameResponseCodeAndMessage(TransactionRequestDto transactionRequestDto,
			String switchResponseCodes, String responseMessage, String responseType) {
		transactionRequestDto.setResponseCode(switchResponseCodes);
		transactionRequestDto.setReasonCode(responseMessage);
		transactionRequestDto.setResponseType(responseType);
		return transactionRequestDto;
	}
}
