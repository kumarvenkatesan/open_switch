package money.open.cards.transaction.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CavvDataDto {

	private String secureAuthResultCode;
	private String secFacAuthResultCode;
	private String cavvKeyId;
	private String cavvValue;
	private String cavvUnpredictableNo;
	private String cardSeqNo;
	private String cardVerifyResult;
	private String reserved;
}
