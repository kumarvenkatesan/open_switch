package money.open.cards.transaction.enums;

public enum Schemes {
    VISA,MASTER,RUPAY;
}
