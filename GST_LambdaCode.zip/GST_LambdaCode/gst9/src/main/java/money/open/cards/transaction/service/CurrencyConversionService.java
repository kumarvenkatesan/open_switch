package money.open.cards.transaction.service;

import java.math.BigDecimal;

public interface CurrencyConversionService {

	public BigDecimal currencyConversion(BigDecimal transactionAmount, BigDecimal billingAmount,
			String transactionCurrencyCode, String billingCurrencyCode, String cardProduct);
}
