package money.open.cards.transaction.enums;

public enum InstrumentTypes {
	ACCT,
	CARD,
	MOBI
}
