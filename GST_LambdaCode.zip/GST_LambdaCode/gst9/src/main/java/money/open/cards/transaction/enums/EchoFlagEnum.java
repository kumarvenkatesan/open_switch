package money.open.cards.transaction.enums;

public enum EchoFlagEnum {
	Y, N
}
