package money.open.cards.issuance;

import com.zaxxer.hikari.HikariDataSource;
import lombok.extern.slf4j.Slf4j;
import money.open.cards.issuance.utility.CommonUtility;
import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class AppServiceInit {

    @Autowired
    @Qualifier("DataSources")
    private Map<Object,Object> dataSources;

    @Value("${acs.keystore.pwd}")
    private String keyStorePwd;

    @PostConstruct
    public void afterPropertiesSet() throws Exception {
        Map<String, String> map = new HashMap<>();
        LocalDate d1 = LocalDate.now();
        LocalDate startDate = d1.withDayOfMonth(1);
        LocalDate endDate = d1.withDayOfMonth(d1.lengthOfMonth());

        map.put("date", d1.format(CommonUtility.DATE_MMYYYY));
        map.put("start_date", startDate.format(CommonUtility.DATE_YYYY_MM_DD));
        map.put("end_date", endDate.format(CommonUtility.DATE_YYYY_MM_DD));

        for (Map.Entry<Object, Object> entry : dataSources.entrySet()) {
            log.info("Running flyway migrations for program key {}", entry.getKey());
            HikariDataSource hikariDataSource = (HikariDataSource) entry.getValue();
            Flyway.configure().baselineOnMigrate(true).baselineVersion("0.0").schemas(hikariDataSource.getSchema())
                    .defaultSchema(hikariDataSource.getSchema()).dataSource(hikariDataSource).locations("classpath:db/migration")
                    .placeholders(map).load().migrate();
        }
    }

    @Bean
    @Qualifier("acs_keyStore")
    public KeyStore getKeyStore() throws KeyStoreException, CertificateException, IOException, NoSuchAlgorithmException {
        log.info("Loading acs key store into spring container");
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        InputStream inputStream = classLoader.getResourceAsStream("keys/acs.jceks");
        KeyStore keyStore = KeyStore.getInstance("JCEKS");
        keyStore.load(inputStream, keyStorePwd.toCharArray());
        return keyStore;
    }
}
