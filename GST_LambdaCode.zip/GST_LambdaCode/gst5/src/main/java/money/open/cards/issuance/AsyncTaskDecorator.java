package money.open.cards.issuance;

import org.springframework.core.task.TaskDecorator;

public class AsyncTaskDecorator implements TaskDecorator {
    @Override
    public Runnable decorate(Runnable runnable) {
        String program = ProgramContextHolder.getProgram();
        return () -> {
            try {
                ProgramContextHolder.setProgram(program);
                runnable.run();
            } finally {
                ProgramContextHolder.removeCurrentProgram();
            }
        };
    }
}
