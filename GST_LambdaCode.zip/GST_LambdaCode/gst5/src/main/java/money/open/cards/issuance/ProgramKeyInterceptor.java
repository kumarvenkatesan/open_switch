package money.open.cards.issuance;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.issuance.exception.IssuanceException;
import money.open.cards.issuance.utility.ResponseCodes;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

@Component
@Slf4j
public class ProgramKeyInterceptor implements HandlerInterceptor {

    @Autowired
    @Qualifier("DataSources")
    private Map<Object,Object> dataSources;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        String programId = request.getHeader("program");
        log.info("Program id :: {}",programId);
        if(StringUtils.isEmpty(programId))
            throw new IssuanceException(ResponseCodes.INVALID_PROGRAM_ID);

        Object dataSource = dataSources.get(programId);
        if(dataSource == null)
            throw new IssuanceException(ResponseCodes.INVALID_PROGRAM_ID);

        ProgramContextHolder.setProgram(programId);
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        ProgramContextHolder.removeCurrentProgram();
    }
}
