package money.open.cards.issuance;

import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.pattern.ConverterKeys;
import org.apache.logging.log4j.core.pattern.LogEventPatternConverter;
import org.slf4j.Marker;
import org.slf4j.MarkerFactory;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Plugin(name = "LogMaskingConverterPlugin", category = "Converter")
@ConverterKeys("logmask")
public class LogMaskingConverter extends LogEventPatternConverter {

    public static final Marker JSON_MARKER = MarkerFactory.getMarker("JSON-MASK");
    private static final String CARD_REGEX = "([0-9]{16})";
    ;
    private static final Pattern CARD_PATTERN = Pattern.compile(CARD_REGEX);
    private static final String CARD_REPLACEMENT = "XXXXXXXXXXXXXXXX";
    private static final String CVV_REGEX = "([0-9]{3})";
    private static final Pattern CVV_PATTERN = Pattern.compile(CVV_REGEX);
    private static final String CVV_REPLACEMENT_REGEX = "***";

    private static final String JSON_REPLACEMENT_REGEX = "\"$1\": \"****\"";
    private static final String[] JSON_KEYS_ARR = new String[]{"cvv", "cardNumber", "cardNo","clearCardNumber"};
    private static final String JSON_KEYS = String.join("|", JSON_KEYS_ARR);
    static final String patternString = String.format("\"(%s)\"\\s*:\\s*\"([^\"]+)\"", JSON_KEYS);
    private static final Pattern JSON_PATTERN = Pattern.compile(patternString);

    /**
     * Constructs an instance of LoggingEventPatternConverter.
     *
     * @param name  name of converter.
     * @param style CSS style for output.
     */
    protected LogMaskingConverter(String name, String style) {
        super(name, style);
    }

    public static LogMaskingConverter newInstance(String[] arrays) {
        return new LogMaskingConverter("logmask", Thread.currentThread().getName());
    }

    @Override
    public void format(LogEvent event, StringBuilder toAppendTo) {
        String message = event.getMessage().getFormattedMessage();
        String maskedMessage = message;

        if (event.getMarker() != null && event.getMarker().getName().equals(JSON_MARKER.getName())) {
            try {
                maskedMessage = mask(message);

            } catch (Exception e) {
                maskedMessage = message;// Although if this fails, it may be better to not log the message
            }
        }
        toAppendTo.append(maskedMessage);
    }

    private String mask(String message) {
        StringBuffer buffer = new StringBuffer();
        Matcher matcher = JSON_PATTERN.matcher(message);

        while (matcher.find()) {
            matcher.appendReplacement(buffer, JSON_REPLACEMENT_REGEX);
        }

        matcher.appendTail(buffer);

        return buffer.toString();
    }
}
