package money.open.cards.issuance;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableJpaRepositories(basePackages = {
		"money.open.cards.issuance.entity.repository"})
@EnableRedisRepositories(basePackages = {"money.open.cards.issuance.redis.repository"})
@EnableAsync
@EnableBatchProcessing
public class SwitchIssuanceApplication{

	public static void main(String[] args) {
		SpringApplication.run(SwitchIssuanceApplication.class, args);
	}

}
