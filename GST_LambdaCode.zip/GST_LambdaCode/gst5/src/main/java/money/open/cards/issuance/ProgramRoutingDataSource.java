package money.open.cards.issuance;

import lombok.extern.slf4j.Slf4j;
import money.open.cards.issuance.utility.DataSourceLookupException;
import money.open.cards.issuance.utility.ResponseCodes;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import javax.sql.DataSource;
@Slf4j
public class ProgramRoutingDataSource extends AbstractRoutingDataSource {
    @Override
    protected Object determineCurrentLookupKey() {
        return ProgramContextHolder.getProgram();
    }

    @Override
    protected DataSource determineTargetDataSource() {

        try {
            return super.determineTargetDataSource();
        } catch (IllegalStateException e){
            throw new DataSourceLookupException(ResponseCodes.INVALID_PROGRAM_ID);
        }
    }
}
