package money.open.cards.issuance;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import lombok.extern.slf4j.Slf4j;
import money.open.cards.issuance.redis.ProgramMasterRedis;
import money.open.cards.issuance.redis.dao.impl.ProgramMasterRedisDaoImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@Component
@Slf4j
public class DataSourcesProvider {

    @Value("${postgres.db.schema}")
    String databaseSchema;

    @Value("${hikari.max.pool.size}")
    int hikariMaxPoolSize;

    @Autowired
    private ProgramMasterRedisDaoImpl programMasterRedisDao;

    @Bean
    @Qualifier("DataSources")
    private Map<Object,Object> getAvailableDataSources(){
        Map<Object,Object> availableDataSources = new HashMap<>();
        Iterable<ProgramMasterRedis> programMasterRedisIterable = programMasterRedisDao.findAll();
        Iterator<ProgramMasterRedis> programMasterRedisIterator = programMasterRedisIterable.iterator();
        if(!programMasterRedisIterator.hasNext()){
            log.info("No datasource available to connect");
            throw new RuntimeException("No datasource available to connect");
        }
        while(programMasterRedisIterator.hasNext()){
            ProgramMasterRedis programMasterRedis = programMasterRedisIterator.next();
            ProgramContextHolder.setProgram(programMasterRedis.getProgramKey()); //To Initialize spring batch with any random datasource
            log.info("Loading datasource {}",programMasterRedis.getProgramKey());
            HikariConfig hConfig = new HikariConfig();
            hConfig.setJdbcUrl(programMasterRedis.getDbUrl());
            hConfig.setUsername(programMasterRedis.getUsername());
            hConfig.setPassword(programMasterRedis.getPassword());
            hConfig.setSchema(databaseSchema);
            hConfig.setMaximumPoolSize(hikariMaxPoolSize);
            HikariDataSource hikariDataSource= new HikariDataSource(hConfig);
            availableDataSources.put(programMasterRedis.getProgramKey(),hikariDataSource);
        }
        return availableDataSources;
    }
}
