CREATE TABLE acs_failed_txns (
	pkey bigserial NOT NULL,
	audit_log_fkey int8 NOT NULL,
	created_at timestamp NOT NULL,
    created_by varchar(255) NOT NULL,
    modified_at timestamp NOT NULL,
    modified_by varchar(255) NOT NULL,
	CONSTRAINT acs_failed_txn_pk PRIMARY KEY (pkey),
	CONSTRAINT acs_failed_txn_fk FOREIGN KEY (audit_log_fkey) REFERENCES audit_log(pkey)
);
