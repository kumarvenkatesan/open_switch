ALTER TABLE card_master ADD dcvv_flag varchar(1) NOT NULL;
ALTER TABLE card_master ADD dcvv_value varchar(3) NULL;

ALTER TABLE card_master_issuance ADD dcvv_flag varchar(1) NOT NULL;
ALTER TABLE card_master_issuance ADD dcvv_value varchar(3) NULL;