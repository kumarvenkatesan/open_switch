-- issuance.batch_job_execution_seq definition

-- DROP SEQUENCE issuance.batch_job_execution_seq;

CREATE SEQUENCE batch_job_execution_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;


-- issuance.batch_job_seq definition

-- DROP SEQUENCE issuance.batch_job_seq;

CREATE SEQUENCE batch_job_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;


-- issuance.batch_step_execution_seq definition

-- DROP SEQUENCE issuance.batch_step_execution_seq;

CREATE SEQUENCE batch_step_execution_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;

-- issuance.batch_job_instance definition

-- Drop table

-- DROP TABLE batch_job_instance;

CREATE TABLE batch_job_instance (
	job_instance_id int8 NOT NULL,
	"version" int8 NULL,
	job_name varchar(100) NOT NULL,
	job_key varchar(32) NOT NULL,
	CONSTRAINT batch_job_instance_pkey PRIMARY KEY (job_instance_id),
	CONSTRAINT job_inst_un UNIQUE (job_name, job_key)
);


-- issuance.batch_master definition

-- Drop table

-- DROP TABLE batch_master;

CREATE TABLE batch_master (
	batch_id varchar(32) NOT NULL,
	vendor_id varchar(32) NOT NULL,
	file_size int8 NOT NULL,
	perso_file varchar(100) NOT NULL,
	pinman_file varchar(100) NULL,
	kit_file varchar(100) NULL,
	status varchar(2) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	status_desc varchar(256) NULL,
	order_ref_no varchar(32) NOT NULL,
	CONSTRAINT batch_master_pk PRIMARY KEY (batch_id)
);


-- issuance.card_order definition

-- Drop table

-- DROP TABLE card_order;

CREATE TABLE card_order (
	card_order_id varchar(32) NOT NULL,
	program_master_id int8 NOT NULL,
	card_product_id varchar(16) NOT NULL,
	no_of_cards int8 NOT NULL,
	status varchar(2) NOT NULL,
	card_prefix varchar(32) NOT NULL,
	start_card_seq int8 NOT NULL,
	end_card_seq int8 NOT NULL,
	received_date timestamp NOT NULL,
	maker_id varchar(128) NOT NULL,
	maker_remarks varchar(128) NOT NULL,
	checker_id varchar(128) NOT NULL,
	checker_remarks varchar(128) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	name_on_card varchar(128) NOT NULL,
	proxy_prefix varchar(32) NOT NULL,
	start_proxy_seq int8 NOT NULL,
	end_proxy_seq int8 NOT NULL,
	card_design_id varchar(32) NULL,
	delivery_address varchar(32) NULL,
	CONSTRAINT card_order_pkey PRIMARY KEY (card_order_id)
);


-- issuance.customer_master definition

-- Drop table

-- DROP TABLE customer_master;

CREATE TABLE customer_master (
	customer_master_id bigserial NOT NULL ,
	partner_entity_id varchar(16) NOT NULL,
	customer_id varchar(32) NOT NULL,
	salutation_code varchar(10) NOT NULL,
	first_name varchar(40) NOT NULL,
	middle_name varchar(40) NULL,
	last_name varchar(40) NOT NULL,
	birth_date date NULL,
	gender varchar(1) NOT NULL,
	primary_email varchar(50) NOT NULL,
	alternate_email varchar(50) NULL,
	primary_mobile varchar(20) NOT NULL,
	alternate_mobile varchar(20) NULL,
	kyc_flag varchar(1) NOT NULL,
	kyc_source varchar(20) NOT NULL,
	status varchar(2) NOT NULL,
	idtype1 varchar(250) NULL,
	idvalue1 varchar(250) NULL,
	idstatus1 varchar(250) NULL,
	idtype2 varchar(250) NULL,
	idvalue2 varchar(250) NULL,
	idstatus2 varchar(250) NULL,
	idtype3 varchar(250) NULL,
	idvalue3 varchar(250) NULL,
	idstatus3 varchar(250) NULL,
	current_address1 varchar(50) NOT NULL,
	current_address2 varchar(50) NOT NULL,
	current_address3 varchar(50) NOT NULL,
	current_address4 varchar(50) NOT NULL,
	current_pincode varchar(50) NOT NULL,
	mailing_address1 varchar(50) NOT NULL,
	mailing_address2 varchar(50) NOT NULL,
	mailing_address3 varchar(50) NOT NULL,
	mailing_address4 varchar(50) NOT NULL,
	mailing_pincode varchar(50) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT customer_master_pkey PRIMARY KEY (customer_master_id)
);


-- issuance.data_sequence_master definition

-- Drop table

-- DROP TABLE data_sequence_master;

CREATE TABLE data_sequence_master (
	entity_id varchar(32) NOT NULL,
	entity_type varchar(16) NOT NULL,
	key_data varchar(16) NOT NULL,
	seq_type bpchar(1) NOT NULL,
	start_seq int8 NOT NULL,
	current_seq int8 NOT NULL,
	max_seq int8 NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	CONSTRAINT data_sequence_master_key_data_key UNIQUE (key_data),
	CONSTRAINT data_sequence_master_pkey PRIMARY KEY (entity_id, entity_type, key_data),
	CONSTRAINT seq_type_chk CHECK ((seq_type = ANY (ARRAY['S'::bpchar, 'R'::bpchar])))
);


-- issuance.limit_master definition

-- Drop table

-- DROP TABLE limit_master;

CREATE TABLE limit_master (
	limit_config_id varchar(32) NOT NULL,
	partner_entity_id varchar(12) NOT NULL,
	entity_id varchar(32) NOT NULL,
	entity_type varchar(16) NOT NULL,
	country_mode varchar(1) NOT NULL,
	tp_code varchar(6) NOT NULL,
	daily_limit numeric(26, 4) NOT NULL,
	daily_count int8 NOT NULL,
	monthly_limit numeric(26, 4) NOT NULL,
	monthly_count int8 NOT NULL,
	channel varchar(32) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	pkey bigserial NOT NULL,
	currency_mode varchar(1) NULL,
	CONSTRAINT limit_master_pk PRIMARY KEY (pkey)
);


-- issuance.batch_job_execution definition

-- Drop table

-- DROP TABLE batch_job_execution;

CREATE TABLE batch_job_execution (
	job_execution_id int8 NOT NULL,
	"version" int8 NULL,
	job_instance_id int8 NOT NULL,
	create_time timestamp NOT NULL,
	start_time timestamp NULL,
	end_time timestamp NULL,
	status varchar(10) NULL,
	exit_code varchar(2500) NULL,
	exit_message varchar(2500) NULL,
	last_updated timestamp NULL,
	job_configuration_location varchar(2500) NULL,
	CONSTRAINT batch_job_execution_pkey PRIMARY KEY (job_execution_id),
	CONSTRAINT job_inst_exec_fk FOREIGN KEY (job_instance_id) REFERENCES batch_job_instance(job_instance_id)
);


-- issuance.batch_job_execution_context definition

-- Drop table

-- DROP TABLE batch_job_execution_context;

CREATE TABLE batch_job_execution_context (
	job_execution_id int8 NOT NULL,
	short_context varchar(2500) NOT NULL,
	serialized_context text NULL,
	CONSTRAINT batch_job_execution_context_pkey PRIMARY KEY (job_execution_id),
	CONSTRAINT job_exec_ctx_fk FOREIGN KEY (job_execution_id) REFERENCES batch_job_execution(job_execution_id)
);


-- issuance.batch_job_execution_params definition

-- Drop table

-- DROP TABLE batch_job_execution_params;

CREATE TABLE batch_job_execution_params (
	job_execution_id int8 NOT NULL,
	type_cd varchar(6) NOT NULL,
	key_name varchar(100) NOT NULL,
	string_val varchar(250) NULL,
	date_val timestamp NULL,
	long_val int8 NULL,
	double_val float8 NULL,
	identifying bpchar(1) NOT NULL,
	CONSTRAINT job_exec_params_fk FOREIGN KEY (job_execution_id) REFERENCES batch_job_execution(job_execution_id)
);


-- issuance.batch_step_execution definition

-- Drop table

-- DROP TABLE batch_step_execution;

CREATE TABLE batch_step_execution (
	step_execution_id int8 NOT NULL,
	"version" int8 NOT NULL,
	step_name varchar(100) NOT NULL,
	job_execution_id int8 NOT NULL,
	start_time timestamp NOT NULL,
	end_time timestamp NULL,
	status varchar(10) NULL,
	commit_count int8 NULL,
	read_count int8 NULL,
	filter_count int8 NULL,
	write_count int8 NULL,
	read_skip_count int8 NULL,
	write_skip_count int8 NULL,
	process_skip_count int8 NULL,
	rollback_count int8 NULL,
	exit_code varchar(2500) NULL,
	exit_message varchar(2500) NULL,
	last_updated timestamp NULL,
	CONSTRAINT batch_step_execution_pkey PRIMARY KEY (step_execution_id),
	CONSTRAINT job_exec_step_fk FOREIGN KEY (job_execution_id) REFERENCES batch_job_execution(job_execution_id)
);


-- issuance.batch_step_execution_context definition

-- Drop table

-- DROP TABLE batch_step_execution_context;

CREATE TABLE batch_step_execution_context (
	step_execution_id int8 NOT NULL,
	short_context varchar(2500) NOT NULL,
	serialized_context text NULL,
	CONSTRAINT batch_step_execution_context_pkey PRIMARY KEY (step_execution_id),
	CONSTRAINT step_exec_ctx_fk FOREIGN KEY (step_execution_id) REFERENCES batch_step_execution(step_execution_id)
);


-- issuance.card_master definition

-- Drop table

-- DROP TABLE card_master;

CREATE TABLE card_master (
	card_master_id bigserial NOT NULL,
	program_master_id int8 NOT NULL,
	card_product_id varchar(16) NOT NULL,
	issuer_bin varchar(12) NOT NULL,
	card_number varchar(128) NOT NULL,
	proxy_card_number varchar(32) NOT NULL,
	mask_card_number varchar(20) NOT NULL,
	order_ref_no varchar(32) NOT NULL,
	status varchar(2) NOT NULL,
	card_type varchar(1) NOT NULL,
	country_mode varchar(1) NOT NULL,
	default_channel varchar(3) NOT NULL,
	di_enabled varchar(1) NOT NULL,
	transaction_group_id varchar(15) NOT NULL,
	card_seq_no varchar(2) NOT NULL,
	pin_offset varchar(12) NULL,
	old_pin_offset varchar(12) NULL,
	display_name varchar(50) NOT NULL,
	activation_date date NULL,
	expiry_date date NOT NULL,
	operation_status varchar(1) NOT NULL,
	mobile_number varchar(20) NOT NULL,
	email varchar(100) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	customer_master_id int8 NULL,
	vendor_id varchar(32) NULL,
	card_design_id varchar(32) NULL,
	delivery_address varchar(32) NULL,
	card_variant varchar(4) NOT NULL,
	batch_master_id varchar(32) NULL,
	limit_config_type varchar(15) NOT NULL DEFAULT 'default'::character varying,
	primary_proxy_card_number varchar(32) NULL,
	card_reprint varchar(1) NOT NULL DEFAULT 'N'::character varying,
	CONSTRAINT card_master_card_number_key UNIQUE (card_number),
	CONSTRAINT card_master_pkey PRIMARY KEY (card_master_id),
	CONSTRAINT card_master_proxy_card_number_key UNIQUE (proxy_card_number),
	CONSTRAINT card_master_fk FOREIGN KEY (customer_master_id) REFERENCES customer_master(customer_master_id)
);


-- issuance.card_master_issuance definition

-- Drop table

-- DROP TABLE card_master_issuance;

CREATE TABLE card_master_issuance (
	card_master_issuance_id bigserial NOT NULL,
	program_master_id int8 NOT NULL,
	card_product_id varchar(16) NOT NULL,
	customer_master_id int8 NULL,
	issuer_bin varchar(12) NOT NULL,
	card_number varchar(128) NOT NULL,
	proxy_card_number varchar(32) NOT NULL,
	mask_card_number varchar(20) NOT NULL,
	order_ref_no varchar(32) NOT NULL,
	status varchar(2) NOT NULL,
	card_type varchar(1) NOT NULL,
	country_mode varchar(1) NOT NULL,
	default_channel varchar(3) NOT NULL,
	di_enabled varchar(1) NOT NULL,
	transaction_group_id varchar(15) NOT NULL,
	card_seq_no varchar(2) NOT NULL,
	pin_offset varchar(12) NULL,
	old_pin_offset varchar(12) NULL,
	display_name varchar(50) NOT NULL,
	activation_date date NULL,
	expiry_date date NOT NULL,
	operation_status varchar(1) NOT NULL,
	mobile_number varchar(20) NOT NULL,
	email varchar(100) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	vendor_id varchar(32) NULL,
	card_design_id varchar(32) NULL,
	delivery_address varchar(32) NULL,
	card_variant varchar(4) NOT NULL,
	batch_master_id varchar(32) NULL,
	limit_config_type varchar(15) NOT NULL DEFAULT 'default'::character varying,
	primary_proxy_card_number varchar(32) NULL,
	card_reprint varchar(1) NOT NULL DEFAULT 'N'::character varying,
	CONSTRAINT card_master_issuance_card_number_key UNIQUE (card_number),
	CONSTRAINT card_master_issuance_pkey PRIMARY KEY (card_master_issuance_id),
	CONSTRAINT card_master_issuance_proxy_card_number_key UNIQUE (proxy_card_number),
	CONSTRAINT card_master_fk FOREIGN KEY (customer_master_id) REFERENCES customer_master(customer_master_id)
);

-- issuance.delivery_address definition

-- Drop table

-- DROP TABLE delivery_address;

CREATE TABLE delivery_address (
	address_id varchar(32) NOT NULL,
	address1 varchar(50) NOT NULL,
	address2 varchar(50) NOT NULL,
	created_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	created_at timestamp NOT NULL DEFAULT now(),
	modified_by varchar(15) NOT NULL DEFAULT 'SYSTEM'::character varying,
	modified_at timestamp NOT NULL DEFAULT now(),
	address3 varchar(50) NOT NULL,
	address4 varchar(50) NOT NULL,
	pin_code varchar(6) NOT NULL,
	CONSTRAINT delivery_address_pk PRIMARY KEY (address_id)
);