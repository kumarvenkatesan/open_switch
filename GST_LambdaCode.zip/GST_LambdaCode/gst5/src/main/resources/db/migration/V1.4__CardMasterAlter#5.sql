ALTER TABLE card_master ADD additional_data1 text NULL;
ALTER TABLE card_master ADD additional_data2 text NULL;

ALTER TABLE card_master_issuance ADD additional_data1 text NULL;
ALTER TABLE card_master_issuance ADD additional_data2 text NULL;