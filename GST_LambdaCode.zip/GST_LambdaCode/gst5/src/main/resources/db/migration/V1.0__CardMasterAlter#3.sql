ALTER TABLE card_master ADD card_flag varchar(1) NULL;
ALTER TABLE card_master ADD card_count int2 NULL;

ALTER TABLE card_master_issuance ADD card_flag varchar(1) NULL;
ALTER TABLE card_master_issuance ADD card_count int2 NULL;