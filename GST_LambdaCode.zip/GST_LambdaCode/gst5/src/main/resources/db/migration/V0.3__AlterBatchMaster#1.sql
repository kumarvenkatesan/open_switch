ALTER TABLE batch_master ALTER COLUMN perso_file TYPE varchar(256) USING perso_file::varchar;
ALTER TABLE batch_master ALTER COLUMN pinman_file TYPE varchar(256) USING pinman_file::varchar;
ALTER TABLE batch_master ALTER COLUMN kit_file TYPE varchar(256) USING kit_file::varchar;