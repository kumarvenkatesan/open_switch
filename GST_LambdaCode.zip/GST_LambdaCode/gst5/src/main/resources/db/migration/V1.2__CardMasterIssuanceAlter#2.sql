ALTER TABLE card_master_issuance ADD physical_card_status varchar(1) NULL;

