CREATE TABLE audit_log (
	pkey bigserial NOT NULL,
	log_id varchar(255) NULL,
	created_at timestamp NOT NULL,
	created_by varchar(255) NOT NULL,
	modified_at timestamp NOT NULL,
	modified_by varchar(255) NOT NULL,
	entity_id varchar(100) NOT NULL,
	entity_type varchar(32) NOT NULL,
	"action" varchar(32) NOT NULL,
	description varchar(100) NULL,
	request text NULL,
	request_url varchar(255) NULL,
	response text NULL,
	response_code varchar(4) NULL,
	CONSTRAINT audit_log_pk PRIMARY KEY (pkey)
)
