package money.open.cards.issuance;

import org.springframework.boot.test.context.TestConfiguration;

@TestConfiguration
public class  IssuanceTestConfig {

}
