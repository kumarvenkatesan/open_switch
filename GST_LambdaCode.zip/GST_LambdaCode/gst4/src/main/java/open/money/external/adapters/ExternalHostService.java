package open.money.external.adapters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import open.money.external.adapters.dto.EaTransactionRequestDto;
import open.money.external.adapters.utils.EaTransactionResponse;

@Service
public class ExternalHostService {

	@Autowired
	private OpenCasAdpater openCasAdapter;
	
	@Autowired
	private OpenSecurityAdapter openSecurityAdapter;

	public EaTransactionRequestDto sendExternalCall(EaTransactionRequestDto transactionRequestDto, String endPoint,
			String networkName) {
		if (networkName.equalsIgnoreCase("Open Cas Host")) {
			return openCasAdapter.formRequestDto(transactionRequestDto, endPoint);
		}

		return transactionRequestDto;
	}
	
	public EaTransactionResponse sendExternalSecurityVerificationCall(String url, MultiValueMap<String, String> headers,
			Object request,String serviceName) {
		return openSecurityAdapter.callSecurityVerification(url,headers,request, serviceName);
		
	}
}