package open.money.external.adapters;

import java.net.ConnectException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.ratelimiter.RequestNotPermitted;
import lombok.extern.slf4j.Slf4j;
import open.money.external.adapters.dto.EaOpenCasTransactionRequestDto;
import open.money.external.adapters.dto.EaTransactionRequestDto;
import open.money.external.adapters.enums.EaInstrumentTypes;
import open.money.external.adapters.enums.EaTransactionModes;
import open.money.external.adapters.enums.EaTransactionRequestTypes;
import open.money.external.adapters.utils.EaSwitchResponseCodes;
import open.money.external.adapters.utils.EaTransactionResponse;
import open.money.external.adapters.utils.EaWebClientUtils;
import open.money.external.adapters.utils.OpenCasUtils;

@Slf4j
@Service
public class OpenCasAdpater {

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	EaWebClientUtils webClientUtils;

	public EaTransactionRequestDto formRequestDto(EaTransactionRequestDto transactionRequestDto, String endPoint) {
		try {
			log.info("Converting transactionRequestDto to OpenCasRequestDto");
			Map<String, Object> headerMap = new HashMap<>();
			headerMap.put("source", "open_cards");
			headerMap.put("requestId", transactionRequestDto.getApiRefNo());
			headerMap.put("Content-Type", "application/json");

			EaTransactionResponse transactionResponse = OpenCasFeignService.openCasResponse
					.openCasAuth(this.frameOpenCasRequestDto(transactionRequestDto), new URI(endPoint), headerMap);
			if (transactionResponse.getResponseCode().equals("T00")) {
				if (transactionResponse.getData().getTotalBalance() != null)
					transactionRequestDto.setAvailableBalance(transactionResponse.getData().getTotalBalance());
				if (transactionResponse.getData().getBalanceDetails() != null)
					transactionRequestDto.setBalanceDetails(transactionResponse.getData().getBalanceDetails());
				transactionRequestDto.setAuthId(String.valueOf(transactionResponse.getData().getAuthCode()));
				transactionRequestDto.setResponseCode(EaSwitchResponseCodes.APPROVED_OR_COMPLETED.getCode());
				transactionRequestDto.setReasonCode(EaSwitchResponseCodes.APPROVED_OR_COMPLETED.getMessage());
			} else if (transactionResponse.getResponseCode().equals("T40")) {
				transactionRequestDto
						.setResponseCode(EaSwitchResponseCodes.INSUFFICIENT_BALANCE_OR_OVER_CREDIT_LIMIT.getCode());
				transactionRequestDto
						.setReasonCode(EaSwitchResponseCodes.INSUFFICIENT_BALANCE_OR_OVER_CREDIT_LIMIT.getMessage());

			} else if (transactionResponse.getResponseCode().equals("T81")) {
				transactionRequestDto.setResponseCode(EaSwitchResponseCodes.INVALID_ORG_TXN_DATE.getCode());
				transactionRequestDto.setReasonCode(EaSwitchResponseCodes.INVALID_ORG_TXN_DATE.getMessage());
			} else {
				transactionRequestDto.setResponseCode(EaSwitchResponseCodes.DO_NOT_HONOR.getCode());
				transactionRequestDto.setReasonCode(transactionResponse.getException());
				transactionRequestDto.setResponseType(EaSwitchResponseCodes.SYSTEM_ERROR.getType());
			}
		} catch (ConnectException e1) {
			log.info("Connect TimeOut Exception");
			// send to kafka
			transactionRequestDto.setResponseCode(EaSwitchResponseCodes.ISSUER_SYSTEM_INOPERATIVE.getCode());
			transactionRequestDto.setReasonCode("ConnectException");
			transactionRequestDto.setResponseType(EaSwitchResponseCodes.SYSTEM_ERROR.getType());
			return transactionRequestDto;
		} catch (URISyntaxException e) {

		} catch (feign.RetryableException e2) {
			log.info("Retryable Exception");
//			send to kafka
			transactionRequestDto.setResponseCode(EaSwitchResponseCodes.ISSUER_SYSTEM_INOPERATIVE.getCode());
			transactionRequestDto.setReasonCode("RetryableException");
			transactionRequestDto.setResponseType(EaSwitchResponseCodes.SYSTEM_ERROR.getType());
			return transactionRequestDto;
		} catch (CallNotPermittedException e) {
			// send to kafka
			log.info("Call Not Permitted Excepiton because more number of requests in open state");
			transactionRequestDto.setResponseCode(EaSwitchResponseCodes.ISSUER_SYSTEM_INOPERATIVE.getCode());
			transactionRequestDto.setReasonCode("CallNotPermittedException");
			transactionRequestDto.setResponseType(EaSwitchResponseCodes.SYSTEM_ERROR.getType());
			return transactionRequestDto;
		} catch (RequestNotPermitted e) {
			// send to kafka
			log.info("Request Not Permitted because requests is taking more than configured seconds");
			transactionRequestDto.setResponseCode(EaSwitchResponseCodes.ISSUER_SYSTEM_INOPERATIVE.getCode());
			transactionRequestDto.setReasonCode("RequestNotPermittedException");
			transactionRequestDto.setResponseType(EaSwitchResponseCodes.SYSTEM_ERROR.getType());
			return transactionRequestDto;
		} catch (feign.FeignException e) {
			// send to kafka
			log.info("Request Not Permitted because requests is taking more than configured seconds");
			transactionRequestDto.setResponseCode(EaSwitchResponseCodes.SYSTEM_ERROR.getCode());
			transactionRequestDto.setReasonCode("RequestNotPermittedException");
			transactionRequestDto.setResponseType(EaSwitchResponseCodes.SYSTEM_ERROR.getType());
			return transactionRequestDto;
		}
		return transactionRequestDto;
	}

	public EaOpenCasTransactionRequestDto frameOpenCasRequestDto(EaTransactionRequestDto transactionRequestDto) {
		EaOpenCasTransactionRequestDto casRequest = new EaOpenCasTransactionRequestDto();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

		if (transactionRequestDto.getDrCrFlag().equals("D")) {
			casRequest.setSourceTxnRefNum(transactionRequestDto.getTransactionKey());
			casRequest.setRequestType(EaTransactionRequestTypes.AUTH);
		}

		if (transactionRequestDto.getDrCrFlag().equals("C")) {
			if ((transactionRequestDto.getTpCode().substring(0, 2).equals("20")
					|| transactionRequestDto.getTpCode().substring(0, 2).equals("26"))
					&& transactionRequestDto.getMti().equals("0100")) {
				casRequest.setRequestType(EaTransactionRequestTypes.AUTH);
				casRequest.setSourceTxnRefNum(transactionRequestDto.getTransactionKey());
			} else if (transactionRequestDto.getTpCode().substring(0, 2).equals("20")
					&& transactionRequestDto.getMti().equals("0400")) {
				casRequest.setRequestType(EaTransactionRequestTypes.REVL);
				casRequest.setSourceTxnRefNum(transactionRequestDto.getTransactionKey());
				casRequest.setOrgSourceTxnRefNum(transactionRequestDto.getOrgTxnKey());
				casRequest.setOrgTxnDate(transactionRequestDto.getOrgTransactionDate().format(dateFormatter));
			} else {
				casRequest.setSourceTxnRefNum(transactionRequestDto.getTransactionKey());
				casRequest.setRequestType(EaTransactionRequestTypes.REVL);
				casRequest.setOrgSourceTxnRefNum(transactionRequestDto.getOrgTxnKey());
				casRequest.setOrgTxnDate(transactionRequestDto.getOrgTransactionDate().format(dateFormatter));
			}
		}

		if (transactionRequestDto.getTransactionType().equals("H")) {
			casRequest.setTransactionFlag("HOLD");
			casRequest.setRequestType(EaTransactionRequestTypes.AUTH);
			casRequest.setSourceTxnRefNum(transactionRequestDto.getTransactionKey());
		}

		if (transactionRequestDto.getTransactionType().equals("R")) {
			casRequest.setTransactionFlag("RELEASE");
			casRequest.setRequestType(EaTransactionRequestTypes.AUTH);
			casRequest.setOrgSourceTxnRefNum(transactionRequestDto.getOrgTxnKey());
		}

		if (transactionRequestDto.getTransactionType().equals("C")) {
			casRequest.setTransactionFlag("CANCEL");
			casRequest.setRequestType(EaTransactionRequestTypes.AUTH);
			casRequest.setOrgSourceTxnRefNum(transactionRequestDto.getOrgTxnKey());
		}
		casRequest.setMode(EaTransactionModes.SYNC);
		casRequest.setTransactionDateTime(transactionRequestDto.getTransactionDateTime().format(formatter));
		casRequest.setTransactionAmount(transactionRequestDto.getDrCrAmount());
		casRequest.setIssuerBin(transactionRequestDto.getIssuerBin());
		casRequest.setRemarks(transactionRequestDto.getCardAcceptorTerminalLocation());
		casRequest.setTransactionType(OpenCasUtils.frameTransactionType(transactionRequestDto.getTpCode()));
		casRequest.setInstrumentId(transactionRequestDto.getProxyCardNumber());
		casRequest.setInstrumentType(EaInstrumentTypes.CARD);
		casRequest.setBusinessEntity(transactionRequestDto.getPartnerEntityId());
		casRequest.setFinancialEntity(transactionRequestDto.getIssuerInstitutionId());
		casRequest.setReservedFld1(OpenCasUtils.frameAdditonalField1(transactionRequestDto));
		if (transactionRequestDto.getTransactionKeyList() != null) {
			casRequest.setSourceTxnRefNumList(transactionRequestDto.getTransactionKeyList());
			casRequest.setIsIncrementalTransactionReversal(true);
		}

		return casRequest;
	}
}
