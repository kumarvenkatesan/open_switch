package open.money.external.adapters;

import java.net.ConnectException;
import java.net.URI;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;

import feign.HeaderMap;
import feign.Request;
import feign.RequestLine;
import feign.Retryer;
import feign.Target;
import feign.gson.GsonDecoder;
import feign.gson.GsonEncoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig.SlidingWindowType;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.feign.FeignDecorators;
import io.github.resilience4j.feign.Resilience4jFeign;
import io.github.resilience4j.ratelimiter.RequestNotPermitted;
import open.money.external.adapters.security.dto.EaPinValidationRequestDto;
import open.money.external.adapters.security.dto.EaVerifyArqcRequestDto;
import open.money.external.adapters.security.dto.EaVerifyCvvRequestDto;
import open.money.external.adapters.utils.EaTransactionResponse;

public interface OpenSecurityFeignService {

	@RequestLine("POST")
	EaTransactionResponse openPinSecurity(@RequestBody EaPinValidationRequestDto pinValidationRequestDto, URI baseUrl,
			@HeaderMap MultiValueMap<String, String> headerMap)
			throws ConnectException, CallNotPermittedException, RequestNotPermitted;

	@RequestLine("POST")
	EaTransactionResponse openCvvSecurity(@RequestBody EaVerifyCvvRequestDto cvvValidationRequestDto, URI baseUrl,
			@HeaderMap MultiValueMap<String, String> headerMap)
			throws ConnectException, CallNotPermittedException, RequestNotPermitted;

	@RequestLine("POST")
	EaTransactionResponse arqcValidation(@RequestBody EaVerifyArqcRequestDto arqcValidationRequestDto, URI baseUrl,
			@HeaderMap MultiValueMap<String, String> headerMap)
			throws ConnectException, CallNotPermittedException, RequestNotPermitted;

	CircuitBreakerConfig circuitBreakerConfig = CircuitBreakerConfig.custom().failureRateThreshold(50)
			.slowCallRateThreshold(50).waitDurationInOpenState(Duration.ofSeconds(10))
			.slowCallDurationThreshold(Duration.ofSeconds(5)).permittedNumberOfCallsInHalfOpenState(300)
			.minimumNumberOfCalls(100).slidingWindowType(SlidingWindowType.COUNT_BASED).slidingWindowSize(100)
			.recordExceptions(Exception.class).build();

	// Create a CircuitBreakerRegistry with a custom global configuration
	CircuitBreakerRegistry circuitBreakerRegistry = CircuitBreakerRegistry.of(circuitBreakerConfig);

	// Get or create a CircuitBreaker from the CircuitBreakerRegistry
	// with a custom configuration
	CircuitBreaker circuitBreakerWithCustomConfig = circuitBreakerRegistry.circuitBreaker("openSecurityCircuit",
			circuitBreakerConfig);

	FeignDecorators decorators = FeignDecorators.builder().withCircuitBreaker(circuitBreakerWithCustomConfig).build();

	OpenSecurityFeignService openSecurityResponse = Resilience4jFeign.builder(decorators).client(new OkHttpClient())
			.options(new Request.Options(100L, TimeUnit.SECONDS, 5L, TimeUnit.SECONDS, false))
			.encoder(new GsonEncoder()).decoder(new GsonDecoder())
			.logger(new Slf4jLogger(OpenSecurityFeignService.class)).retryer(Retryer.NEVER_RETRY)
			.logLevel(feign.Logger.Level.FULL).target(Target.EmptyTarget.create(OpenSecurityFeignService.class));

}
