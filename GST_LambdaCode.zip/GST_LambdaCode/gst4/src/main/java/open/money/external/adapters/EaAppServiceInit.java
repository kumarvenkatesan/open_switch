package open.money.external.adapters;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import lombok.Getter;

public class EaAppServiceInit {

	@Autowired
	OpenCasAdpater openCasTransactionRequestDto;

	@Getter
	Map<String, EaRequestDtoFormationService> requestDtoFormationServiceMap = new HashMap<>();

//	@Override
//	public void afterPropertiesSet() throws Exception {
//		requestDtoFormationServiceMap.put("OPEN CAS HOST", openCasTransactionRequestDto);
//	}
}
