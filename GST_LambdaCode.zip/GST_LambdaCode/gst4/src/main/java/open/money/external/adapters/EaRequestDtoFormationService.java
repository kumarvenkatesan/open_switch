package open.money.external.adapters;

import org.springframework.transaction.TransactionException;

import com.fasterxml.jackson.core.JsonProcessingException;

import open.money.external.adapters.dto.EaTransactionRequestDto;

public interface EaRequestDtoFormationService {

	EaTransactionRequestDto formRequestDto(EaTransactionRequestDto transactionRequestDto, String url,
			int timeOut) throws TransactionException, JsonProcessingException;

}
