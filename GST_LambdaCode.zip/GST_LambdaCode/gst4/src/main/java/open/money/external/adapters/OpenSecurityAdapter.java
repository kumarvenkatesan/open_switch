package open.money.external.adapters;

import java.net.ConnectException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.ratelimiter.RequestNotPermitted;
import lombok.extern.slf4j.Slf4j;
import open.money.external.adapters.security.dto.EaPinValidationRequestDto;
import open.money.external.adapters.security.dto.EaVerifyArqcRequestDto;
import open.money.external.adapters.security.dto.EaVerifyCvvRequestDto;
import open.money.external.adapters.utils.EaSwitchResponseCodes;
import open.money.external.adapters.utils.EaTransactionResponse;

@Slf4j
@Service
public class OpenSecurityAdapter {

	@Autowired
	private ObjectMapper mapper;

	public EaTransactionResponse callSecurityVerification(String url, MultiValueMap<String, String> headers,
			Object request, String serviceName) {
		EaTransactionResponse transactionResponse = new EaTransactionResponse();
		try {
			if (serviceName.equals("PIN_VALIDATION")) {
				EaPinValidationRequestDto pinValidationRequestDto = mapper.convertValue(request,
						EaPinValidationRequestDto.class);
				transactionResponse = OpenSecurityFeignService.openSecurityResponse
						.openPinSecurity(pinValidationRequestDto, new URI(url), headers);
			}
			if (serviceName.equals("CVV_VALIDATION")) {
				EaVerifyCvvRequestDto cvvValidationRequestDto = mapper.convertValue(request,
						EaVerifyCvvRequestDto.class);
				transactionResponse = OpenSecurityFeignService.openSecurityResponse
						.openCvvSecurity(cvvValidationRequestDto, new URI(url), headers);
			}

			if (serviceName.equals("EMV_VALIDATION")) {
				EaVerifyArqcRequestDto arqcValidationRequestDto = mapper.convertValue(request,
						EaVerifyArqcRequestDto.class);
				transactionResponse = OpenSecurityFeignService.openSecurityResponse
						.arqcValidation(arqcValidationRequestDto, new URI(url), headers);
			}

		} catch (ConnectException e1) {
			log.info("Connect TimeOut Exception");
			transactionResponse.setResponseCode(EaSwitchResponseCodes.ISSUER_SYSTEM_INOPERATIVE.getCode());
			transactionResponse.setException(e1.getMessage());
			transactionResponse.setResult(EaSwitchResponseCodes.SYSTEM_ERROR.getType());
		} catch (URISyntaxException e) {
			log.info("URI syntax exception");
		} catch (feign.RetryableException e2) {
			log.info("Retryable Exception");
			transactionResponse.setResponseCode(EaSwitchResponseCodes.SYSTEM_ERROR.getCode());
			transactionResponse.setException(StandardCharsets.UTF_8.decode(e2.responseBody().get()).toString());
			transactionResponse.setResult(EaSwitchResponseCodes.SYSTEM_ERROR.getType());
		} catch (CallNotPermittedException e) {
			log.info("Call Not Permitted Excepiton because more number of requests in open state");
			transactionResponse.setResponseCode(EaSwitchResponseCodes.ISSUER_SYSTEM_INOPERATIVE.getCode());
			transactionResponse.setException(e.getMessage());
			transactionResponse.setResult(EaSwitchResponseCodes.SYSTEM_ERROR.getType());
		} catch (RequestNotPermitted e) {
			log.info("Request Not Permitted because requests is taking more than configured seconds :: {}",
					e.getMessage());
			transactionResponse.setResponseCode(EaSwitchResponseCodes.ISSUER_SYSTEM_INOPERATIVE.getCode());
			transactionResponse.setException(e.getMessage());
			transactionResponse.setResult(EaSwitchResponseCodes.SYSTEM_ERROR.getType());
		} catch (feign.FeignException e) {
			if (!e.responseBody().isEmpty()) {
				log.info("Feign Exception :: {}", StandardCharsets.UTF_8.decode(e.responseBody().get()));
				transactionResponse.setException(StandardCharsets.UTF_8.decode(e.responseBody().get()).toString());
				transactionResponse.setResponseCode(EaSwitchResponseCodes.SYSTEM_ERROR.getCode());
				transactionResponse.setResult(EaSwitchResponseCodes.SYSTEM_ERROR.getType());
			}

		}
		return transactionResponse;
	}

}
