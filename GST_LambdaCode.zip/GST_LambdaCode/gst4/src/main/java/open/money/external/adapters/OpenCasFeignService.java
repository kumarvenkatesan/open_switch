package open.money.external.adapters;

import java.net.ConnectException;
import java.net.URI;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.web.bind.annotation.RequestBody;

import feign.HeaderMap;
import feign.Request;
import feign.RequestLine;
import feign.Retryer;
import feign.Target;
import feign.gson.GsonDecoder;
import feign.gson.GsonEncoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig.SlidingWindowType;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.feign.FeignDecorators;
import io.github.resilience4j.feign.Resilience4jFeign;
import io.github.resilience4j.ratelimiter.RequestNotPermitted;
import open.money.external.adapters.dto.EaOpenCasTransactionRequestDto;
import open.money.external.adapters.utils.EaTransactionResponse;

public interface OpenCasFeignService {

	@RequestLine("POST")
	EaTransactionResponse openCasAuth(@RequestBody EaOpenCasTransactionRequestDto openCasTransactionRequestDto,
			URI baseUri, @HeaderMap Map<String, Object> headerMap)
			throws ConnectException, CallNotPermittedException, RequestNotPermitted, feign.FeignException;

	CircuitBreakerConfig circuitBreakerConfig = CircuitBreakerConfig.custom().failureRateThreshold(50)
			.slowCallRateThreshold(50).waitDurationInOpenState(Duration.ofSeconds(60))
			.slowCallDurationThreshold(Duration.ofSeconds(5)).permittedNumberOfCallsInHalfOpenState(50)
			.minimumNumberOfCalls(20).slidingWindowType(SlidingWindowType.COUNT_BASED).slidingWindowSize(100)
			.recordExceptions(Exception.class).build();

	// Create a CircuitBreakerRegistry with a custom global configuration
	CircuitBreakerRegistry circuitBreakerRegistry = CircuitBreakerRegistry.of(circuitBreakerConfig);

	// Get or create a CircuitBreaker from the CircuitBreakerRegistry
	// with a custom configuration
	CircuitBreaker circuitBreakerWithCustomConfig = circuitBreakerRegistry.circuitBreaker("openCasAuthCircuit",
			circuitBreakerConfig);

	FeignDecorators decorators = FeignDecorators.builder().withCircuitBreaker(circuitBreakerWithCustomConfig).build();
	OpenCasFeignService openCasResponse = Resilience4jFeign.builder(decorators).client(new OkHttpClient())
			.options(new Request.Options(100L, TimeUnit.SECONDS, 5L, TimeUnit.SECONDS, false))
			.encoder(new GsonEncoder()).decoder(new GsonDecoder()).logger(new Slf4jLogger(OpenCasFeignService.class))
			.retryer(Retryer.NEVER_RETRY).logLevel(feign.Logger.Level.FULL)
			.target(Target.EmptyTarget.create(OpenCasFeignService.class));

}