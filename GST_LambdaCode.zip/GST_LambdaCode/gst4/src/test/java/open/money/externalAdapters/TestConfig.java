package open.money.externalAdapters;

import org.springframework.context.annotation.Configuration;

/**
 * 
 *Sample config for Junit context 
 */
@Configuration
public class TestConfig {
	
}
