# OpenSwitch-ExternalAdapter
External Host adapter used in transaction service and SAF
test
